# main.py — Module 6: Dashboard & Visualization
# Port: 8005

import os
import uvicorn
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from loguru import logger
from routes import router

app = FastAPI(
    title="Echo-Log — Dashboard",
    description="Module 6: Visual dashboard for all pipeline outputs",
    version="1.0.0"
)

os.makedirs("logs", exist_ok=True)
os.makedirs("static", exist_ok=True)

logger.add(
    "logs/dashboard.log",
    rotation="10 MB",
    retention="7 days",
    level="INFO",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}"
)

app.mount("/static", StaticFiles(directory="static"), name="static")
app.include_router(router)


if __name__ == "__main__":
    logger.info("🚀 Starting Echo-Log Dashboard on port 8005...")
    logger.info("📊 Open http://localhost:8005 in your browser")
    uvicorn.run("main:app", host="0.0.0.0", port=8005, reload=True)
