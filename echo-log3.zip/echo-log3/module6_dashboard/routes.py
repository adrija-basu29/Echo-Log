# routes.py — Module 6 Dashboard API + page routes

import json
import requests
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from loguru import logger
from dashboard_data import (
    get_dashboard_summary, get_recent_alerts, get_alert_batches,
    get_system_metrics, get_module_health, get_rca_rules_count,
    get_remediation_history, load_alert_history,
)

router    = APIRouter()
templates = Jinja2Templates(directory="templates")

M3 = "http://localhost:8002/api/v3"
M4 = "http://localhost:8003/api/v4"
M5 = "http://localhost:8004/api/v5"
M7 = "http://localhost:8006/api/v7"
M8 = "http://localhost:8007/api/v8"


# ── Page Routes ───────────────────────────────────────────────────────────────

@router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    """Main dashboard page."""
    summary    = get_dashboard_summary()
    metrics    = get_system_metrics()
    health     = get_module_health()
    recent     = get_recent_alerts(limit=20)
    remediation = get_remediation_history(limit=8)
    rules_count = get_rca_rules_count()

    return templates.TemplateResponse("dashboard.html", {
        "request":     request,
        "summary":     summary,
        "metrics":     metrics,
        "health":      health,
        "recent":      recent,
        "remediation": remediation,
        "rules_count": rules_count,
    })


@router.get("/alerts", response_class=HTMLResponse)
async def alerts_page(request: Request):
    """Full alert history page."""
    batches = get_alert_batches(limit=30)
    return templates.TemplateResponse("alerts.html", {
        "request": request,
        "batches": batches,
    })


@router.get("/run", response_class=HTMLResponse)
async def run_page(request: Request):
    """Live pipeline runner page — upload logs and run the full pipeline."""
    return templates.TemplateResponse("run.html", {"request": request})


@router.get("/reports", response_class=HTMLResponse)
async def reports_page(request: Request):
    """Reports list page."""
    try:
        r = requests.get(f"{M7}/reports", timeout=5)
        reports = r.json().get("reports", []) if r.status_code == 200 else []
    except Exception:
        reports = []
    return templates.TemplateResponse("reports.html", {
        "request": request,
        "reports": reports,
    })


@router.get("/learning", response_class=HTMLResponse)
async def learning_page(request: Request):
    """Model learning & improvement visualization page."""
    return templates.TemplateResponse("learning.html", {"request": request})


# ── JSON API Routes (for live dashboard refresh) ──────────────────────────────

@router.get("/api/summary")
async def api_summary():
    return get_dashboard_summary()


@router.get("/api/alerts")
async def api_alerts(limit: int = 50):
    return {"alerts": get_recent_alerts(limit=limit)}


@router.get("/api/metrics")
async def api_metrics():
    return {
        "system":  get_system_metrics(),
        "health":  get_module_health(),
    }


@router.get("/api/batches")
async def api_batches(limit: int = 20):
    return {"batches": get_alert_batches(limit=limit)}


@router.post("/api/run-pipeline")
async def run_pipeline(payload: dict):
    """
    Proxy: forward log entries to M5 full-pipeline and return results.
    Also records the run in M8 for continuous learning.
    """
    try:
        r = requests.post(f"{M5}/full-pipeline", json=payload, timeout=300)
        if r.status_code != 200:
            raise HTTPException(status_code=502, detail=r.text[:400])
        result = r.json()

        # Hook M8 — record this run for continuous learning (fire and forget)
        try:
            pipeline_data = result.get("pipeline", {})
            log_filename  = payload.get("log_filename", "unknown")
            requests.post(f"{M8}/record-run", json={
                "pipeline_data": pipeline_data,
                "log_filename":  log_filename,
                "auto_feedback": True,
            }, timeout=5)
        except Exception:
            pass  # M8 is optional — don't fail the pipeline if M8 is down

        return result
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="Module 5 is not running (port 8004).")


@router.get("/api/learning/status")
async def learning_status():
    """Proxy: get learning status from Module 8."""
    try:
        r = requests.get(f"{M8}/status", timeout=5)
        return r.json()
    except Exception:
        return {"error": "Module 8 not running", "feedback": {"total": 0}, "recent_runs": [], "recent_retrains": []}


@router.get("/api/learning/runs")
async def learning_runs(limit: int = 30):
    """Proxy: get run history from Module 8."""
    try:
        r = requests.get(f"{M8}/runs?limit={limit}", timeout=5)
        return r.json()
    except Exception:
        return {"runs": []}


@router.get("/api/learning/performance")
async def learning_performance():
    """Proxy: get performance history from Module 8."""
    try:
        r = requests.get(f"{M8}/performance", timeout=5)
        return r.json()
    except Exception:
        return {"history": [], "trend": {}}


@router.post("/api/learning/retrain")
async def learning_retrain(payload: dict = {}):
    """Proxy: trigger retrain via Module 8."""
    try:
        r = requests.post(f"{M8}/retrain-now",
                          json={"clear_after": payload.get("clear_after", True)},
                          timeout=120)
        if r.status_code != 200:
            raise HTTPException(status_code=r.status_code, detail=r.text[:300])
        return r.json()
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="Module 8 not running (port 8007)")


@router.post("/api/learning/feedback")
async def learning_feedback(payload: dict):
    """Proxy: submit human feedback to Module 8."""
    try:
        r = requests.post(f"{M8}/feedback", json=payload, timeout=5)
        return r.json()
    except Exception:
        raise HTTPException(status_code=503, detail="Module 8 not running")


@router.post("/api/learning/record-run")
async def learning_record_run(payload: dict):
    """Proxy: record a pipeline run in Module 8."""
    try:
        r = requests.post(f"{M8}/record-run", json=payload, timeout=10)
        return r.json()
    except Exception:
        return {"status": "skipped", "reason": "Module 8 not running"}


@router.post("/api/generate-report")
async def generate_report(payload: dict):
    """Proxy: generate report via Module 7. Passes recipients through."""
    try:
        r = requests.post(f"{M7}/generate", json=payload, timeout=30)
        if r.status_code != 200:
            raise HTTPException(status_code=502, detail=r.text[:400])
        return r.json()
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="Module 7 is not running (port 8006).")


@router.get("/api/reports")
async def get_reports():
    """Proxy: list all reports from Module 7."""
    try:
        r = requests.get(f"{M7}/reports", timeout=5)
        return r.json()
    except Exception:
        return {"reports": [], "error": "Module 7 not running"}


@router.get("/api/report/{report_id}/html")
async def proxy_report_html(report_id: str):
    """Proxy: get report HTML from Module 7."""
    try:
        r = requests.get(f"{M7}/report/{report_id}/html", timeout=10)
        if r.status_code == 200:
            from fastapi.responses import HTMLResponse
            return HTMLResponse(content=r.text)
        raise HTTPException(status_code=r.status_code, detail="Report not found")
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="Module 7 not running")


@router.get("/api/report/{report_id}/download")
async def proxy_report_download(report_id: str):
    """Proxy: download report from Module 7."""
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url=f"{M7}/report/{report_id}/download")


@router.get("/api/health")
async def api_health():
    # Instant — no external calls so launcher health check works fast
    return {"status": "online", "port": 8005}


@router.get("/api/modules-health")
async def api_modules_health():
    # Separate endpoint for checking other modules — can be slow
    return {"status": "online", "port": 8005, "modules": get_module_health()}
