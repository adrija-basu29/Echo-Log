# dashboard_data.py
# Data layer for Module 6 Dashboard
# Reads alerts_history.json (written by Module 5 alert_manager)
# + queries live APIs from M3/M4/M5 for real-time stats

import json
import os
import requests
from pathlib import Path
from loguru import logger

M3 = "http://localhost:8002/api/v3"
M4 = "http://localhost:8003/api/v4"
M5 = "http://localhost:8004/api/v5"

ALERTS_FILE = os.getenv("ALERTS_HISTORY_PATH", "alerts_history.json")


# ─────────────────────────────────────────────────────────────────────────────
# alerts_history.json reader
# ─────────────────────────────────────────────────────────────────────────────

def load_alert_history() -> list:
    """Load all alert batches from alerts_history.json written by alert_manager."""
    path = Path(ALERTS_FILE)
    if not path.exists():
        logger.warning(f"alerts_history.json not found at {ALERTS_FILE}")
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception as e:
        logger.error(f"Failed to load alert history: {e}")
        return []


def get_dashboard_summary() -> dict:
    """
    Aggregate stats across all alert batches for the summary cards.
    """
    history = load_alert_history()

    if not history:
        return {
            "total_batches":    0,
            "total_alerts":     0,
            "critical_count":   0,
            "high_count":       0,
            "medium_count":     0,
            "low_count":        0,
            "total_anomalies":  0,
            "total_entries":    0,
            "chains_detected":  0,
            "log_types_seen":   [],
            "top_entities":     [],
            "latest_batch":     None,
            "alert_trend":      [],
        }

    total_alerts    = 0
    sev_counts      = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
    total_anomalies = 0
    total_entries   = 0
    chains_total    = 0
    log_types       = set()
    entity_map      = {}
    alert_trend     = []

    for batch in history:
        alerts = batch.get("alerts", [])
        total_alerts    += len(alerts)
        total_anomalies += batch.get("anomaly_count", 0)
        total_entries   += batch.get("total_entries", 0)
        chains_total    += batch.get("chains_detected", 0)
        lt = batch.get("log_type", "")
        if lt:
            log_types.add(lt)

        for alert in alerts:
            sev = alert.get("severity", "LOW")
            sev_counts[sev] = sev_counts.get(sev, 0) + 1

        for entity in batch.get("top_entities", []):
            e = entity.get("entity", "")
            if e:
                if e not in entity_map:
                    entity_map[e] = {"entity": e, "anomaly_count": 0, "max_score": 0}
                entity_map[e]["anomaly_count"] += entity.get("anomaly_count", 0)
                entity_map[e]["max_score"] = max(
                    entity_map[e]["max_score"], entity.get("max_score", 0)
                )

        alert_trend.append({
            "timestamp":     batch.get("timestamp", ""),
            "log_file":      batch.get("log_file", ""),
            "anomaly_count": batch.get("anomaly_count", 0),
            "critical":      batch.get("critical_count", 0),
            "high":          batch.get("high_count", 0),
            "alert_count":   len(alerts),
        })

    top_entities = sorted(
        entity_map.values(),
        key=lambda x: x["anomaly_count"],
        reverse=True
    )[:8]

    return {
        "total_batches":   len(history),
        "total_alerts":    total_alerts,
        "critical_count":  sev_counts["CRITICAL"],
        "high_count":      sev_counts["HIGH"],
        "medium_count":    sev_counts["MEDIUM"],
        "low_count":       sev_counts["LOW"],
        "total_anomalies": total_anomalies,
        "total_entries":   total_entries,
        "chains_detected": chains_total,
        "log_types_seen":  sorted(log_types),
        "top_entities":    top_entities,
        "latest_batch":    history[-1] if history else None,
        "alert_trend":     alert_trend[-20:],   # last 20 runs
    }


def get_recent_alerts(limit: int = 50) -> list:
    """Get the most recent individual alerts across all batches."""
    history = load_alert_history()
    all_alerts = []
    for batch in reversed(history):
        for alert in batch.get("alerts", []):
            alert["_batch_log_file"] = batch.get("log_file", "")
            alert["_batch_log_type"] = batch.get("log_type", "")
            all_alerts.append(alert)
        if len(all_alerts) >= limit:
            break
    return all_alerts[:limit]


def get_alert_batches(limit: int = 20) -> list:
    """Get recent alert batches with summary info."""
    history = load_alert_history()
    return list(reversed(history))[:limit]


# ─────────────────────────────────────────────────────────────────────────────
# Live API queries
# ─────────────────────────────────────────────────────────────────────────────

def get_system_metrics() -> dict:
    try:
        r = requests.get(f"{M5}/system-metrics", timeout=4)
        if r.status_code == 200:
            return r.json().get("metrics", {})
    except Exception:
        pass
    return {}


def get_module_health() -> dict:
    health = {}
    for name, url in [("M3 Anomaly Detection", M3),
                      ("M4 Root Cause Analysis", M4),
                      ("M5 Escalation", M5)]:
        try:
            r = requests.get(f"{url}/health", timeout=3)
            health[name] = {"status": "online" if r.status_code == 200 else "error",
                            "code": r.status_code}
        except Exception:
            health[name] = {"status": "offline", "code": None}
    return health


def get_rca_rules_count() -> int:
    try:
        r = requests.get(f"{M4}/rules", timeout=3)
        if r.status_code == 200:
            return r.json().get("total_rules", 0)
    except Exception:
        pass
    return 0


def get_remediation_history(limit: int = 10) -> list:
    try:
        r = requests.get(f"{M5}/history?limit={limit}", timeout=4)
        if r.status_code == 200:
            return r.json().get("history", [])
    except Exception:
        pass
    return []
