# routes.py — Module 6 Dashboard API + page routes

import json
import requests
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from loguru import logger
from dashboard_data import (
    get_dashboard_summary, get_recent_alerts, get_alert_batches,
    get_system_metrics, get_module_health, get_rca_rules_count,
    get_remediation_history, load_alert_history,
)

router    = APIRouter()
templates = Jinja2Templates(directory="templates")

M3 = "http://localhost:8002/api/v3"
M4 = "http://localhost:8003/api/v4"
M5 = "http://localhost:8004/api/v5"
M7 = "http://localhost:8006/api/v7"


# ── Page Routes ───────────────────────────────────────────────────────────────

@router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    """Main dashboard page."""
    summary    = get_dashboard_summary()
    metrics    = get_system_metrics()
    health     = get_module_health()
    recent     = get_recent_alerts(limit=20)
    remediation = get_remediation_history(limit=8)
    rules_count = get_rca_rules_count()

    return templates.TemplateResponse("dashboard.html", {
        "request":     request,
        "summary":     summary,
        "metrics":     metrics,
        "health":      health,
        "recent":      recent,
        "remediation": remediation,
        "rules_count": rules_count,
    })


@router.get("/alerts", response_class=HTMLResponse)
async def alerts_page(request: Request):
    """Full alert history page."""
    batches = get_alert_batches(limit=30)
    return templates.TemplateResponse("alerts.html", {
        "request": request,
        "batches": batches,
    })


@router.get("/run", response_class=HTMLResponse)
async def run_page(request: Request):
    """Live pipeline runner page — upload logs and run the full pipeline."""
    return templates.TemplateResponse("run.html", {"request": request})


@router.get("/reports", response_class=HTMLResponse)
async def reports_page(request: Request):
    """Reports list page."""
    try:
        r = requests.get(f"{M7}/reports", timeout=5)
        reports = r.json().get("reports", []) if r.status_code == 200 else []
    except Exception:
        reports = []
    return templates.TemplateResponse("reports.html", {
        "request": request,
        "reports": reports,
    })


# ── JSON API Routes (for live dashboard refresh) ──────────────────────────────

@router.get("/api/summary")
async def api_summary():
    return get_dashboard_summary()


@router.get("/api/alerts")
async def api_alerts(limit: int = 50):
    return {"alerts": get_recent_alerts(limit=limit)}


@router.get("/api/metrics")
async def api_metrics():
    return {
        "system":  get_system_metrics(),
        "health":  get_module_health(),
    }


@router.get("/api/batches")
async def api_batches(limit: int = 20):
    return {"batches": get_alert_batches(limit=limit)}


@router.post("/api/run-pipeline")
async def run_pipeline(payload: dict):
    """
    Proxy: forward log entries to M5 full-pipeline and return results.
    Called by the Run page via JS fetch.
    """
    try:
        r = requests.post(f"{M5}/full-pipeline", json=payload, timeout=300)
        if r.status_code != 200:
            raise HTTPException(status_code=502, detail=r.text[:400])
        return r.json()
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="Module 5 is not running (port 8004).")


@router.post("/api/generate-report")
async def generate_report(payload: dict):
    """Proxy: generate report via Module 7."""
    try:
        r = requests.post(f"{M7}/generate", json=payload, timeout=30)
        if r.status_code != 200:
            raise HTTPException(status_code=502, detail=r.text[:400])
        return r.json()
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="Module 7 is not running (port 8006).")


@router.get("/api/reports")
async def get_reports():
    """Proxy: list all reports from Module 7."""
    try:
        r = requests.get(f"{M7}/reports", timeout=5)
        return r.json()
    except Exception:
        return {"reports": [], "error": "Module 7 not running"}


@router.get("/api/report/{report_id}/html")
async def proxy_report_html(report_id: str):
    """Proxy: get report HTML from Module 7."""
    try:
        r = requests.get(f"{M7}/report/{report_id}/html", timeout=10)
        if r.status_code == 200:
            from fastapi.responses import HTMLResponse
            return HTMLResponse(content=r.text)
        raise HTTPException(status_code=r.status_code, detail="Report not found")
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="Module 7 not running")


@router.get("/api/report/{report_id}/download")
async def proxy_report_download(report_id: str):
    """Proxy: download report from Module 7."""
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url=f"{M7}/report/{report_id}/download")


@router.get("/api/health")
async def api_health():
    # Instant — no external calls so launcher health check works fast
    return {"status": "online", "port": 8005}


@router.get("/api/modules-health")
async def api_modules_health():
    # Separate endpoint for checking other modules — can be slow
    return {"status": "online", "port": 8005, "modules": get_module_health()}
