# trainer.py
# Handles training the ML model on ALL 16 loghub log types
# Supports: raw .log, _structured.csv, _templates.csv

import os
import re
import json
import numpy as np
import pandas as pd
from loguru import logger
from log_schemas import (
    LOG_TYPE_SCHEMAS, ANOMALY_KEYWORDS, NORMAL_KEYWORDS,
    SECURITY_KEYWORDS, CONNECTION_KEYWORDS
)
from models import train_isolation_forest, train_scaler

TRAINING_DATA_DIR = "training_data"
MODEL_DIR         = "saved_models"
METADATA_PATH     = os.path.join(MODEL_DIR, "training_metadata.json")

os.makedirs(TRAINING_DATA_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

FEATURE_KEYS = [
    "level_encoded", "is_error", "is_warning",
    "has_anomaly_keyword", "has_normal_keyword",
    "has_security_keyword", "has_connection_keyword",
    "status_code", "status_4xx", "status_5xx",
    "status_403", "status_404", "status_500", "status_502",
    "response_time", "response_size", "message_length",
    "is_sensitive_component", "has_ip",
    "ip_frequency", "ip_is_high_frequency",
    "url_sensitivity", "is_admin_endpoint",
    "dangerous_method_on_admin", "method_encoded"
]

SENSITIVE_COMPONENTS = [
    "admin", "root", "auth", "security", "kernel",
    "ssh", "sudo", "cron", "firewall", "iptables"
]

LEVEL_MAP = {
    "INFO": 1, "I": 1, "NOTICE": 1,
    "DEBUG": 0, "D": 0, "VERBOSE": 0, "V": 0,
    "WARNING": 2, "WARN": 2, "W": 2,
    "ERROR": 3, "E": 3,
    "CRITICAL": 4, "FATAL": 4, "F": 4,
}


# ─────────────────────────────────────────────
# File Type Detection
# ─────────────────────────────────────────────

def detect_log_type(filename: str) -> str:
    """Detect which of 16 log types based on filename."""
    filename_upper = filename.upper()
    for log_type in LOG_TYPE_SCHEMAS.keys():
        if log_type.upper() in filename_upper:
            return log_type
    return "UNKNOWN"


def detect_file_role(filename: str) -> str:
    """Detect if file is structured CSV, templates CSV, or raw log."""
    if "_structured.csv" in filename.lower():
        return "structured"
    elif "_templates.csv" in filename.lower():
        return "templates"
    elif filename.endswith(".log"):
        return "raw"
    elif filename.endswith(".csv"):
        return "structured"
    return "unknown"


# ─────────────────────────────────────────────
# Universal Feature Extraction
# ─────────────────────────────────────────────

def extract_features_from_content(
    content: str, level: str, component: str
) -> dict:
    """
    Extracts all 25 features from any log content.
    Works universally across all 16 log types.
    """
    content_lower = content.lower()

    level_encoded = LEVEL_MAP.get(str(level).upper().strip(), 1)

    status_match = re.search(r'\b([2-5]\d{2})\b', content)
    status_code  = int(status_match.group(1)) if status_match else -1

    ip_match = re.search(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', content)
    ip = ip_match.group(1) if ip_match else "unknown"

    numbers = re.findall(r'\b(\d+)\b', content)
    response_time = int(numbers[-1])  if numbers            else 0
    response_size = int(numbers[-2])  if len(numbers) >= 2  else 0

    method_map = {"GET": 1, "POST": 2, "PUT": 3, "DELETE": 4, "PATCH": 5}
    method_encoded = -1
    for m, v in method_map.items():
        if m in content:
            method_encoded = v
            break

    url_sensitivity = 0
    url_map = {
        "/usr/admin/developer": 10, "/usr/admin": 8,
        "/usr/login": 5, "/usr/register": 3, "/usr": 1
    }
    for url, score in url_map.items():
        if url in content:
            url_sensitivity = score
            break

    admin_keywords = ["/admin", "/developer", "/root", "/superuser"]
    is_admin = int(any(k in content_lower for k in admin_keywords))

    dangerous = ["DELETE /usr/admin", "PUT /usr/admin", "DELETE /usr/login"]
    is_dangerous = int(any(p in content for p in dangerous))

    is_sens_comp = int(any(s in str(component).lower() for s in SENSITIVE_COMPONENTS))

    return {
        "level_encoded":    level_encoded,
        "is_error":         int(level_encoded >= 3 or (status_code >= 500 if status_code > 0 else False)),
        "is_warning":       int(level_encoded == 2 or (400 <= status_code < 500 if status_code > 0 else False)),

        "has_anomaly_keyword":    int(any(w in content_lower for w in ANOMALY_KEYWORDS)),
        "has_normal_keyword":     int(any(w in content_lower for w in NORMAL_KEYWORDS)),
        "has_security_keyword":   int(any(w in content_lower for w in SECURITY_KEYWORDS)),
        "has_connection_keyword": int(any(w in content_lower for w in CONNECTION_KEYWORDS)),

        "status_code": status_code if status_code > 0 else 0,
        "status_4xx":  int(400 <= status_code < 500) if status_code > 0 else 0,
        "status_5xx":  int(status_code >= 500)       if status_code > 0 else 0,
        "status_403":  int(status_code == 403),
        "status_404":  int(status_code == 404),
        "status_500":  int(status_code == 500),
        "status_502":  int(status_code == 502),

        "response_time":   response_time,
        "response_size":   response_size,
        "message_length":  len(content),

        "is_sensitive_component":  is_sens_comp,
        "has_ip":                  int(ip != "unknown"),

        "ip_frequency":         1,   # Updated after all entries loaded
        "ip_is_high_frequency": 0,   # Updated after all entries loaded

        "url_sensitivity":           url_sensitivity,
        "is_admin_endpoint":         is_admin,
        "dangerous_method_on_admin": is_dangerous,
        "method_encoded":            method_encoded,
    }


# ─────────────────────────────────────────────
# IP Frequency Updater
# ─────────────────────────────────────────────

def update_ip_frequencies(entries: list[dict]) -> list[dict]:
    """Counts IP frequency globally across all entries."""
    from collections import Counter
    ip_counts = Counter()

    for entry in entries:
        raw = entry.get("raw_text", "")
        ip_match = re.match(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', raw)
        if ip_match:
            ip_counts[ip_match.group(1)] += 1

    high_threshold = max(5, np.mean(list(ip_counts.values())) * 2) if ip_counts else 5

    for entry in entries:
        raw = entry.get("raw_text", "")
        ip_match = re.match(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', raw)
        if ip_match and "_features" in entry:
            ip = ip_match.group(1)
            freq = ip_counts.get(ip, 1)
            entry["_features"]["ip_frequency"]         = freq
            entry["_features"]["ip_is_high_frequency"] = int(freq > high_threshold)

    return entries


# ─────────────────────────────────────────────
# File Loaders
# ─────────────────────────────────────────────

def load_structured_csv(filepath: str, log_type: str) -> list[dict]:
    """Load _structured.csv file for any of 16 log types."""
    logger.info(f"Loading structured CSV: {os.path.basename(filepath)} ({log_type})")

    schema = LOG_TYPE_SCHEMAS.get(log_type, LOG_TYPE_SCHEMAS["Apache"])

    try:
        df = pd.read_csv(filepath, on_bad_lines="skip", low_memory=False)
    except Exception as e:
        logger.error(f"Failed to read {filepath}: {e}")
        return []

    entries = []

    for _, row in df.iterrows():
        try:
            content   = str(row.get(schema["content_col"],   ""))
            level     = str(row.get(schema["level_col"],     "INFO"))
            component = str(row.get(schema["component_col"], ""))
            event_id  = str(row.get(schema["event_id_col"],  ""))
            template  = str(row.get(schema["template_col"],  ""))
            line_id   = int(row.get("LineId", 0))

            date_val  = str(row.get(schema["date_col"], ""))
            time_val  = str(row.get(schema["time_col"], ""))
            timestamp = f"{date_val} {time_val}".strip()

            features = extract_features_from_content(content, level, component)

            ip_match = re.search(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', content)
            ip = ip_match.group(1) if ip_match else "unknown"

            entry = {
                "line_number":    line_id,
                "timestamp":      timestamp,
                "level":          level,
                "service":        f"{component} [{ip}]" if ip != "unknown" else component,
                "message":        content[:300],
                "event_id":       event_id,
                "event_template": template,
                "log_type":       log_type,
                "is_error":       bool(features["is_error"]),
                "is_warning":     bool(features["is_warning"]),
                "raw_text":       content,
                "_features":      features
            }
            entries.append(entry)

        except Exception as e:
            logger.debug(f"Skipping row: {e}")
            continue

    logger.info(f"✅ Loaded {len(entries)} entries from {log_type} structured CSV")
    return entries


def load_templates_csv(filepath: str, log_type: str) -> dict:
    """Load _templates.csv for enrichment."""
    logger.info(f"Loading templates: {os.path.basename(filepath)} ({log_type})")
    try:
        df = pd.read_csv(filepath, on_bad_lines="skip")
    except Exception as e:
        logger.error(f"Failed to read templates {filepath}: {e}")
        return {}

    templates = {}
    for _, row in df.iterrows():
        event_id = str(row.get("EventId", ""))
        templates[event_id] = {
            "template":    str(row.get("EventTemplate", "")),
            "occurrences": int(row.get("Occurrences", 0)),
            "log_type":    log_type
        }

    logger.info(f"✅ Loaded {len(templates)} templates from {log_type}")
    return templates


def load_raw_log(filepath: str, log_type: str) -> list[dict]:
    """Load raw .log file as fallback."""
    logger.info(f"Loading raw log: {os.path.basename(filepath)} ({log_type})")
    entries = []
    line_number = 0

    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                line_number += 1
                if not line or len(line) < 5:
                    continue

                level = "INFO"
                line_upper = line.upper()
                if any(w in line_upper for w in ["ERROR", "FATAL", "CRITICAL"]):
                    level = "ERROR"
                elif any(w in line_upper for w in ["WARN", "WARNING"]):
                    level = "WARNING"
                elif "DEBUG" in line_upper:
                    level = "DEBUG"

                comp_match = re.search(r'\[([^\]]+)\]', line)
                component  = comp_match.group(1) if comp_match else log_type

                features = extract_features_from_content(line, level, component)

                ip_match = re.match(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', line)
                ip = ip_match.group(1) if ip_match else "unknown"

                entry = {
                    "line_number": line_number,
                    "timestamp":   None,
                    "level":       level,
                    "service":     f"{component} [{ip}]" if ip != "unknown" else component,
                    "message":     line[:300],
                    "log_type":    log_type,
                    "is_error":    bool(features["is_error"]),
                    "is_warning":  bool(features["is_warning"]),
                    "raw_text":    line,
                    "_features":   features
                }
                entries.append(entry)

    except Exception as e:
        logger.error(f"Failed to read {filepath}: {e}")

    logger.info(f"✅ Loaded {len(entries)} entries from raw {log_type} log")
    return entries


# ─────────────────────────────────────────────
# Feature Matrix Builder
# ─────────────────────────────────────────────

def build_feature_matrix(entries: list[dict]):
    """Convert entries to numpy matrix for ML training."""
    rows = []
    for entry in entries:
        features = entry.get("_features", {})
        row = [float(features.get(k, 0)) for k in FEATURE_KEYS]
        rows.append(row)
    return np.array(rows, dtype=float)


# ─────────────────────────────────────────────
# Master Training Function
# ─────────────────────────────────────────────

def train_on_multiple_files(file_paths: list[str]) -> dict:
    """
    Master training function.
    Accepts any mix of .log / _structured.csv / _templates.csv
    from any of the 16 loghub log types.
    """
    all_entries    = []
    all_templates  = {}
    type_breakdown = {}

    logger.info(f"Starting training on {len(file_paths)} files...")

    # ── Step 1: Load all files ──────────────────────
    for filepath in file_paths:
        filename  = os.path.basename(filepath)
        log_type  = detect_log_type(filename)
        file_role = detect_file_role(filename)

        if log_type == "UNKNOWN":
            logger.warning(f"Unknown log type for {filename} — using Apache as fallback")
            log_type = "Apache"

        logger.info(f"→ {filename} | Type: {log_type} | Role: {file_role}")

        if file_role == "structured":
            entries = load_structured_csv(filepath, log_type)
            all_entries.extend(entries)
            type_breakdown[log_type] = type_breakdown.get(log_type, 0) + len(entries)

        elif file_role == "templates":
            templates = load_templates_csv(filepath, log_type)
            all_templates.update(templates)

        elif file_role == "raw":
            entries = load_raw_log(filepath, log_type)
            all_entries.extend(entries)
            type_breakdown[log_type] = type_breakdown.get(log_type, 0) + len(entries)

        else:
            logger.warning(f"Unrecognized file role for {filename} — skipping")

    if len(all_entries) < 10:
        return {
            "status": "error",
            "message": "Not enough data. Need at least 10 entries."
        }

    logger.info(f"Total entries loaded: {len(all_entries)}")

    # ── Step 2: Update IP frequencies globally ──────
    logger.info("Updating IP frequencies...")
    all_entries = update_ip_frequencies(all_entries)

    # ── Step 3: Build feature matrix ────────────────
    logger.info("Building feature matrix...")
    X = build_feature_matrix(all_entries)
    logger.info(f"Feature matrix: {X.shape[0]} rows × {X.shape[1]} features")

    # ── Step 4: Train scaler ─────────────────────────
    logger.info("Training StandardScaler...")
    scaler = train_scaler(X)
    X_scaled = scaler.transform(X)

    # ── Step 5: Train Isolation Forest ───────────────
    logger.info("Training Isolation Forest on all data...")
    train_isolation_forest(X_scaled)

    # ── Step 6: Save metadata ────────────────────────
    metadata = {
        "status":           "trained",
        "total_files":      len(file_paths),
        "total_entries":    len(all_entries),
        "total_templates":  len(all_templates),
        "feature_count":    len(FEATURE_KEYS),
        "feature_keys":     FEATURE_KEYS,
        "log_type_breakdown": type_breakdown,
        "files_trained_on": [os.path.basename(f) for f in file_paths],
        "supported_log_types": list(LOG_TYPE_SCHEMAS.keys())
    }

    with open(METADATA_PATH, "w") as f:
        json.dump(metadata, f, indent=2)

    logger.info("✅ Training complete!")
    logger.info(f"Log type breakdown: {type_breakdown}")

    return {
        "status":                "success",
        "total_files_used":      len(file_paths),
        "total_entries_trained": len(all_entries),
        "feature_count":         len(FEATURE_KEYS),
        "log_type_breakdown":    type_breakdown,
        "templates_loaded":      len(all_templates),
        "message":               "✅ Model trained successfully on all log types"
    }
