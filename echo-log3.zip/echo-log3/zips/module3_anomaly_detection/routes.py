# routes.py
# All API routes for Module 3 — Anomaly Detection

import os
import json
from fastapi import APIRouter, HTTPException, File, UploadFile
from fastapi.responses import JSONResponse
from loguru import logger
import aiofiles

from anomaly_detector import run_detection_pipeline, save_feedback, load_feedback
from evaluator import generate_full_evaluation

router = APIRouter()


# ─────────────────────────────────────────────
# ROUTE 1: Health Check
# ─────────────────────────────────────────────

@router.get("/health")
async def health_check():
    return {
        "status": "✅ Echo-Log Anomaly Detection API is running",
        "module": "Module 3 — Anomaly Detection",
        "models": ["Isolation Forest", "Local Outlier Factor", "Statistical Z-Score"]
    }


# ─────────────────────────────────────────────
# ROUTE 2: Analyze Logs (Main Detection)
# URL: POST /api/v3/analyze
# Input: structured_logs from Module 2
# ─────────────────────────────────────────────

@router.post("/analyze")
async def analyze_logs(payload: dict):
    """
    Accepts structured log entries from Module 2
    and returns full anomaly detection report.
    """
    try:
        entries = payload.get("structured_logs", [])

        if not entries:
            raise HTTPException(status_code=400, detail="No log entries provided")
        if len(entries) < 5:
            raise HTTPException(status_code=400, detail="Need at least 5 log entries")

        logger.info(f"Received {len(entries)} entries for analysis")
        entries_dict = [e if isinstance(e, dict) else e.dict() for e in entries]

        report = run_detection_pipeline(entries_dict, force_retrain=False)

        return JSONResponse(status_code=200, content=report)

    except Exception as e:
        logger.error(f"Analysis failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────
# ROUTE 3: Analyze + Generate Graphs
# URL: POST /api/v3/analyze-and-evaluate
# ─────────────────────────────────────────────

@router.post("/analyze-and-evaluate")
async def analyze_and_evaluate(payload: dict):
    """
    Runs full anomaly detection AND generates
    all 7 performance graphs + metrics.
    """
    try:
        entries = payload.get("structured_logs", [])
        if not entries:
            raise HTTPException(status_code=400, detail="No entries provided")

        entries_dict = [e if isinstance(e, dict) else e.dict() for e in entries]

        # Run detection
        report = run_detection_pipeline(entries_dict)

        # Generate graphs and metrics
        evaluation = generate_full_evaluation(report)

        return JSONResponse(status_code=200, content={
            "detection_report": {
                "total_entries":      report["total_entries"],
                "anomaly_count":      report["anomaly_count"],
                "anomaly_percentage": report["anomaly_percentage"],
                "critical_count":     report["critical_count"],
                "high_count":         report["high_count"],
                "medium_count":       report["medium_count"],
                "low_count":          report["low_count"],
            },
            "performance_metrics": evaluation["metrics"],
            "graphs_generated":    evaluation["graphs_generated"],
            "graph_locations":     evaluation["graph_paths"],
            "message": (
                f"✅ Analysis complete. "
                f"{evaluation['graphs_generated']} graphs saved "
                f"to performance_graphs/ folder"
            )
        })

    except Exception as e:
        logger.error(f"Evaluation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────
# ROUTE 4: Get Only Critical Anomalies
# URL: POST /api/v3/critical-only
# ─────────────────────────────────────────────

@router.post("/critical-only")
async def get_critical_only(payload: dict):
    """Returns only CRITICAL and HIGH severity anomalies."""
    try:
        entries = payload.get("structured_logs", [])
        entries_dict = [e if isinstance(e, dict) else e.dict() for e in entries]

        report = run_detection_pipeline(entries_dict)

        critical_results = [
            r for r in report["results"]
            if r["severity"] in ("CRITICAL", "HIGH")
        ]

        return JSONResponse(status_code=200, content={
            "critical_and_high_count": len(critical_results),
            "results": critical_results
        })

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────
# ROUTE 5: Force Retrain Model
# URL: POST /api/v3/retrain
# ─────────────────────────────────────────────

@router.post("/retrain")
async def retrain_model(payload: dict):
    """Forces the ML model to retrain from scratch."""
    try:
        entries = payload.get("structured_logs", [])
        if not entries:
            raise HTTPException(status_code=400, detail="No log entries provided")

        entries_dict = [e if isinstance(e, dict) else e.dict() for e in entries]
        report = run_detection_pipeline(entries_dict, force_retrain=True)

        return JSONResponse(status_code=200, content={
            "message": "✅ Model retrained successfully",
            "summary": {
                "total_entries":      report["total_entries"],
                "anomaly_count":      report["anomaly_count"],
                "anomaly_percentage": report["anomaly_percentage"],
                "critical_count":     report["critical_count"],
            }
        })

    except Exception as e:
        logger.error(f"Retraining failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────
# ROUTE 6: Train on Loghub Files (All 16 Types)
# URL: POST /api/v3/train-loghub
# ─────────────────────────────────────────────

@router.post("/train-loghub")
async def train_loghub(files: list[UploadFile] = File(...)):
    """
    Upload any combination of loghub files:
      - XXX_2k.log_structured.csv  (best — pre-parsed)
      - XXX_2k.log_templates.csv   (enrichment)
      - XXX_2k.log                 (raw fallback)

    Supports all 16 log types:
    HDFS, Hadoop, Spark, Zookeeper, BGL, HPC, Thunderbird,
    Windows, Linux, Android, HealthApp, Apache, OpenSSH,
    OpenStack, Mac, Proxifier
    """
    from trainer import train_on_multiple_files, detect_log_type, detect_file_role

    if len(files) > 50:
        raise HTTPException(status_code=400, detail="Max 50 files per session")

    saved_paths  = []
    file_summary = []
    os.makedirs("training_data", exist_ok=True)

    for file in files:
        save_path = f"training_data/{file.filename}"
        async with aiofiles.open(save_path, "wb") as f:
            content = await file.read()
            await f.write(content)

        saved_paths.append(save_path)
        log_type  = detect_log_type(file.filename)
        file_role = detect_file_role(file.filename)

        file_summary.append({
            "filename":      file.filename,
            "detected_type": log_type,
            "file_role":     file_role
        })
        logger.info(f"Saved: {file.filename} | Type: {log_type} | Role: {file_role}")

    result = train_on_multiple_files(saved_paths)

    return JSONResponse(status_code=200, content={
        "message":        "✅ Model trained on loghub datasets",
        "files_detected": file_summary,
        "training_result": result
    })


# ─────────────────────────────────────────────
# ROUTE 7: Check Training Status
# URL: GET /api/v3/training-status
# ─────────────────────────────────────────────

@router.get("/training-status")
async def training_status():
    """Shows what the model was trained on."""
    metadata_path = "saved_models/training_metadata.json"

    if not os.path.exists(metadata_path):
        return JSONResponse(status_code=200, content={
            "status":         "❌ Not trained yet",
            "recommendation": "Use POST /train-loghub to train first"
        })

    with open(metadata_path, "r") as f:
        metadata = json.load(f)

    return JSONResponse(status_code=200, content={
        "status":                  "✅ Model is trained",
        "total_entries_trained_on": metadata["total_entries"],
        "total_log_types":         len(metadata["log_type_breakdown"]),
        "log_type_breakdown":      metadata["log_type_breakdown"],
        "feature_count":           metadata["feature_count"],
        "files_used":              metadata["files_trained_on"]
    })


# ─────────────────────────────────────────────
# ROUTE 8: Submit Feedback
# URL: POST /api/v3/feedback
# ─────────────────────────────────────────────

@router.post("/feedback")
async def submit_feedback(payload: dict):
    """
    Submit feedback on whether an anomaly was real or false alarm.
    Builds labeled dataset for future retraining.

    Payload:
    {
        "entry": { ...log entry... },
        "confirmed_anomaly": true
    }
    """
    try:
        entry     = payload.get("entry")
        confirmed = payload.get("confirmed_anomaly", True)

        if not entry:
            raise HTTPException(status_code=400, detail="No entry provided")

        save_feedback(entry, confirmed)

        return JSONResponse(status_code=200, content={
            "message":            "✅ Feedback saved",
            "confirmed_anomaly":  confirmed
        })

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────
# ROUTE 9: Retrain With Feedback Data
# URL: POST /api/v3/retrain-with-feedback
# ─────────────────────────────────────────────

@router.post("/retrain-with-feedback")
async def retrain_with_feedback(payload: dict):
    """
    Retrains using current logs + confirmed feedback data.
    Makes the model smarter over time.
    """
    try:
        entries      = payload.get("structured_logs", [])
        entries_dict = [e if isinstance(e, dict) else e.dict() for e in entries]

        feedback             = load_feedback()
        confirmed_anomalies  = feedback.get("anomalies", [])
        confirmed_normals    = feedback.get("normals",   [])

        all_entries = entries_dict + confirmed_anomalies + confirmed_normals

        if len(all_entries) < 5:
            raise HTTPException(status_code=400, detail="Not enough data to retrain")

        report = run_detection_pipeline(all_entries, force_retrain=True)

        return JSONResponse(status_code=200, content={
            "message": "✅ Model retrained with feedback data",
            "training_summary": {
                "new_entries":               len(entries_dict),
                "confirmed_anomalies_used":  len(confirmed_anomalies),
                "confirmed_normals_used":    len(confirmed_normals),
                "total_training_size":       len(all_entries),
                "anomaly_count":             report["anomaly_count"],
                "anomaly_percentage":        report["anomaly_percentage"]
            }
        })

    except Exception as e:
        logger.error(f"Retrain with feedback failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────
# ROUTE 10: Feedback Stats
# URL: GET /api/v3/feedback-stats
# ─────────────────────────────────────────────

@router.get("/feedback-stats")
async def get_feedback_stats():
    """Shows how much labeled feedback data has been collected."""
    feedback  = load_feedback()
    anomalies = feedback.get("anomalies", [])
    normals   = feedback.get("normals",   [])
    total     = len(anomalies) + len(normals)

    if len(anomalies) < 10:    quality = "🔴 Poor — need more feedback"
    elif len(anomalies) < 50:  quality = "🟡 Fair — getting better"
    elif len(anomalies) < 200: quality = "🟢 Good — model is well trained"
    else:                      quality = "🌟 Excellent — highly trained"

    return JSONResponse(status_code=200, content={
        "confirmed_anomalies":    len(anomalies),
        "confirmed_normals":      len(normals),
        "total_feedback_entries": total,
        "model_quality":          quality
    })
