# scorer.py
# Combines scores from all 3 models into one final anomaly score

import numpy as np
from loguru import logger

WEIGHTS = {
    "isolation_forest": 0.40,
    "lof":              0.35,
    "statistical":      0.25,
}


def compute_final_score(if_score: float, lof_score: float, stat_score: float) -> float:
    weighted = (
        if_score   * WEIGHTS["isolation_forest"] +
        lof_score  * WEIGHTS["lof"] +
        stat_score * WEIGHTS["statistical"]
    )
    return round(weighted * 100, 2)


def assign_severity(score: float) -> str:
    if score >= 85:   return "CRITICAL"
    elif score >= 70: return "HIGH"
    elif score >= 50: return "MEDIUM"
    elif score >= 30: return "LOW"
    else:             return "NORMAL"


def identify_anomaly_reasons(entry: dict, score: float) -> list[str]:
    reasons  = []
    message  = entry.get("message", "")
    features = entry.get("_features", {})

    status = features.get("status_code", 0)
    if status >= 500:
        reasons.append(f"Server error detected (HTTP {status})")
    if status == 403:
        reasons.append("Unauthorized access attempt (HTTP 403)")
    if status == 404:
        reasons.append("Resource not found (HTTP 404)")

    if features.get("is_admin_endpoint", 0) == 1:
        reasons.append("Request targeting sensitive admin endpoint")
    if features.get("dangerous_method_on_admin", 0) == 1:
        reasons.append("Dangerous HTTP method used on admin endpoint")
    if features.get("has_security_keyword", 0) == 1:
        reasons.append("Security-related keywords detected in log")
    if features.get("has_anomaly_keyword", 0) == 1:
        reasons.append("Anomaly keywords detected (failed/error/refused)")
    if features.get("is_sensitive_component", 0) == 1:
        reasons.append("Request involves sensitive system component")

    ip_freq = features.get("ip_frequency", 0)
    if ip_freq > 10:
        reasons.append(f"High request frequency from same IP ({ip_freq} requests)")

    resp_time = features.get("response_time", 0)
    if resp_time > 4000:
        reasons.append(f"Very high response time ({resp_time}ms) — possible overload")

    if entry.get("is_error", False):
        reasons.append("Log level is ERROR or CRITICAL")

    if score >= 70 and not reasons:
        reasons.append("Statistical outlier detected by ML ensemble")

    return reasons if reasons else ["Slight deviation from normal pattern"]


def build_anomaly_results(
    entries: list[dict],
    if_scores: np.ndarray,
    lof_scores: np.ndarray,
    stat_scores: np.ndarray,
    feature_rows: list[dict]
) -> list[dict]:

    results = []

    for i, entry in enumerate(entries):
        if_score   = float(if_scores[i])
        lof_score  = float(lof_scores[i])
        stat_score = float(stat_scores[i])

        final_score = compute_final_score(if_score, lof_score, stat_score)
        severity    = assign_severity(final_score)

        entry["_features"] = feature_rows[i]
        reasons = identify_anomaly_reasons(entry, final_score)

        results.append({
            "line_number":             entry.get("line_number", i + 1),
            "raw_text":                entry.get("raw_text", ""),
            "anomaly_score":           final_score,
            "is_anomaly":              final_score >= 30,
            "severity":                severity,
            "anomaly_reasons":         reasons,
            "isolation_forest_score":  round(if_score   * 100, 2),
            "lof_score":               round(lof_score  * 100, 2),
            "statistical_score":       round(stat_score * 100, 2),
        })

    return results
