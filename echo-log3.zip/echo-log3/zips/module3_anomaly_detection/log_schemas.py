# log_schemas.py
# Defines the CSV column structure for all 16 loghub log types

LOG_TYPE_SCHEMAS = {
    "HDFS": {
        "date_col": "Date", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "Hadoop Distributed File System logs"
    },
    "Hadoop": {
        "date_col": "Date", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "Hadoop MapReduce logs"
    },
    "Spark": {
        "date_col": "Date", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "Apache Spark processing logs"
    },
    "Zookeeper": {
        "date_col": "Date", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "Apache Zookeeper coordination logs"
    },
    "BGL": {
        "date_col": "Date", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "BlueGene/L Supercomputer logs"
    },
    "HPC": {
        "date_col": "LogId", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "High Performance Computing logs"
    },
    "Thunderbird": {
        "date_col": "Date", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "Thunderbird Supercomputer logs"
    },
    "Windows": {
        "date_col": "Date", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "Windows Event logs"
    },
    "Linux": {
        "date_col": "Month", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "Linux system logs"
    },
    "Android": {
        "date_col": "Date", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "Android framework logs"
    },
    "HealthApp": {
        "date_col": "Time", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "Health application logs"
    },
    "Apache": {
        "date_col": "Time", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "Apache web server logs"
    },
    "OpenSSH": {
        "date_col": "Date", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "OpenSSH authentication logs"
    },
    "OpenStack": {
        "date_col": "Date", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "OpenStack cloud platform logs"
    },
    "Mac": {
        "date_col": "Month", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "macOS system logs"
    },
    "Proxifier": {
        "date_col": "Time", "time_col": "Time",
        "level_col": "Level", "component_col": "Component",
        "content_col": "Content", "event_id_col": "EventId",
        "template_col": "EventTemplate",
        "description": "Proxifier network proxy logs"
    }
}

ANOMALY_KEYWORDS = [
    "error", "failure", "failed", "fatal", "critical",
    "exception", "refused", "denied", "rejected", "timeout",
    "crash", "panic", "killed", "abort", "invalid",
    "unauthorized", "forbidden", "blocked", "attack",
    "overflow", "corrupt", "missing", "lost", "down"
]

NORMAL_KEYWORDS = [
    "success", "completed", "started", "initialized",
    "connected", "accepted", "ok", "ready", "running",
    "healthy", "normal", "finished", "done"
]

SECURITY_KEYWORDS = [
    "password", "authentication", "login", "ssh", "root",
    "sudo", "admin", "privilege", "permission", "access",
    "token", "certificate", "key", "credential"
]

CONNECTION_KEYWORDS = [
    "connection", "connect", "disconnect", "socket",
    "port", "bind", "listen", "timeout", "reset", "closed"
]
