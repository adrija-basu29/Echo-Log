# models.py
# Three ML models working together as an ensemble

import numpy as np
import joblib
import os
from loguru import logger
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.preprocessing import StandardScaler

MODEL_DIR   = "saved_models"
IF_PATH     = os.path.join(MODEL_DIR, "isolation_forest.pkl")
SCALER_PATH = os.path.join(MODEL_DIR, "scaler.pkl")

os.makedirs(MODEL_DIR, exist_ok=True)


# ─────────────────────────────────────────────
# Model 1: Isolation Forest (40% weight)
# ─────────────────────────────────────────────

def train_isolation_forest(X: np.ndarray) -> IsolationForest:
    logger.info("Training Isolation Forest...")
    model = IsolationForest(
        n_estimators=200,
        contamination=0.15,
        max_samples="auto",
        random_state=42,
        n_jobs=-1
    )
    model.fit(X)
    joblib.dump(model, IF_PATH)
    logger.info(f"Isolation Forest saved → {IF_PATH}")
    return model


def load_isolation_forest():
    if os.path.exists(IF_PATH):
        logger.info("Loading saved Isolation Forest...")
        return joblib.load(IF_PATH)
    return None


def predict_isolation_forest(model: IsolationForest, X: np.ndarray) -> np.ndarray:
    raw_scores = model.decision_function(X)
    scores = 1 - (raw_scores - raw_scores.min()) / (raw_scores.max() - raw_scores.min() + 1e-10)
    return scores


# ─────────────────────────────────────────────
# Model 2: Local Outlier Factor (35% weight)
# ─────────────────────────────────────────────

def predict_lof(X: np.ndarray) -> np.ndarray:
    logger.info("Running Local Outlier Factor...")
    n_neighbors = min(20, len(X) - 1)
    lof = LocalOutlierFactor(
        n_neighbors=n_neighbors,
        contamination=0.15,
        novelty=False,
        n_jobs=-1
    )
    lof.fit_predict(X)
    raw_scores = -lof.negative_outlier_factor_
    scores = (raw_scores - raw_scores.min()) / (raw_scores.max() - raw_scores.min() + 1e-10)
    return scores


# ─────────────────────────────────────────────
# Model 3: Statistical Z-Score (25% weight)
# ─────────────────────────────────────────────

def predict_statistical(X: np.ndarray) -> np.ndarray:
    logger.info("Running Statistical Anomaly Detection...")
    mean = np.mean(X, axis=0)
    std  = np.std(X,  axis=0) + 1e-10
    z_scores     = np.abs((X - mean) / std)
    max_z_scores = np.max(z_scores, axis=1)
    scores = (max_z_scores - max_z_scores.min()) / (max_z_scores.max() - max_z_scores.min() + 1e-10)
    return scores


# ─────────────────────────────────────────────
# Scaler
# ─────────────────────────────────────────────

def train_scaler(X: np.ndarray) -> StandardScaler:
    scaler = StandardScaler()
    scaler.fit(X)
    joblib.dump(scaler, SCALER_PATH)
    logger.info(f"Scaler saved → {SCALER_PATH}")
    return scaler


def load_scaler():
    if os.path.exists(SCALER_PATH):
        return joblib.load(SCALER_PATH)
    return None
