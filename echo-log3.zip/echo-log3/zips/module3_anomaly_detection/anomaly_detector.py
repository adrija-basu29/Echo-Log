# anomaly_detector.py
# Main pipeline connecting all components

import os
import json
import numpy as np
from loguru import logger
from feature_engineer import engineer_features
from models import (
    train_isolation_forest, load_isolation_forest,
    predict_isolation_forest, predict_lof,
    predict_statistical, train_scaler, load_scaler
)
from scorer import build_anomaly_results
from reporter import build_full_report

FEEDBACK_FILE = "saved_models/feedback_data.json"


# ─────────────────────────────────────────────
# Feedback System
# ─────────────────────────────────────────────

def save_feedback(entry: dict, confirmed_anomaly: bool):
    """Save confirmed anomaly/normal for future retraining."""
    if os.path.exists(FEEDBACK_FILE):
        with open(FEEDBACK_FILE, "r") as f:
            feedback = json.load(f)
    else:
        feedback = {"anomalies": [], "normals": []}

    entry["confirmed_label"] = confirmed_anomaly

    if confirmed_anomaly:
        feedback["anomalies"].append(entry)
    else:
        feedback["normals"].append(entry)

    with open(FEEDBACK_FILE, "w") as f:
        json.dump(feedback, f, indent=2)

    logger.info(
        f"Feedback saved | Label: {'ANOMALY' if confirmed_anomaly else 'NORMAL'} | "
        f"Total: anomalies={len(feedback['anomalies'])}, normals={len(feedback['normals'])}"
    )


def load_feedback() -> dict:
    """Load all saved feedback data."""
    if os.path.exists(FEEDBACK_FILE):
        with open(FEEDBACK_FILE, "r") as f:
            return json.load(f)
    return {"anomalies": [], "normals": []}


# ─────────────────────────────────────────────
# Main Detection Pipeline
# ─────────────────────────────────────────────

def run_detection_pipeline(
    entries: list[dict],
    force_retrain: bool = False
) -> dict:
    """
    Full anomaly detection pipeline.
    Input  → Structured log entries from Module 2
    Output → Full anomaly report with scores + severity
    """
    logger.info(f"Starting detection pipeline on {len(entries)} entries...")

    # Step 1: Feature Engineering
    logger.info("Step 1: Engineering features...")
    feature_df   = engineer_features(entries)
    X            = feature_df.values
    feature_rows = feature_df.to_dict(orient="records")

    # Step 2: Scale Features
    logger.info("Step 2: Scaling features...")
    scaler = load_scaler()
    model_trained_fresh = False

    if scaler is None or force_retrain:
        scaler = train_scaler(X)
        model_trained_fresh = True

    X_scaled = scaler.transform(X)

    # Step 3: Isolation Forest
    logger.info("Step 3: Running Isolation Forest...")
    if_model = load_isolation_forest()

    if if_model is None or force_retrain:
        if_model = train_isolation_forest(X_scaled)
        model_trained_fresh = True

    if_scores = predict_isolation_forest(if_model, X_scaled)

    # Step 4: LOF
    logger.info("Step 4: Running Local Outlier Factor...")
    lof_scores = predict_lof(X_scaled)

    # Step 5: Statistical
    logger.info("Step 5: Running Statistical Detection...")
    stat_scores = predict_statistical(X_scaled)

    # Step 6: Score & Label
    logger.info("Step 6: Computing anomaly scores...")
    results = build_anomaly_results(
        entries=entries,
        if_scores=if_scores,
        lof_scores=lof_scores,
        stat_scores=stat_scores,
        feature_rows=feature_rows
    )

    # Step 7: Build Report
    logger.info("Step 7: Building report...")
    report = build_full_report(
        results=results,
        model_trained_fresh=model_trained_fresh,
        total_features=len(feature_df.columns)
    )

    logger.info("✅ Detection pipeline complete!")
    return report
