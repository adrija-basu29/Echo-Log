# feature_engineer.py
# Converts structured log entries into numerical features for ML
# Works for ALL 16 loghub log types + Apache access logs

import re
import pandas as pd
import numpy as np
from loguru import logger
from collections import Counter
from log_schemas import (
    ANOMALY_KEYWORDS, NORMAL_KEYWORDS,
    SECURITY_KEYWORDS, CONNECTION_KEYWORDS
)

# ─────────────────────────────────────────────
# Encoding Maps
# ─────────────────────────────────────────────

LEVEL_MAP = {
    "INFO": 1, "I": 1, "NOTICE": 1,
    "DEBUG": 0, "D": 0, "VERBOSE": 0, "V": 0,
    "WARNING": 2, "WARN": 2, "W": 2,
    "ERROR": 3, "E": 3,
    "CRITICAL": 4, "FATAL": 4, "F": 4,
    None: -1
}

METHOD_MAP = {
    "GET": 1, "POST": 2, "PUT": 3,
    "DELETE": 4, "PATCH": 5,
    "HEAD": 6, "OPTIONS": 7,
    None: -1
}

URL_SENSITIVITY = {
    "/usr/admin/developer": 10,
    "/usr/admin": 8,
    "/usr/login": 5,
    "/usr/register": 3,
    "/usr": 1,
}

SENSITIVE_COMPONENTS = [
    "admin", "root", "auth", "security", "kernel",
    "ssh", "sudo", "cron", "firewall", "iptables"
]


def encode_level(level: str) -> int:
    return LEVEL_MAP.get(str(level).upper().strip() if level else None, 1)


def encode_method(message: str) -> int:
    if not message:
        return -1
    for method in METHOD_MAP:
        if method and message.startswith(method):
            return METHOD_MAP[method]
    return -1


def extract_status_code(message: str) -> int:
    match = re.search(r'→\s*(\d{3})', message)
    if match:
        return int(match.group(1))
    match = re.search(r'\b([2-5]\d{2})\b', message)
    if match:
        return int(match.group(1))
    return -1


def extract_response_size(message: str) -> int:
    match = re.search(r'\((\d+)\s*bytes\)', message)
    if match:
        return int(match.group(1))
    numbers = re.findall(r'\b(\d+)\b', message)
    if len(numbers) >= 2:
        return int(numbers[-2])
    return 0


def extract_response_time(raw_text: str) -> int:
    numbers = re.findall(r'\b(\d+)\b', raw_text)
    if numbers:
        return int(numbers[-1])
    return 0


def extract_url_sensitivity(message: str) -> int:
    for url, score in URL_SENSITIVITY.items():
        if url in message:
            return score
    return 0


def extract_ip(service: str) -> str:
    if not service:
        return "unknown"
    match = re.search(r'\[(\d+\.\d+\.\d+\.\d+)\]', service)
    if match:
        return match.group(1)
    return "unknown"


def is_admin_endpoint(message: str) -> int:
    keywords = ["/admin", "/developer", "/root", "/superuser"]
    return int(any(k in message.lower() for k in keywords))


def is_dangerous_method_on_admin(message: str) -> int:
    dangerous = ["DELETE /usr/admin", "PUT /usr/admin", "DELETE /usr/login"]
    return int(any(p in message for p in dangerous))


def is_sensitive_component(component: str) -> int:
    if not component:
        return 0
    return int(any(s in component.lower() for s in SENSITIVE_COMPONENTS))


def compute_ip_frequency(entries: list) -> dict:
    ip_counts = Counter()
    for entry in entries:
        ip = extract_ip(entry.get("service", ""))
        if ip != "unknown":
            ip_counts[ip] += 1
    return dict(ip_counts)


def engineer_features(entries: list[dict]) -> pd.DataFrame:
    """
    Main feature engineering function.
    Works for ALL log types — Apache access logs + all 16 loghub types.
    Produces a 25-feature matrix per entry.
    """
    logger.info(f"Engineering features for {len(entries)} log entries...")

    ip_freq = compute_ip_frequency(entries)

    # Calculate high frequency threshold dynamically
    if ip_freq:
        freq_values = list(ip_freq.values())
        high_threshold = max(5, np.mean(freq_values) * 2)
    else:
        high_threshold = 5

    rows = []

    for entry in entries:
        # Use pre-computed features if available (from trainer.py)
        if "_features" in entry and entry["_features"]:
            pre = entry["_features"]
            ip = extract_ip(entry.get("service", ""))
            freq = ip_freq.get(ip, 1)
            pre["ip_frequency"] = freq
            pre["ip_is_high_frequency"] = int(freq > high_threshold)
            rows.append(pre)
            continue

        # Otherwise compute from scratch
        message   = entry.get("message", "")
        raw_text  = entry.get("raw_text", "")
        service   = entry.get("service", "")
        level     = entry.get("level", None)
        component = service.split("[")[0].strip() if service else ""
        content_lower = message.lower()

        status_code   = extract_status_code(message)
        response_size = extract_response_size(message)
        response_time = extract_response_time(raw_text)
        ip            = extract_ip(service)
        ip_frequency  = ip_freq.get(ip, 1)

        row = {
            # Level features
            "level_encoded": encode_level(level),
            "is_error":      int(entry.get("is_error",   False)),
            "is_warning":    int(entry.get("is_warning", False)),

            # Universal keyword features
            "has_anomaly_keyword":    int(any(w in content_lower for w in ANOMALY_KEYWORDS)),
            "has_normal_keyword":     int(any(w in content_lower for w in NORMAL_KEYWORDS)),
            "has_security_keyword":   int(any(w in content_lower for w in SECURITY_KEYWORDS)),
            "has_connection_keyword": int(any(w in content_lower for w in CONNECTION_KEYWORDS)),

            # HTTP features
            "method_encoded": encode_method(message),
            "status_code":    status_code if status_code > 0 else 0,
            "status_4xx":     int(400 <= status_code < 500) if status_code > 0 else 0,
            "status_5xx":     int(status_code >= 500)       if status_code > 0 else 0,
            "status_403":     int(status_code == 403),
            "status_404":     int(status_code == 404),
            "status_500":     int(status_code == 500),
            "status_502":     int(status_code == 502),

            # Endpoint features
            "url_sensitivity":          extract_url_sensitivity(message),
            "is_admin_endpoint":        is_admin_endpoint(message),
            "dangerous_method_on_admin": is_dangerous_method_on_admin(message),

            # Size & Time features
            "response_size": response_size,
            "response_time": response_time,
            "message_length": len(message),

            # Component features
            "is_sensitive_component": is_sensitive_component(component),

            # IP behavior features
            "ip_frequency":         ip_frequency,
            "ip_is_high_frequency": int(ip_frequency > high_threshold),
        }

        rows.append(row)

    df = pd.DataFrame(rows).fillna(0)
    logger.info(f"Feature matrix: {df.shape[0]} rows × {df.shape[1]} features")
    return df
