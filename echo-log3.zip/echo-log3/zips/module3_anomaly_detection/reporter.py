# reporter.py
# Builds the final comprehensive anomaly report

import re
from loguru import logger


def build_full_report(
    results: list[dict],
    model_trained_fresh: bool,
    total_features: int
) -> dict:

    total     = len(results)
    anomalies = [r for r in results if r["is_anomaly"]]
    normal    = [r for r in results if not r["is_anomaly"]]

    critical = [r for r in results if r["severity"] == "CRITICAL"]
    high     = [r for r in results if r["severity"] == "HIGH"]
    medium   = [r for r in results if r["severity"] == "MEDIUM"]
    low      = [r for r in results if r["severity"] == "LOW"]

    all_reasons = []
    for r in results:
        all_reasons.extend(r.get("anomaly_reasons", []))

    high_error_rate = any("Server error"        in r for r in all_reasons)
    unauthorized    = any("Unauthorized"         in r for r in all_reasons)
    unusual_methods = any("Dangerous HTTP method" in r for r in all_reasons)
    ip_abuse        = any("High request frequency" in r for r in all_reasons)
    time_spike      = any("response time"        in r for r in all_reasons)

    # Top suspicious IPs
    ip_scores = {}
    for r in results:
        raw = r.get("raw_text", "")
        ip_match = re.match(r'(\d+\.\d+\.\d+\.\d+)', raw)
        if ip_match:
            ip = ip_match.group(1)
            if ip not in ip_scores:
                ip_scores[ip] = {
                    "ip": ip,
                    "max_score": 0,
                    "request_count": 0,
                    "anomaly_count": 0
                }
            ip_scores[ip]["request_count"] += 1
            ip_scores[ip]["max_score"] = max(ip_scores[ip]["max_score"], r["anomaly_score"])
            if r["is_anomaly"]:
                ip_scores[ip]["anomaly_count"] += 1

    top_ips = sorted(
        ip_scores.values(),
        key=lambda x: (x["anomaly_count"], x["max_score"]),
        reverse=True
    )[:10]

    anomaly_pct = round(len(anomalies) / total * 100, 2) if total > 0 else 0

    logger.info(
        f"Report | Total: {total} | Anomalies: {len(anomalies)} "
        f"({anomaly_pct}%) | Critical: {len(critical)} | High: {len(high)}"
    )

    return {
        "total_entries":    total,
        "anomaly_count":    len(anomalies),
        "normal_count":     len(normal),
        "anomaly_percentage": anomaly_pct,

        "critical_count": len(critical),
        "high_count":     len(high),
        "medium_count":   len(medium),
        "low_count":      len(low),

        "high_error_rate_detected":     high_error_rate,
        "unauthorized_access_detected": unauthorized,
        "unusual_methods_detected":     unusual_methods,
        "ip_abuse_detected":            ip_abuse,
        "response_time_spike_detected": time_spike,

        "top_suspicious_ips": top_ips,
        "results":            results,
        "model_trained_fresh": model_trained_fresh,
        "total_features_used": total_features,
    }
