# main.py — Module 5: Escalation & Auto-Remediation Engine
# Port: 8004

import os
import uvicorn
from fastapi import FastAPI
from loguru import logger
from routes import router

app = FastAPI(
    title="Echo-Log — Escalation & Auto-Remediation API",
    description="""
    ## Module 5: Escalation & Auto-Remediation Engine

    Receives RCA results from Module 4 and takes action:

    | Decision     | What happens                                      |
    |--------------|---------------------------------------------------|
    | AUTO_FIX     | Runs a safe recovery script automatically         |
    | RESCALE      | Expands disk/memory/CPU (or generates commands)   |
    | ESCALATE     | Flags for human engineer — too risky to auto-fix  |
    | MONITOR      | Logs and watches — low severity, no action yet    |

    ### Auto-Fix Scripts Available:
    - `cleanup_storage` — deletes old logs and temp files
    - `restart_service` — restarts a crashed service
    - `restart_heavy_processes` — kills top memory consumers
    - `restart_network_services` — restarts Zookeeper / Kafka

    ### Rescaling:
    - `disk` — generates cloud commands to expand volume
    - `memory` — adds swap immediately + cloud upgrade commands
    - `cpu` — generates cloud commands to upgrade instance type

    ### Safety:
    - All scripts are whitelisted — cannot run arbitrary commands
    - Dry-run mode available for testing
    - Every action is logged to `logs/remediation_history.json`
    """,
    version="1.0.0"
)

os.makedirs("logs", exist_ok=True)
logger.add(
    "logs/escalation.log",
    rotation="10 MB",
    retention="7 days",
    level="INFO",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}"
)

app.include_router(router, prefix="/api/v5")


@app.get("/")
async def root():
    return {
        "project": "Echo-Log",
        "module":  "Module 5 — Escalation & Auto-Remediation",
        "port":    8004,
        "status":  "running",
        "routes": {
            "POST /api/v5/escalate":        "Escalate from Module 4 RCA report",
            "POST /api/v5/full-pipeline":   "Full chain: logs → M3 → M4 → M5",
            "POST /api/v5/decide-only":     "Preview decisions without executing",
            "POST /api/v5/manual-fix":      "Manually trigger an auto-fix",
            "POST /api/v5/manual-rescale":  "Manually trigger rescale",
            "GET  /api/v5/system-metrics":  "Current CPU / RAM / Disk usage",
            "GET  /api/v5/history":         "History of all actions taken",
            "GET  /api/v5/health":          "Health check",
        },
        "docs": "Visit /docs for interactive API documentation"
    }


if __name__ == "__main__":
    logger.info("🚀 Starting Echo-Log Escalation & Auto-Remediation Server on port 8004...")
    uvicorn.run("main:app", host="0.0.0.0", port=8004, reload=False)
