# routes.py — Module 6 Dashboard API + page routes

import json
import requests
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from loguru import logger
from dashboard_data import (
    get_dashboard_summary, get_recent_alerts, get_alert_batches,
    get_system_metrics, get_module_health, get_rca_rules_count,
    get_remediation_history, load_alert_history,
)

router    = APIRouter()
templates = Jinja2Templates(directory="templates")

M3 = "http://localhost:8002/api/v3"
M4 = "http://localhost:8003/api/v4"
M5 = "http://localhost:8004/api/v5"


# ── Page Routes ───────────────────────────────────────────────────────────────

@router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    """Main dashboard page."""
    summary    = get_dashboard_summary()
    metrics    = get_system_metrics()
    health     = get_module_health()
    recent     = get_recent_alerts(limit=20)
    remediation = get_remediation_history(limit=8)
    rules_count = get_rca_rules_count()

    return templates.TemplateResponse("dashboard.html", {
        "request":     request,
        "summary":     summary,
        "metrics":     metrics,
        "health":      health,
        "recent":      recent,
        "remediation": remediation,
        "rules_count": rules_count,
    })


@router.get("/alerts", response_class=HTMLResponse)
async def alerts_page(request: Request):
    """Full alert history page."""
    batches = get_alert_batches(limit=30)
    return templates.TemplateResponse("alerts.html", {
        "request": request,
        "batches": batches,
    })


@router.get("/run", response_class=HTMLResponse)
async def run_page(request: Request):
    """Live pipeline runner page — upload logs and run the full pipeline."""
    return templates.TemplateResponse("run.html", {"request": request})


# ── JSON API Routes (for live dashboard refresh) ──────────────────────────────

@router.get("/api/summary")
async def api_summary():
    return get_dashboard_summary()


@router.get("/api/alerts")
async def api_alerts(limit: int = 50):
    return {"alerts": get_recent_alerts(limit=limit)}


@router.get("/api/metrics")
async def api_metrics():
    return {
        "system":  get_system_metrics(),
        "health":  get_module_health(),
    }


@router.get("/api/batches")
async def api_batches(limit: int = 20):
    return {"batches": get_alert_batches(limit=limit)}


@router.post("/api/run-pipeline")
async def run_pipeline(payload: dict):
    """
    Proxy: forward log entries to M5 full-pipeline and return results.
    Called by the Run page via JS fetch.
    """
    try:
        r = requests.post(f"{M5}/full-pipeline", json=payload, timeout=300)
        if r.status_code != 200:
            raise HTTPException(status_code=502, detail=r.text[:400])
        return r.json()
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="Module 5 is not running (port 8004).")


@router.get("/api/health")
async def api_health():
    return {
        "status": "online",
        "port":   8005,
        "modules": get_module_health(),
    }
