# evaluator.py
# Generates performance metrics and graphs after ML detection

import os
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from loguru import logger

GRAPHS_DIR = "performance_graphs"
os.makedirs(GRAPHS_DIR, exist_ok=True)


# ─────────────────────────────────────────────
# Graph 1: Anomaly Score Distribution
# ─────────────────────────────────────────────

def plot_score_distribution(results: list[dict]) -> str:
    scores  = [r["anomaly_score"] for r in results]
    labels  = ["Anomaly" if r["is_anomaly"] else "Normal" for r in results]
    normal_scores   = [s for s, l in zip(scores, labels) if l == "Normal"]
    anomaly_scores  = [s for s, l in zip(scores, labels) if l == "Anomaly"]

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.hist(normal_scores,  bins=30, alpha=0.7, color="#2ecc71", label="Normal",  edgecolor="white")
    ax.hist(anomaly_scores, bins=30, alpha=0.7, color="#e74c3c", label="Anomaly", edgecolor="white")
    ax.axvline(x=30, color="orange", linestyle="--", linewidth=2, label="Threshold (30)")
    ax.set_xlabel("Anomaly Score", fontsize=12)
    ax.set_ylabel("Number of Log Entries", fontsize=12)
    ax.set_title("Anomaly Score Distribution", fontsize=14, fontweight="bold")
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)

    path = os.path.join(GRAPHS_DIR, "1_score_distribution.png")
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()
    logger.info(f"Saved: {path}")
    return path


# ─────────────────────────────────────────────
# Graph 2: Severity Breakdown Pie Chart
# ─────────────────────────────────────────────

def plot_severity_breakdown(report: dict) -> str:
    labels  = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "NORMAL"]
    sizes   = [
        report.get("critical_count", 0),
        report.get("high_count",     0),
        report.get("medium_count",   0),
        report.get("low_count",      0),
        report.get("normal_count",   0),
    ]
    colors  = ["#c0392b", "#e74c3c", "#f39c12", "#f1c40f", "#2ecc71"]
    explode = (0.1, 0.05, 0, 0, 0)

    filtered = [(l, s, c, e) for l, s, c, e in zip(labels, sizes, colors, explode) if s > 0]
    if not filtered:
        return None
    labels, sizes, colors, explode = zip(*filtered)

    fig, ax = plt.subplots(figsize=(8, 8))
    _, _, autotexts = ax.pie(
        sizes, labels=labels, colors=colors, explode=explode,
        autopct="%1.1f%%", startangle=140, textprops={"fontsize": 12}
    )
    for at in autotexts:
        at.set_fontweight("bold")
    ax.set_title("Severity Level Breakdown", fontsize=14, fontweight="bold")

    path = os.path.join(GRAPHS_DIR, "2_severity_breakdown.png")
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()
    logger.info(f"Saved: {path}")
    return path


# ─────────────────────────────────────────────
# Graph 3: Model Score Comparison
# ─────────────────────────────────────────────

def plot_model_comparison(results: list[dict]) -> str:
    normal    = [r for r in results if not r["is_anomaly"]]
    anomalous = [r for r in results if r["is_anomaly"]]

    models = ["Isolation Forest", "LOF", "Statistical"]
    keys   = ["isolation_forest_score", "lof_score", "statistical_score"]

    normal_avgs  = [np.mean([r[k] for r in normal])    if normal    else 0 for k in keys]
    anomaly_avgs = [np.mean([r[k] for r in anomalous]) if anomalous else 0 for k in keys]

    x     = np.arange(len(models))
    width = 0.35

    fig, ax = plt.subplots(figsize=(10, 6))
    bars1 = ax.bar(x - width/2, normal_avgs,  width, label="Normal",  color="#2ecc71", edgecolor="white")
    bars2 = ax.bar(x + width/2, anomaly_avgs, width, label="Anomaly", color="#e74c3c", edgecolor="white")

    ax.set_xlabel("ML Model", fontsize=12)
    ax.set_ylabel("Average Score", fontsize=12)
    ax.set_title("Model Score Comparison: Normal vs Anomaly", fontsize=14, fontweight="bold")
    ax.set_xticks(x)
    ax.set_xticklabels(models, fontsize=11)
    ax.legend(fontsize=11)
    ax.grid(True, axis="y", alpha=0.3)
    ax.set_ylim(0, 100)

    for bar in list(bars1) + list(bars2):
        height = bar.get_height()
        ax.annotate(
            f"{height:.1f}",
            xy=(bar.get_x() + bar.get_width() / 2, height),
            xytext=(0, 3), textcoords="offset points",
            ha="center", fontsize=9
        )

    path = os.path.join(GRAPHS_DIR, "3_model_comparison.png")
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()
    logger.info(f"Saved: {path}")
    return path


# ─────────────────────────────────────────────
# Graph 4: Top Suspicious IPs
# ─────────────────────────────────────────────

def plot_top_suspicious_ips(report: dict) -> str:
    top_ips = report.get("top_suspicious_ips", [])
    if not top_ips:
        return None

    ips    = [e["ip"]        for e in top_ips[:10]]
    scores = [e["max_score"] for e in top_ips[:10]]
    counts = [e["anomaly_count"] for e in top_ips[:10]]
    colors = ["#c0392b" if s >= 85 else "#e74c3c" if s >= 70 else "#f39c12" for s in scores]

    fig, ax = plt.subplots(figsize=(10, 6))
    bars = ax.barh(ips, scores, color=colors, edgecolor="white")
    ax.set_xlabel("Max Anomaly Score", fontsize=12)
    ax.set_title("Top Suspicious IP Addresses", fontsize=14, fontweight="bold")
    ax.set_xlim(0, 100)
    ax.axvline(x=85, color="#c0392b", linestyle="--", alpha=0.7, label="Critical (85)")
    ax.axvline(x=70, color="#e74c3c", linestyle="--", alpha=0.7, label="High (70)")
    ax.legend(fontsize=10)
    ax.grid(True, axis="x", alpha=0.3)

    for bar, count in zip(bars, counts):
        ax.text(
            bar.get_width() + 0.5,
            bar.get_y() + bar.get_height() / 2,
            f"{count} anomalies",
            va="center", fontsize=9
        )

    path = os.path.join(GRAPHS_DIR, "4_suspicious_ips.png")
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()
    logger.info(f"Saved: {path}")
    return path


# ─────────────────────────────────────────────
# Graph 5: Anomaly Types Detected
# ─────────────────────────────────────────────

def plot_anomaly_types(report: dict) -> str:
    anomaly_types = {
        "High Error Rate\n(5xx)":          report.get("high_error_rate_detected",      False),
        "Unauthorized\nAccess (403)":       report.get("unauthorized_access_detected",  False),
        "Unusual Methods\n(DELETE/PUT)":    report.get("unusual_methods_detected",      False),
        "IP Abuse\n(High Frequency)":       report.get("ip_abuse_detected",             False),
        "Response Time\nSpikes":            report.get("response_time_spike_detected",  False),
    }

    labels   = list(anomaly_types.keys())
    detected = [1 if v else 0 for v in anomaly_types.values()]
    colors   = ["#e74c3c" if d else "#95a5a6" for d in detected]

    fig, ax = plt.subplots(figsize=(10, 5))
    bars = ax.bar(labels, detected, color=colors, edgecolor="white", width=0.5)
    ax.set_ylabel("Detected (1=Yes, 0=No)", fontsize=12)
    ax.set_title("Anomaly Types Detected", fontsize=14, fontweight="bold")
    ax.set_ylim(0, 1.5)
    ax.set_yticks([0, 1])
    ax.set_yticklabels(["Not Detected", "Detected"])
    ax.grid(True, axis="y", alpha=0.3)

    for bar, d in zip(bars, detected):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.05,
            "✓ YES" if d else "✗ NO",
            ha="center", fontsize=11, fontweight="bold",
            color="#e74c3c" if d else "#95a5a6"
        )

    path = os.path.join(GRAPHS_DIR, "5_anomaly_types.png")
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()
    logger.info(f"Saved: {path}")
    return path


# ─────────────────────────────────────────────
# Graph 6: Score Timeline (Heartbeat Monitor)
# ─────────────────────────────────────────────

def plot_score_timeline(results: list[dict]) -> str:
    line_numbers = [r["line_number"]   for r in results]
    scores       = [r["anomaly_score"] for r in results]

    fig, ax = plt.subplots(figsize=(14, 5))
    ax.plot(line_numbers, scores, color="#3498db", linewidth=0.8, alpha=0.7, label="Anomaly Score")
    ax.fill_between(
        line_numbers, scores, 30,
        where=[s > 30 for s in scores],
        alpha=0.3, color="#e74c3c", label="Anomalous Zone"
    )

    critical_lines  = [r["line_number"]   for r in results if r["severity"] == "CRITICAL"]
    critical_scores = [r["anomaly_score"] for r in results if r["severity"] == "CRITICAL"]
    if critical_lines:
        ax.scatter(critical_lines, critical_scores, color="#c0392b", s=50, zorder=5, label="CRITICAL")

    ax.axhline(y=30, color="orange",   linestyle="--", linewidth=1.5, label="Threshold (30)")
    ax.axhline(y=70, color="#e74c3c",  linestyle="--", linewidth=1.5, alpha=0.7, label="High (70)")
    ax.axhline(y=85, color="#c0392b",  linestyle="--", linewidth=1.5, alpha=0.7, label="Critical (85)")

    ax.set_xlabel("Log Line Number", fontsize=12)
    ax.set_ylabel("Anomaly Score",   fontsize=12)
    ax.set_title("Anomaly Score Timeline — Log Entry Analysis", fontsize=14, fontweight="bold")
    ax.legend(fontsize=9, loc="upper right")
    ax.set_ylim(0, 105)
    ax.grid(True, alpha=0.3)

    path = os.path.join(GRAPHS_DIR, "6_score_timeline.png")
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()
    logger.info(f"Saved: {path}")
    return path


# ─────────────────────────────────────────────
# Graph 7: Training Data Breakdown
# ─────────────────────────────────────────────

def plot_training_breakdown() -> str:
    metadata_path = "saved_models/training_metadata.json"
    if not os.path.exists(metadata_path):
        return None

    with open(metadata_path, "r") as f:
        metadata = json.load(f)

    breakdown = metadata.get("log_type_breakdown", {})
    if not breakdown:
        return None

    log_types = list(breakdown.keys())
    counts    = list(breakdown.values())
    colors    = plt.cm.Set3(np.linspace(0, 1, len(log_types)))

    fig, ax = plt.subplots(figsize=(12, 6))
    bars = ax.bar(log_types, counts, color=colors, edgecolor="white")
    ax.set_xlabel("Log Type", fontsize=12)
    ax.set_ylabel("Training Entries", fontsize=12)
    ax.set_title("Training Data Breakdown by Log Type", fontsize=14, fontweight="bold")
    ax.tick_params(axis="x", rotation=45)
    ax.grid(True, axis="y", alpha=0.3)

    for bar, count in zip(bars, counts):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 10,
            str(count), ha="center", fontsize=9
        )

    path = os.path.join(GRAPHS_DIR, "7_training_breakdown.png")
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()
    logger.info(f"Saved: {path}")
    return path


# ─────────────────────────────────────────────
# Performance Metrics Calculator
# ─────────────────────────────────────────────

def calculate_metrics(results: list[dict]) -> dict:
    scores     = np.array([r["anomaly_score"] for r in results])
    is_anomaly = np.array([r["is_anomaly"]    for r in results])

    total     = len(results)
    anomalies = int(np.sum(is_anomaly))
    normals   = total - anomalies

    avg_score         = float(np.mean(scores))
    avg_anomaly_score = float(np.mean(scores[is_anomaly]))  if anomalies > 0 else 0
    avg_normal_score  = float(np.mean(scores[~is_anomaly])) if normals   > 0 else 0
    separation        = avg_anomaly_score - avg_normal_score

    if separation >= 40:   separation_quality = "🌟 Excellent"
    elif separation >= 25: separation_quality = "🟢 Good"
    elif separation >= 15: separation_quality = "🟡 Fair"
    else:                  separation_quality = "🔴 Poor — need more training data"

    severity_counts = {}
    for r in results:
        sev = r["severity"]
        severity_counts[sev] = severity_counts.get(sev, 0) + 1

    return {
        "total_entries":      total,
        "anomaly_count":      anomalies,
        "normal_count":       normals,
        "anomaly_rate":       round(anomalies / total * 100, 2) if total > 0 else 0,

        "avg_anomaly_score":  round(avg_anomaly_score, 2),
        "avg_normal_score":   round(avg_normal_score,  2),
        "avg_overall_score":  round(avg_score,         2),
        "score_std_dev":      round(float(np.std(scores)), 2),
        "score_separation":   round(separation, 2),
        "separation_quality": separation_quality,

        "severity_breakdown": severity_counts,

        "model_components": {
            "isolation_forest_weight": "40%",
            "lof_weight":              "35%",
            "statistical_weight":      "25%"
        }
    }


# ─────────────────────────────────────────────
# Master Evaluation Function
# ─────────────────────────────────────────────

def generate_full_evaluation(report: dict) -> dict:
    """Generates ALL 7 graphs + performance metrics."""
    results = report.get("results", [])
    if not results:
        return {"error": "No results to evaluate"}

    logger.info("Generating full performance evaluation...")

    graph_paths = {}
    graph_paths["score_distribution"] = plot_score_distribution(results)
    graph_paths["severity_breakdown"]  = plot_severity_breakdown(report)
    graph_paths["model_comparison"]    = plot_model_comparison(results)
    graph_paths["suspicious_ips"]      = plot_top_suspicious_ips(report)
    graph_paths["anomaly_types"]       = plot_anomaly_types(report)
    graph_paths["score_timeline"]      = plot_score_timeline(results)
    graph_paths["training_breakdown"]  = plot_training_breakdown()

    graph_paths = {k: v for k, v in graph_paths.items() if v}

    metrics = calculate_metrics(results)

    metrics_path = os.path.join(GRAPHS_DIR, "performance_metrics.json")
    with open(metrics_path, "w") as f:
        json.dump(metrics, f, indent=2)

    logger.info(f"✅ Generated {len(graph_paths)} graphs")
    logger.info(f"Separation quality: {metrics['separation_quality']}")

    return {
        "metrics":          metrics,
        "graphs_generated": len(graph_paths),
        "graph_paths":      graph_paths,
        "metrics_path":     metrics_path
    }
