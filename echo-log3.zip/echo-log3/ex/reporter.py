# reporter.py
# ALL 5 anomaly types always shown with counts + evidence
# Analysed all 16 loghub log formats to build this properly
#
# Log format analysis:
# Apache     → [date] [level] message (error log) OR ip - - [date] "METHOD URL" status size (access log)
# OpenSSH    → date host sshd[pid]: message (with IPs in "from IP" pattern)
# Linux      → date host process[pid]: message
# Hadoop     → date time level class: message (job_ID, task_ID patterns)
# HDFS       → date time level class: message (blk_ID, DataNode patterns)
# Spark      → date time level class: message (executor, stage, RDD patterns)
# Zookeeper  → date time level class@host: message
# BGL        → date time node nodeID kernel: FATAL/ERROR message
# HPC        → logID node cpu message
# Thunderbird→ timestamp node nodeID process: message
# Windows    → date time level source EventID message
# Android    → date time priority/tag(pid): message
# HealthApp  → date time component: message
# Mac        → date host process[pid]: message
# Proxifier  → date time process.exe - message (CONNECT/CLOSE/ERROR)
# OpenStack  → date time pid level component [reqID]: message

import re
from collections import Counter, defaultdict
from loguru import logger


# ─────────────────────────────────────────────────────────────────────────────
# PER-LOG-TYPE ANOMALY DEFINITIONS
# Each log type has its own definition of all 5 anomaly types
# ─────────────────────────────────────────────────────────────────────────────

LOG_TYPE_ANOMALY_DEFS = {

    "Apache": {
        "high_error_rate": [
            r"\[error\]", r"\[crit\]", r"\[alert\]", r"\[emerg\]",
            r"http [45]\d\d", r" 5\d\d ", r"mod_jk.*error",
            r"worker.*error", r"child.*exit", r"segfault",
        ],
        "unauthorized_access": [
            r" 403 ", r"forbidden", r"access denied",
            r"authentication required", r"invalid password",
            r" 401 ", r"unauthorized",
        ],
        "unusual_operations": [
            r'"delete ', r'"put ', r'"patch ',
            r"delete /usr", r"put /usr",
            r"cannot bind", r"bind failed",
            r"child.*killed", r"worker.*killed",
        ],
        "repeated_abuse": [
            r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}",  # IP present → count frequency
        ],
        "performance_issues": [
            r"timeout", r"timed out", r"slow",
            r"request.*time", r"connection.*reset",
        ],
    },

    "OpenSSH": {
        "high_error_rate": [
            r"error", r"failed", r"failure",
            r"fatal", r"invalid", r"illegal",
            r"refused", r"disconnect.*error",
        ],
        "unauthorized_access": [
            r"failed password", r"failed publickey",
            r"invalid user", r"illegal user",
            r"authentication failure", r"auth.*fail",
            r"too many authentication",
            r"possible break-in", r"break.in attempt",
            r"did not receive identification",
            r"bad protocol", r"protocol error",
        ],
        "unusual_operations": [
            r"reverse mapping.*failed",
            r"address.*not.*associated",
            r"rsa key.*warning",
            r"opened.*for.*root",
            r"preauth",
            r"disconnecting.*preauth",
            r"bad packet",
        ],
        "repeated_abuse": [
            r"from \d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}",  # "from IP" pattern
            r"failed password.*from",
            r"invalid user.*from",
        ],
        "performance_issues": [
            r"timeout", r"timed out",
            r"connection.*closed", r"connection.*reset",
            r"did not receive",
        ],
    },

    "Hadoop": {
        "high_error_rate": [
            r"error", r"exception", r"failed", r"failure",
            r"fatal", r"warn",
            r"task.*failed", r"job.*failed",
            r"attempt.*failed", r"reduce.*failed",
            r"map.*failed",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"unauthorized", r"authentication.*fail",
            r"security.*exception",
        ],
        "unusual_operations": [
            r"killed", r"blacklisted",
            r"lost.*tracker", r"tracker.*lost",
            r"outofmemory", r"out of memory",
            r"heartbeat.*miss", r"miss.*heartbeat",
            r"node.*blacklisted",
        ],
        "repeated_abuse": [
            r"attempt_\w+",         # repeated task attempts
            r"task.*retry",
            r"job.*retry",
            r"failed.*attempt",
        ],
        "performance_issues": [
            r"timeout", r"timed out", r"slow",
            r"waiting", r"stalled",
            r"gc.*overhead", r"garbage.*collection",
        ],
    },

    "HDFS": {
        "high_error_rate": [
            r"error", r"exception", r"failed", r"failure",
            r"warn", r"ioexception",
            r"corrupt", r"corrupted",
            r"block.*lost", r"lost.*block",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"unauthorized", r"security.*exception",
        ],
        "unusual_operations": [
            r"corrupt", r"corrupted",
            r"replicat.*fail", r"under.replicated",
            r"missing.*block", r"block.*missing",
            r"checksum.*error", r"crc.*error",
            r"disk.*fail", r"disk.*full",
            r"no.*space", r"quota.*exceed",
        ],
        "repeated_abuse": [
            r"blk_-?\d+",           # repeated block IDs
            r"datanode.*fail",
            r"failed.*connect",
            r"connect.*fail",
        ],
        "performance_issues": [
            r"timeout", r"timed out", r"slow",
            r"waiting.*replication",
            r"decommission",
            r"balancer",
        ],
    },

    "Spark": {
        "high_error_rate": [
            r"error", r"exception", r"failed", r"failure",
            r"fatal", r"warn",
            r"executorlost", r"executor.*lost",
            r"stage.*failed", r"task.*failed",
            r"job.*failed", r"job.*aborted",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"unauthorized", r"authentication.*fail",
        ],
        "unusual_operations": [
            r"outofmemory", r"out of memory",
            r"gc.*overhead", r"heap.*space",
            r"executorlost", r"executor.*lost",
            r"driver.*stopped", r"driver.*exit",
            r"fetchfailed", r"shuffle.*fail",
            r"broadcast.*timeout",
        ],
        "repeated_abuse": [
            r"attempt.*\d+",        # repeated attempts
            r"retry.*\d+",
            r"task.*retry",
            r"executor.*\d+.*lost", # same executor failing
        ],
        "performance_issues": [
            r"timeout", r"timed out", r"slow",
            r"gc.*pause", r"straggler",
            r"speculative.*task",
            r"waiting.*resource",
        ],
    },

    "Zookeeper": {
        "high_error_rate": [
            r"error", r"exception", r"failed", r"failure",
            r"warn", r"fatal",
            r"connectionloss", r"session.*expired",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"auth.*fail", r"authentication.*fail",
            r"invalid.*acl",
        ],
        "unusual_operations": [
            r"leader.*election", r"new.*leader",
            r"quorum.*lost", r"not.*enough.*participants",
            r"unable.*read", r"read.*fail",
            r"snap.*corrupt", r"log.*corrupt",
        ],
        "repeated_abuse": [
            r"session.*timeout",    # repeated session timeouts
            r"connectionloss",
            r"client.*disconnect",
            r"too.*many.*connect",
        ],
        "performance_issues": [
            r"timeout", r"timed out",
            r"session.*timeout", r"connection.*timeout",
            r"high.*latency", r"slow.*request",
            r"fsync.*threshold",
        ],
    },

    "BGL": {
        "high_error_rate": [
            r"error", r"fatal", r"failure", r"failed",
            r"severe", r"critical",
            r"hardware.*error", r"machine.*check",
            r"rts.*error", r"ciod.*error",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"authentication.*fail", r"unauthorized",
        ],
        "unusual_operations": [
            r"machine check", r"mce",
            r"hardware.*error", r"hardware.*failure",
            r"memory.*error", r"ecc.*error",
            r"cpu.*error", r"processor.*error",
            r"kernel.*panic", r"panic",
            r"node.*fail", r"node.*down",
            r"fatal",
        ],
        "repeated_abuse": [
            r"node.*\w+.*error",    # same node repeated errors
            r"repeated.*error",
            r"R\d{2}-M\d-N\d+",    # BGL node ID patterns
        ],
        "performance_issues": [
            r"timeout", r"timed out", r"slow",
            r"network.*error", r"link.*error",
            r"latency", r"congestion",
        ],
    },

    "HPC": {
        "high_error_rate": [
            r"error", r"failed", r"failure", r"fatal",
            r"warn", r"exception",
            r"job.*fail", r"node.*fail",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"authentication.*fail", r"unauthorized",
            r"account.*locked",
        ],
        "unusual_operations": [
            r"node.*down", r"node.*fail",
            r"memory.*error", r"cpu.*error",
            r"mpi.*error", r"mpi.*abort",
            r"scheduler.*error", r"queue.*error",
            r"job.*cancel", r"job.*kill",
        ],
        "repeated_abuse": [
            r"job.*retry", r"requeue",
            r"node.*repeated.*fail",
            r"same.*node.*error",
        ],
        "performance_issues": [
            r"timeout", r"slow", r"stall",
            r"waiting.*resource", r"queue.*full",
            r"load.*high", r"overload",
        ],
    },

    "Thunderbird": {
        "high_error_rate": [
            r"error", r"fatal", r"failure", r"failed",
            r"severe", r"critical", r"panic",
            r"hardware.*error", r"node.*fail",
        ],
        "unauthorized_access": [
            r"permission denied", r"unauthorized",
            r"authentication.*fail",
        ],
        "unusual_operations": [
            r"fatal", r"panic",
            r"hardware.*error", r"hardware.*failure",
            r"node.*fail", r"node.*down",
            r"kernel.*error", r"kernel.*panic",
            r"network.*partition", r"partition.*event",
            r"rpc.*error",
        ],
        "repeated_abuse": [
            r"node.*\w+.*repeated",
            r"same.*node.*fail",
        ],
        "performance_issues": [
            r"timeout", r"slow", r"latency",
            r"network.*slow", r"congestion",
        ],
    },

    "Windows": {
        "high_error_rate": [
            r"error", r"failed", r"failure", r"fatal",
            r"critical", r"warning",
            r"eventid.*1000", r"eventid.*1001",  # app crashes
            r"eventid.*7034", r"eventid.*7031",  # service crashes
            r"blue.screen", r"bsod",
        ],
        "unauthorized_access": [
            r"eventid.*4625",   # failed logon
            r"eventid.*4648",   # explicit credential logon
            r"logon.*fail", r"failed.*logon",
            r"account.*lock", r"locked.*out",
            r"unauthorized", r"access.*denied",
            r"permission.*denied",
        ],
        "unusual_operations": [
            r"eventid.*4698",   # scheduled task created
            r"eventid.*4719",   # audit policy changed
            r"eventid.*4720",   # user account created
            r"eventid.*4732",   # member added to group
            r"registry.*change", r"registry.*corrupt",
            r"service.*stop", r"service.*crash",
            r"process.*inject", r"dll.*inject",
        ],
        "repeated_abuse": [
            r"eventid.*4625.*4625",  # repeated failed logons
            r"multiple.*fail",
            r"account.*lock",        # account locked due to repeated failures
            r"brute.*force",
        ],
        "performance_issues": [
            r"timeout", r"slow", r"high.*cpu",
            r"memory.*leak", r"disk.*full",
            r"eventid.*2019", r"eventid.*2020",  # memory issues
        ],
    },

    "Linux": {
        "high_error_rate": [
            r"error", r"failed", r"failure", r"fatal",
            r"warn", r"critical",
            r"kernel.*error", r"driver.*error",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"authentication.*fail", r"auth.*fail",
            r"su.*fail", r"sudo.*fail",
            r"pam.*error", r"pam.*fail",
            r"sshd.*fail",
        ],
        "unusual_operations": [
            r"oom.killer", r"out.of.memory.*kill",
            r"segfault", r"segmentation fault",
            r"kernel.*panic", r"panic",
            r"call.*trace", r"oops",
            r"soft.*lockup", r"hard.*lockup",
            r"hung.*task", r"rcu.*stall",
            r"i/o.*error", r"disk.*error",
            r"filesystem.*error", r"ext.*error",
        ],
        "repeated_abuse": [
            r"repeated.*fail",
            r"multiple.*error",
            r"oom.*killed.*process",  # repeated OOM kills
        ],
        "performance_issues": [
            r"timeout", r"slow", r"high.*load",
            r"swap.*full", r"memory.*pressure",
            r"disk.*full", r"no.*space",
            r"cpu.*throttl", r"thermal",
        ],
    },

    "Android": {
        "high_error_rate": [
            r"error", r"exception", r"fatal",
            r"crash", r"e/", r"wtf/",
            r"anr", r"not.*responding",
            r"force.*close", r"stopped.*unexpectedly",
        ],
        "unauthorized_access": [
            r"permission.*denied", r"securityexception",
            r"access.*denied", r"not.*allowed",
            r"permission.*not.*granted",
        ],
        "unusual_operations": [
            r"anr",                 # App Not Responding
            r"fatal.*exception",    # app crash
            r"outofmemoryerror",    # OOM
            r"nullpointerexception",
            r"stackoverflowerror",
            r"watchdog.*expired",
            r"deadlock",
            r"native.*crash",
        ],
        "repeated_abuse": [
            # Android has no IPs — detect repeated crashes from same app
            r"fatal.*exception.*main",
            r"anr.*in.*\w+\.\w+",   # ANR in same package
            r"force.*close.*\w+",
            r"crash.*\w+\.\w+",
        ],
        "performance_issues": [
            r"anr",                 # ANR is a performance issue
            r"slow.*main.*thread",
            r"gc.*pause", r"gc.*overhead",
            r"low.*memory", r"memory.*pressure",
            r"frame.*drop", r"jank",
            r"battery.*drain",
        ],
    },

    "HealthApp": {
        "high_error_rate": [
            r"error", r"failed", r"failure", r"fatal",
            r"warn", r"exception",
            r"sensor.*fail", r"device.*fail",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"unauthorized", r"authentication.*fail",
        ],
        "unusual_operations": [
            r"threshold.*exceed", r"exceed.*threshold",
            r"critical.*alert", r"alert.*critical",
            r"sensor.*fail", r"sensor.*error",
            r"data.*missing", r"missing.*data",
            r"battery.*low", r"low.*battery",
            r"device.*disconnect",
        ],
        "repeated_abuse": [
            r"repeated.*error",
            r"sensor.*repeated.*fail",
            r"multiple.*alert",
        ],
        "performance_issues": [
            r"timeout", r"slow", r"latency",
            r"battery.*low", r"memory.*full",
            r"data.*delay", r"sync.*fail",
        ],
    },

    "Mac": {
        "high_error_rate": [
            r"error", r"failed", r"failure", r"fatal",
            r"warn", r"critical",
            r"kernel.*error", r"crash",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"authentication.*fail", r"auth.*fail",
            r"sudo.*fail", r"su.*fail",
            r"pam.*error", r"keychain.*fail",
        ],
        "unusual_operations": [
            r"kernel.*panic", r"panic",
            r"segfault", r"segmentation fault",
            r"crash.*reporter", r"crash.*log",
            r"sandbox.*violation", r"sandbox.*deny",
            r"gatekeeper.*block",
            r"disk.*full", r"no.*space",
        ],
        "repeated_abuse": [
            r"repeated.*error",
            r"crash.*loop",
            r"respawn.*too.*fast",
        ],
        "performance_issues": [
            r"timeout", r"slow", r"high.*cpu",
            r"memory.*pressure", r"swap.*full",
            r"thermal.*throttl", r"disk.*full",
        ],
    },

    "Proxifier": {
        "high_error_rate": [
            r"error", r"failed", r"failure",
            r"connect.*error", r"connection.*error",
            r"proxy.*error",
        ],
        "unauthorized_access": [
            r"access denied", r"denied",
            r"blocked", r"rule.*blocked",
            r"forbidden", r"unauthorized",
            r"auth.*fail", r"authentication.*fail",
        ],
        "unusual_operations": [
            r"blocked", r"rule.*blocked",
            r"certificate.*error", r"ssl.*error",
            r"invalid.*certificate", r"cert.*fail",
            r"proxy.*chain.*fail",
            r"socks.*error",
        ],
        "repeated_abuse": [
            r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}",  # IP frequency
            r"repeated.*block",
            r"multiple.*deny",
        ],
        "performance_issues": [
            r"timeout", r"timed out", r"slow",
            r"connection.*timeout", r"proxy.*timeout",
            r"latency", r"bandwidth",
        ],
    },

    "OpenStack": {
        "high_error_rate": [
            r"error", r"exception", r"failed", r"failure",
            r"fatal", r"traceback", r"warn",
            r"http [45]\d\d",
        ],
        "unauthorized_access": [
            r"unauthorized", r"401", r"403",
            r"access.*denied", r"permission.*denied",
            r"authentication.*fail", r"auth.*fail",
            r"token.*invalid", r"token.*expired",
        ],
        "unusual_operations": [
            r"instance.*fail", r"vm.*fail",
            r"quota.*exceed", r"resource.*exhaust",
            r"network.*fail", r"neutron.*error",
            r"compute.*fail", r"nova.*error",
            r"storage.*fail", r"cinder.*error",
            r"image.*fail", r"glance.*error",
        ],
        "repeated_abuse": [
            r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}",
            r"repeated.*fail",
            r"request.*flood",
            r"rate.*limit",
        ],
        "performance_issues": [
            r"timeout", r"timed out", r"slow",
            r"high.*latency", r"response.*slow",
            r"queue.*full", r"overload",
        ],
    },

    "Unknown": {
        "high_error_rate": [
            r"error", r"failed", r"failure", r"fatal",
            r"exception", r"crash", r"panic",
        ],
        "unauthorized_access": [
            r"unauthorized", r"denied", r"forbidden",
            r"authentication.*fail", r"permission.*denied",
        ],
        "unusual_operations": [
            r"kill", r"abort", r"crash",
            r"corrupt", r"overflow", r"inject",
        ],
        "repeated_abuse": [
            r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}",
            r"repeated", r"multiple.*fail",
        ],
        "performance_issues": [
            r"timeout", r"slow", r"latency",
            r"overload", r"memory.*full",
        ],
    },
}


# ─────────────────────────────────────────────
# Helper: Get searchable text from entry
# ─────────────────────────────────────────────

def get_text(result: dict) -> str:
    """Combines ALL text fields for maximum coverage."""
    parts = []
    for field in ["raw_text", "message", "event_template", "service"]:
        val = (result.get(field) or "").strip()
        if val:
            parts.append(val)
    reasons = " ".join(result.get("anomaly_reasons", []))
    return ((" ".join(parts)) + " " + reasons).lower()


def match_patterns(text: str, patterns: list) -> list[str]:
    """Returns list of matched pattern labels."""
    matched = []
    for pattern in patterns:
        try:
            if re.search(pattern, text):
                matched.append(pattern)
        except re.error:
            if pattern in text:
                matched.append(pattern)
    return matched


def get_log_type_defs(log_type: str) -> dict:
    """Gets anomaly definitions for a log type, falls back to Unknown."""
    return LOG_TYPE_ANOMALY_DEFS.get(log_type) or LOG_TYPE_ANOMALY_DEFS["Unknown"]


# ─────────────────────────────────────────────
# Anomaly Type Analyzers
# Each returns a detailed dict — not just true/false
# ─────────────────────────────────────────────

def analyze_high_error_rate(results: list[dict]) -> dict:
    """
    Detects high error rate for ANY log type.
    Returns count, percentage, examples, detected flag.
    """
    error_entries  = []
    error_by_type  = defaultdict(int)

    for r in results:
        text     = get_text(r)
        log_type = r.get("log_type", "Unknown")
        defs     = get_log_type_defs(log_type)
        patterns = defs.get("high_error_rate", [])

        if match_patterns(text, patterns):
            error_entries.append(r)
            error_by_type[log_type] += 1

    total      = len(results)
    count      = len(error_entries)
    rate       = round(count / total * 100, 1) if total > 0 else 0
    detected   = count >= 3 or rate >= 5.0

    # Get top example raw texts
    examples = [
        e.get("raw_text", "")[:100]
        for e in sorted(error_entries, key=lambda x: x.get("anomaly_score", 0), reverse=True)[:3]
    ]

    return {
        "detected":    detected,
        "count":       count,
        "percentage":  rate,
        "by_log_type": dict(error_by_type),
        "examples":    examples,
        "label":       "High Error Rate",
        "description": f"{count} error entries detected ({rate}% of total)",
    }


def analyze_unauthorized_access(results: list[dict]) -> dict:
    """
    Detects unauthorized access for ANY log type.
    SSH brute force, HTTP 403, Windows 4625, permission denied, etc.
    """
    unauth_entries = []
    by_type        = defaultdict(int)

    for r in results:
        text     = get_text(r)
        log_type = r.get("log_type", "Unknown")
        defs     = get_log_type_defs(log_type)
        patterns = defs.get("unauthorized_access", [])

        if match_patterns(text, patterns):
            unauth_entries.append(r)
            by_type[log_type] += 1

    count    = len(unauth_entries)
    detected = count >= 1

    examples = [
        e.get("raw_text", "")[:100]
        for e in sorted(unauth_entries, key=lambda x: x.get("anomaly_score", 0), reverse=True)[:3]
    ]

    return {
        "detected":    detected,
        "count":       count,
        "by_log_type": dict(by_type),
        "examples":    examples,
        "label":       "Unauthorized Access",
        "description": f"{count} unauthorized access attempts detected",
    }


def analyze_unusual_operations(results: list[dict]) -> dict:
    """
    Detects unusual/dangerous operations for ANY log type.
    HTTP DELETE on admin, kernel panic, OOM kill, ANR, etc.
    """
    unusual_entries = []
    by_type         = defaultdict(int)

    for r in results:
        text     = get_text(r)
        log_type = r.get("log_type", "Unknown")
        defs     = get_log_type_defs(log_type)
        patterns = defs.get("unusual_operations", [])

        if match_patterns(text, patterns):
            unusual_entries.append(r)
            by_type[log_type] += 1

    count    = len(unusual_entries)
    detected = count >= 1

    examples = [
        e.get("raw_text", "")[:100]
        for e in sorted(unusual_entries, key=lambda x: x.get("anomaly_score", 0), reverse=True)[:3]
    ]

    return {
        "detected":    detected,
        "count":       count,
        "by_log_type": dict(by_type),
        "examples":    examples,
        "label":       "Unusual Operations",
        "description": f"{count} unusual/dangerous operations detected",
    }


def analyze_repeated_abuse(results: list[dict]) -> dict:
    """
    Detects repeated abuse patterns for ANY log type.
    - HTTP/Apache/Proxifier/OpenStack → IP frequency
    - OpenSSH → repeated failed logins from same IP
    - Android → same app crashing repeatedly
    - Hadoop/Spark → same task/job failing repeatedly
    - Windows → repeated Event 4625 (failed logons)
    - Zookeeper → repeated session timeouts
    """
    abuse_entries  = []
    by_type        = defaultdict(int)
    abuse_details  = []

    # ── Method 1: IP frequency (for IP-based logs) ────
    ip_counts    = Counter()
    ip_to_results = defaultdict(list)

    for r in results:
        raw = (r.get("raw_text") or "").strip()
        # Apache / Proxifier / OpenStack — IP at start
        m = re.match(r'^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', raw)
        # OpenSSH — "from IP" pattern
        if not m:
            m = re.search(r'from\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', raw)
        # Any field
        if not m:
            for field in ["service", "message"]:
                val = (r.get(field) or "")
                m = re.search(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', val)
                if m:
                    break
        if m:
            ip = m.group(1)
            ip_counts[ip] += 1
            ip_to_results[ip].append(r)

    total     = len(results)
    threshold = max(3, total * 0.04)

    for ip, count in ip_counts.items():
        if count > threshold:
            abuse_details.append(f"IP {ip} appeared {count} times")
            for r in ip_to_results[ip]:
                if r not in abuse_entries:
                    abuse_entries.append(r)
                    by_type[r.get("log_type", "Unknown")] += 1

    # ── Method 2: Android repeated crashes ────────────
    android_crashes = defaultdict(list)
    for r in results:
        if r.get("log_type") == "Android":
            text = get_text(r)
            # Extract app package from ANR/crash
            pkg_m = re.search(r'in\s+([\w.]+)', text)
            pkg   = pkg_m.group(1) if pkg_m else "unknown_app"
            if re.search(r"anr|fatal.*exception|force.*close|crash", text):
                android_crashes[pkg].append(r)

    for pkg, entries in android_crashes.items():
        if len(entries) >= 2:
            abuse_details.append(f"App '{pkg}' crashed {len(entries)} times")
            for r in entries:
                if r not in abuse_entries:
                    abuse_entries.append(r)
                    by_type["Android"] += 1

    # ── Method 3: Hadoop/Spark repeated task failures ──
    task_failures = defaultdict(list)
    for r in results:
        if r.get("log_type") in ("Hadoop", "Spark", "HDFS"):
            text = get_text(r)
            # Extract job/task ID
            id_m = re.search(r'(job_\w+|task_\w+|stage_\w+)', text)
            tid  = id_m.group(1) if id_m else None
            if tid and re.search(r"fail|error|exception", text):
                task_failures[tid].append(r)

    for tid, entries in task_failures.items():
        if len(entries) >= 2:
            abuse_details.append(f"Task/Job '{tid}' failed {len(entries)} times")
            for r in entries:
                if r not in abuse_entries:
                    abuse_entries.append(r)
                    by_type[r.get("log_type", "Unknown")] += 1

    # ── Method 4: OpenSSH repeated login failures ─────
    ssh_fail_ips = Counter()
    for r in results:
        if r.get("log_type") == "OpenSSH":
            text = get_text(r)
            if re.search(r"failed.*password|invalid.*user|auth.*fail", text):
                ip_m = re.search(r'from\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', text)
                ip   = ip_m.group(1) if ip_m else "unknown"
                ssh_fail_ips[ip] += 1

    for ip, count in ssh_fail_ips.items():
        if count >= 3:
            abuse_details.append(f"SSH brute force from {ip} ({count} attempts)")
            abuse_entries.extend([
                r for r in results
                if r.get("log_type") == "OpenSSH" and ip in get_text(r)
                and r not in abuse_entries
            ])
            by_type["OpenSSH"] += count

    # ── Method 5: Windows repeated failed logons ───────
    win_fail_count = sum(
        1 for r in results
        if r.get("log_type") == "Windows" and re.search(r"4625|fail.*logon|logon.*fail", get_text(r))
    )
    if win_fail_count >= 3:
        abuse_details.append(f"Windows repeated failed logons ({win_fail_count} events)")
        by_type["Windows"] += win_fail_count

    # ── Method 6: Zookeeper repeated timeouts ─────────
    zk_timeout_count = sum(
        1 for r in results
        if r.get("log_type") == "Zookeeper" and re.search(r"timeout|session.*expire|connectionloss", get_text(r))
    )
    if zk_timeout_count >= 3:
        abuse_details.append(f"Zookeeper repeated timeouts ({zk_timeout_count} events)")
        by_type["Zookeeper"] += zk_timeout_count

    count    = len(abuse_entries)
    detected = count >= 1 or len(abuse_details) >= 1

    examples = [
        e.get("raw_text", "")[:100]
        for e in sorted(abuse_entries, key=lambda x: x.get("anomaly_score", 0), reverse=True)[:3]
    ]

    return {
        "detected":    detected,
        "count":       count,
        "by_log_type": dict(by_type),
        "details":     abuse_details[:5],
        "examples":    examples,
        "label":       "Repeated Abuse",
        "description": f"{count} repeated abuse entries | {'; '.join(abuse_details[:2]) if abuse_details else 'none'}",
    }


def analyze_performance_issues(results: list[dict]) -> dict:
    """
    Detects performance issues for ANY log type.
    HTTP slow responses, timeouts, ANR, GC pauses, etc.
    """
    perf_entries = []
    by_type      = defaultdict(int)

    for r in results:
        text     = get_text(r)
        log_type = r.get("log_type", "Unknown")
        defs     = get_log_type_defs(log_type)
        patterns = defs.get("performance_issues", [])

        matched = match_patterns(text, patterns)
        if matched:
            perf_entries.append(r)
            by_type[log_type] += 1
            continue

        # Also check raw response time value
        raw     = (r.get("raw_text") or "")
        numbers = re.findall(r'\b(\d+)\b', raw)
        if numbers:
            last_num = int(numbers[-1])
            if last_num > 3000 and r.get("is_anomaly"):
                perf_entries.append(r)
                by_type[log_type] += 1

    count    = len(perf_entries)
    detected = count >= 1

    examples = [
        e.get("raw_text", "")[:100]
        for e in sorted(perf_entries, key=lambda x: x.get("anomaly_score", 0), reverse=True)[:3]
    ]

    return {
        "detected":    detected,
        "count":       count,
        "by_log_type": dict(by_type),
        "examples":    examples,
        "label":       "Performance Issues",
        "description": f"{count} performance issue entries detected",
    }


# ─────────────────────────────────────────────
# Suspicious IP / Entity Extractor
# ─────────────────────────────────────────────

def extract_suspicious_entities(results: list[dict]) -> list[dict]:
    """
    Extracts top suspicious IPs (for IP logs) OR
    top suspicious components/apps (for non-IP logs).
    """
    entity_data = defaultdict(lambda: {
        "entity": "",
        "type": "",
        "max_score": 0,
        "total_count": 0,
        "anomaly_count": 0
    })

    for r in results:
        raw      = (r.get("raw_text") or "").strip()
        log_type = r.get("log_type", "Unknown")
        entity   = None
        etype    = "ip"

        # Try IP from different positions
        m = re.match(r'^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', raw)
        if not m:
            m = re.search(r'from\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', raw)
        if m:
            entity = m.group(1)
            etype  = "ip"

        # For Android — use app package
        if not entity and log_type == "Android":
            m = re.search(r'([a-z][a-z0-9]*\.[a-z][a-z0-9.]+)', raw)
            if m:
                entity = m.group(1)
                etype  = "app"

        # For Hadoop/Spark — use job/task ID
        if not entity and log_type in ("Hadoop", "Spark"):
            m = re.search(r'(job_\w+|task_\w+)', raw)
            if m:
                entity = m.group(1)
                etype  = "job"

        # For Windows — use event source
        if not entity and log_type == "Windows":
            m = re.search(r'EventID[:\s]+(\d+)', raw, re.IGNORECASE)
            if m:
                entity = f"EventID_{m.group(1)}"
                etype  = "event"

        if entity:
            d = entity_data[entity]
            d["entity"]       = entity
            d["type"]         = etype
            d["total_count"] += 1
            d["max_score"]    = max(d["max_score"], r.get("anomaly_score", 0))
            if r.get("is_anomaly"):
                d["anomaly_count"] += 1

    return sorted(
        entity_data.values(),
        key=lambda x: (x["anomaly_count"], x["max_score"]),
        reverse=True
    )[:10]


# ─────────────────────────────────────────────
# Main Report Builder
# ─────────────────────────────────────────────

def build_full_report(
    results: list[dict],
    model_trained_fresh: bool,
    total_features: int
) -> dict:

    total     = len(results)
    anomalies = [r for r in results if r["is_anomaly"]]
    normal    = [r for r in results if not r["is_anomaly"]]

    critical = [r for r in results if r["severity"] == "CRITICAL"]
    high     = [r for r in results if r["severity"] == "HIGH"]
    medium   = [r for r in results if r["severity"] == "MEDIUM"]
    low      = [r for r in results if r["severity"] == "LOW"]

    anomaly_pct = round(len(anomalies) / total * 100, 2) if total > 0 else 0

    # ── Analyze ALL 5 anomaly types ───────────────────
    logger.info("Analyzing all 5 anomaly types...")

    error_analysis    = analyze_high_error_rate(results)
    unauth_analysis   = analyze_unauthorized_access(results)
    unusual_analysis  = analyze_unusual_operations(results)
    abuse_analysis    = analyze_repeated_abuse(results)
    perf_analysis     = analyze_performance_issues(results)

    # ── Extract suspicious entities ───────────────────
    top_entities = extract_suspicious_entities(results)

    # ── Log summary ───────────────────────────────────
    logger.info(
        f"Report | Total={total} | Anomalies={len(anomalies)} ({anomaly_pct}%) | "
        f"Critical={len(critical)} | High={len(high)}"
    )
    logger.info(
        f"Anomaly types | "
        f"Errors={error_analysis['count']} | "
        f"Unauth={unauth_analysis['count']} | "
        f"Unusual={unusual_analysis['count']} | "
        f"Abuse={abuse_analysis['count']} | "
        f"Perf={perf_analysis['count']}"
    )

    # ── Backward compatibility flags ──────────────────
    # Keep the old boolean fields so existing code doesn't break
    high_error_rate = error_analysis["detected"]
    unauthorized    = unauth_analysis["detected"]
    unusual_methods = unusual_analysis["detected"]
    ip_abuse        = abuse_analysis["detected"]
    time_spike      = perf_analysis["detected"]

    return {
        # ── Summary counts ─────────────────────────────
        "total_entries":      total,
        "anomaly_count":      len(anomalies),
        "normal_count":       len(normal),
        "anomaly_percentage": anomaly_pct,
        "critical_count":     len(critical),
        "high_count":         len(high),
        "medium_count":       len(medium),
        "low_count":          len(low),

        # ── Boolean flags (backward compat) ───────────
        "high_error_rate_detected":     high_error_rate,
        "unauthorized_access_detected": unauthorized,
        "unusual_methods_detected":     unusual_methods,
        "ip_abuse_detected":            ip_abuse,
        "response_time_spike_detected": time_spike,

        # ── Detailed anomaly type analysis ────────────
        # Each has: detected, count, by_log_type, examples, description
        "anomaly_type_analysis": {
            "high_error_rate":    error_analysis,
            "unauthorized_access": unauth_analysis,
            "unusual_operations": unusual_analysis,
            "repeated_abuse":     abuse_analysis,
            "performance_issues": perf_analysis,
        },

        # ── Suspicious entities ────────────────────────
        # IPs for HTTP logs, apps for Android, jobs for Hadoop, etc.
        "top_suspicious_ips":  top_entities,

        # ── Per-entry results ─────────────────────────
        "results":             results,
        "model_trained_fresh": model_trained_fresh,
        "total_features_used": total_features,
    }
