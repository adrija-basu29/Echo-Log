# launcher.py — Echo-Log Master Launcher
# Place in: E:\echo-log\launcher.py
# Run:  python launcher.py
# Stop: Ctrl+C

import os
import sys
import time
import signal
import subprocess
import threading
import webbrowser
import requests
from pathlib import Path

# ─────────────────────────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────────────────────────

BASE_DIR = Path(__file__).parent.resolve()

MODULES = [
    {
        "name":   "Module 3 — Anomaly Detection",
        "folder": BASE_DIR / "module3_anomaly_detection",
        "port":   8002,
        "health": "http://localhost:8002/api/v3/health",
    },
    {
        "name":   "Module 4 — Root Cause Analysis",
        "folder": BASE_DIR / "module4_root_cause",
        "port":   8003,
        "health": "http://localhost:8003/api/v4/health",
    },
    {
        "name":   "Module 5 — Escalation & Remediation",
        "folder": BASE_DIR / "module5_automation",
        "port":   8004,
        "health": "http://localhost:8004/api/v5/health",
    },
    {
        "name":   "Module 6 — Dashboard",
        "folder": BASE_DIR / "module6_dashboard",
        "port":   8005,
        "health": "http://localhost:8005/api/health",
    },
]

ALERTS_HISTORY = BASE_DIR / "module5_automation" / "alerts_history.json"
DASHBOARD_URL  = "http://localhost:8005/run"
PYTHON         = sys.executable

RESET  = "\033[0m"
BOLD   = "\033[1m"
GREEN  = "\033[92m"
RED    = "\033[91m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
MUTED  = "\033[90m"

def c(color, text): return f"{color}{text}{RESET}"

processes = []
proc_lock = threading.Lock()

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def print_banner():
    print()
    print(c(CYAN, "  +================================================+"))
    print(c(CYAN, "  |") + c(BOLD,  "       Echo-Log  Master Launcher              ") + c(CYAN, "|"))
    print(c(CYAN, "  |") + c(MUTED, "  Anomaly Detection & Remediation Pipeline     ") + c(CYAN, "|"))
    print(c(CYAN, "  +================================================+"))
    print()


def validate_folders():
    print(c(MUTED, "  Checking module folders..."))
    ok = True
    for m in MODULES:
        if not (m["folder"] / "main.py").exists():
            print(f"  {c(RED,'MISSING')} {m['name']} -> {m['folder']}")
            ok = False
        else:
            print(f"  {c(GREEN,'OK')}      {m['name']}")
    print()
    return ok


def is_healthy(url: str) -> bool:
    try:
        r = requests.get(url, timeout=15)
        return r.status_code == 200
    except Exception:
        return False


def kill_port(port: int):
    """Kill only the LISTENING process on this exact port."""
    try:
        if sys.platform == "win32":
            result = subprocess.run(
                "netstat -ano", shell=True,
                capture_output=True, text=True
            )
            pids = set()
            for line in result.stdout.strip().splitlines():
                parts = line.split()
                if len(parts) < 5:
                    continue
                local = parts[1]
                state = parts[3]
                pid   = parts[4]
                if (state == "LISTENING"
                        and local.endswith(f":{port}")
                        and pid.isdigit()
                        and int(pid) > 4):
                    pids.add(int(pid))
            for pid in pids:
                subprocess.run(f"taskkill /PID {pid} /F",
                               shell=True, capture_output=True)
        else:
            subprocess.run(f"fuser -k {port}/tcp",
                           shell=True, capture_output=True)
        time.sleep(1)
    except Exception:
        pass


def start_module(m) -> subprocess.Popen:
    """Start main.py — keep log file handle open for subprocess lifetime."""
    env = os.environ.copy()
    env["ALERTS_HISTORY_PATH"] = str(ALERTS_HISTORY)

    log_path = m["folder"] / "logs" / "launcher_output.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)

    # Must NOT use 'with open()' — handle must stay open
    log_fh = open(log_path, "w", encoding="utf-8")

    kwargs = dict(cwd=str(m["folder"]), env=env, stdout=log_fh, stderr=log_fh)
    if sys.platform == "win32":
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP

    return subprocess.Popen([PYTHON, "main.py"], **kwargs)


def shutdown(signum=None, frame=None):
    print()
    print(c(YELLOW, "  Shutting down all modules..."))
    with proc_lock:
        for proc, m in processes:
            try:
                if sys.platform == "win32":
                    proc.send_signal(signal.CTRL_BREAK_EVENT)
                else:
                    proc.terminate()
                proc.wait(timeout=5)
                print(f"  {c(GREEN,'OK')} {m['name']}")
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
    print(c(CYAN, "\n  Echo-Log stopped.\n"))
    sys.exit(0)


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main():
    if sys.platform == "win32":
        os.system("color")

    print_banner()
    signal.signal(signal.SIGINT,  shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    if not validate_folders():
        print(c(RED, "  Fix missing folders then retry.\n"))
        sys.exit(1)

    # ── Step 1: Kill any stale processes on all ports first ───────
    print(c(MUTED, "  Clearing ports..."))
    for m in MODULES:
        kill_port(m["port"])
    print(c(GREEN, "  Done\n"))

    # ── Step 2: Start ALL modules immediately, no waiting ─────────
    print(c(MUTED, "  Launching all modules...\n"))
    for m in MODULES:
        print(f"  {c(CYAN,'>')} Starting {c(BOLD, m['name'])} on port {m['port']}...")
        try:
            proc = start_module(m)
            with proc_lock:
                processes.append((proc, m))
        except Exception as e:
            print(f"  {c(RED,'FAILED:')} {e}")

    # ── Step 3: Wait 15s for all to boot, then check status ───────
    print()
    print(c(MUTED, "  Waiting 15s for all modules to boot"), end="", flush=True)
    for _ in range(45):
        time.sleep(1)
        print(".", end="", flush=True)
    print()

    # ── Step 4: Show status of all modules ────────────────────────
    print()
    print(c(CYAN, "  " + "=" * 50))
    all_ok = True
    for m in MODULES:
        ok = is_healthy(m["health"])
        if not ok:
            all_ok = False
        dot  = c(GREEN, "●") if ok else c(RED, "●")
        stat = c(GREEN, "RUNNING") if ok else c(RED, "NOT READY")
        print(f"  {dot}  {m['name']:<42} :{m['port']}  {stat}")
    print(c(CYAN, "  " + "=" * 50))
    print()
    print(f"  Dashboard    -> {c(CYAN, 'http://localhost:8005')}")
    print(f"  Run Pipeline -> {c(CYAN, 'http://localhost:8005/run')}")
    print()

    if not all_ok:
        print(c(YELLOW, "  Some modules are still starting up."))
        print(c(YELLOW, "  Wait 10-20 more seconds then open the dashboard."))
        print()

    print(c(MUTED, "  Ctrl+C to stop all modules.\n"))

    # Open browser
    threading.Thread(
        target=lambda: (time.sleep(3), webbrowser.open(DASHBOARD_URL)),
        daemon=True
    ).start()

    # ── Step 5: Keep alive + auto-restart crashed modules ─────────
    while True:
        time.sleep(5)
        with proc_lock:
            for i, (proc, m) in enumerate(processes):
                if proc.poll() is not None:
                    print(c(RED, f"\n  {m['name']} crashed. Restarting..."))
                    kill_port(m["port"])
                    time.sleep(1)
                    new_proc = start_module(m)
                    processes[i] = (new_proc, m)
                    time.sleep(5)
                    if is_healthy(m["health"]):
                        print(c(GREEN, f"  {m['name']} back online"))
                    else:
                        print(c(YELLOW, f"  {m['name']} restarting, give it a moment..."))


if __name__ == "__main__":
    main()
