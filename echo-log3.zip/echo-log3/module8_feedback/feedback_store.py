# feedback_store.py — Module 8: Feedback Data Store
# Persists all feedback, run history, and model performance over time

import os
import json
from datetime import datetime
from pathlib import Path
from loguru import logger

STORE_DIR       = "feedback_store"
RUNS_FILE       = os.path.join(STORE_DIR, "runs.json")
FEEDBACK_FILE   = os.path.join(STORE_DIR, "feedback.json")
PERFORMANCE_FILE= os.path.join(STORE_DIR, "performance.json")

os.makedirs(STORE_DIR, exist_ok=True)


# ─────────────────────────────────────────────────────────────────────────────
# Run History — every pipeline run is recorded
# ─────────────────────────────────────────────────────────────────────────────

def save_run(run_data: dict) -> str:
    """Save a pipeline run to history. Returns run_id."""
    runs = _load_json(RUNS_FILE, default=[])
    run_id = f"RUN-{datetime.now().strftime('%Y%m%d-%H%M%S')}-{len(runs)+1:04d}"
    run_data["run_id"]    = run_id
    run_data["timestamp"] = datetime.now().isoformat()
    runs.append(run_data)
    _save_json(RUNS_FILE, runs)
    logger.info(f"Run saved: {run_id}")
    return run_id


def get_runs(limit: int = 50) -> list:
    runs = _load_json(RUNS_FILE, default=[])
    return list(reversed(runs[-limit:]))


def get_run(run_id: str) -> dict | None:
    runs = _load_json(RUNS_FILE, default=[])
    for r in runs:
        if r.get("run_id") == run_id:
            return r
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Feedback — human labels on specific log entries
# ─────────────────────────────────────────────────────────────────────────────

def save_feedback_entry(entry: dict) -> str:
    """Save a single feedback entry. Returns feedback_id."""
    feedback = _load_json(FEEDBACK_FILE, default={"confirmed": [], "rejected": [], "uncertain": []})
    fb_id = f"FB-{datetime.now().strftime('%Y%m%d-%H%M%S')}-{_total_feedback(feedback)+1:04d}"
    entry["feedback_id"] = fb_id
    entry["timestamp"]   = datetime.now().isoformat()

    label = entry.get("label", "confirmed")   # confirmed | rejected | uncertain
    if label not in feedback:
        feedback[label] = []
    feedback[label].append(entry)

    _save_json(FEEDBACK_FILE, feedback)
    logger.info(f"Feedback saved: {fb_id} label={label}")
    return fb_id


def get_all_feedback() -> dict:
    return _load_json(FEEDBACK_FILE, default={"confirmed": [], "rejected": [], "uncertain": []})


def get_feedback_stats() -> dict:
    fb = get_all_feedback()
    confirmed  = len(fb.get("confirmed", []))
    rejected   = len(fb.get("rejected", []))
    uncertain  = len(fb.get("uncertain", []))
    total      = confirmed + rejected + uncertain
    return {
        "total":      total,
        "confirmed":  confirmed,
        "rejected":   rejected,
        "uncertain":  uncertain,
        "ready_for_training": total >= 10,
        "min_needed": max(0, 10 - total),
    }


def get_training_data() -> dict:
    """
    Convert feedback into format M3 can use for retraining.
    Returns confirmed anomalies and rejected (normal) entries.
    """
    fb = get_all_feedback()
    return {
        "anomalies": fb.get("confirmed", []),
        "normals":   fb.get("rejected",  []),
    }


def clear_feedback():
    """Clear all feedback after a successful retrain."""
    _save_json(FEEDBACK_FILE, {"confirmed": [], "rejected": [], "uncertain": []})
    logger.info("Feedback cleared after retrain")


# ─────────────────────────────────────────────────────────────────────────────
# Performance Tracking — track model accuracy over time
# ─────────────────────────────────────────────────────────────────────────────

def save_performance_snapshot(snapshot: dict):
    """Save model performance after a retrain."""
    perf = _load_json(PERFORMANCE_FILE, default=[])
    snapshot["timestamp"] = datetime.now().isoformat()
    perf.append(snapshot)
    _save_json(PERFORMANCE_FILE, perf)
    logger.info(f"Performance snapshot saved")


def get_performance_history(limit: int = 20) -> list:
    perf = _load_json(PERFORMANCE_FILE, default=[])
    return list(reversed(perf[-limit:]))


def get_learning_trend() -> dict:
    """
    Analyze if the model is improving over retrains.
    Compares anomaly rate across runs to detect drift or improvement.
    """
    runs = _load_json(RUNS_FILE, default=[])
    if len(runs) < 2:
        return {"status": "insufficient_data", "runs_needed": max(0, 2 - len(runs))}

    recent = runs[-10:]   # last 10 runs
    rates  = [r.get("anomaly_rate", 0) for r in recent if "anomaly_rate" in r]

    if len(rates) < 2:
        return {"status": "insufficient_data"}

    avg_early  = sum(rates[:len(rates)//2]) / (len(rates)//2)
    avg_recent = sum(rates[len(rates)//2:]) / (len(rates) - len(rates)//2)
    delta      = avg_recent - avg_early

    if delta < -5:   trend = "improving"    # fewer anomalies detected = better model
    elif delta > 5:  trend = "degrading"    # more anomalies = possible drift
    else:            trend = "stable"

    return {
        "status":      "ok",
        "trend":       trend,
        "avg_early":   round(avg_early, 1),
        "avg_recent":  round(avg_recent, 1),
        "delta":       round(delta, 1),
        "runs_analyzed": len(rates),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Auto-trigger logic
# ─────────────────────────────────────────────────────────────────────────────

def should_auto_retrain() -> dict:
    """
    Decide whether to auto-trigger a retrain.
    Rules:
      1. At least 10 feedback entries since last retrain
      2. At least 3 runs since last retrain
      3. Not already retraining
    """
    fb_stats  = get_feedback_stats()
    runs      = _load_json(RUNS_FILE, default=[])
    perf_hist = _load_json(PERFORMANCE_FILE, default=[])

    runs_since_retrain = len(runs)
    if perf_hist:
        last_retrain_time = perf_hist[-1].get("timestamp", "")
        runs_since_retrain = sum(
            1 for r in runs
            if r.get("timestamp", "") > last_retrain_time
        )

    should = (
        fb_stats["total"] >= 10
        and runs_since_retrain >= 3
    )

    return {
        "should_retrain":       should,
        "feedback_count":       fb_stats["total"],
        "runs_since_retrain":   runs_since_retrain,
        "reason": (
            "Ready — enough feedback and runs accumulated" if should
            else f"Not yet — need {fb_stats['min_needed']} more feedback entries and {max(0, 3-runs_since_retrain)} more runs"
        )
    }


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _load_json(path: str, default):
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return default


def _save_json(path: str, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)


def _total_feedback(fb: dict) -> int:
    return sum(len(v) for v in fb.values() if isinstance(v, list))
