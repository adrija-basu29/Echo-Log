# learning_engine.py — Module 8: Continuous Learning Engine
# Sends feedback to M3 and triggers retraining

import requests
from datetime import datetime
from loguru import logger
from feedback_store import (
    get_training_data, get_feedback_stats,
    save_performance_snapshot, clear_feedback,
    get_all_feedback
)

M3_URL = "http://localhost:8002/api/v3"


def trigger_retrain(clear_after: bool = True) -> dict:
    """
    Send all accumulated feedback to M3 and trigger a retrain.
    This is the core learning step — M3's model improves after this.
    """
    fb_stats = get_feedback_stats()

    if fb_stats["total"] < 10:
        return {
            "status":  "insufficient_feedback",
            "message": f"Need at least 10 feedback entries. Have {fb_stats['total']}.",
            "stats":   fb_stats,
        }

    training_data = get_training_data()
    anomalies = training_data.get("anomalies", [])
    normals   = training_data.get("normals",   [])

    logger.info(f"Triggering retrain — {len(anomalies)} anomalies, {len(normals)} normals")

    # ── Step 1: Push each feedback entry to M3 /feedback ──────────
    pushed = 0
    errors = 0
    for entry in anomalies:
        try:
            requests.post(f"{M3_URL}/feedback", json={
                "line_number":       entry.get("line_number", 0),
                "raw_text":          entry.get("raw_text", ""),
                "confirmed_anomaly": True,
                "log_type":          entry.get("log_type"),
            }, timeout=5)
            pushed += 1
        except Exception as e:
            errors += 1
            logger.warning(f"Failed to push anomaly feedback: {e}")

    for entry in normals:
        try:
            requests.post(f"{M3_URL}/feedback", json={
                "line_number":       entry.get("line_number", 0),
                "raw_text":          entry.get("raw_text", ""),
                "confirmed_anomaly": False,
                "log_type":          entry.get("log_type"),
            }, timeout=5)
            pushed += 1
        except Exception as e:
            errors += 1
            logger.warning(f"Failed to push normal feedback: {e}")

    # ── Step 2: Trigger M3 retrain-with-feedback ───────────────────
    try:
        r = requests.post(f"{M3_URL}/retrain-with-feedback", timeout=120)
        if r.status_code != 200:
            return {
                "status":  "retrain_failed",
                "message": f"M3 retrain returned {r.status_code}: {r.text[:200]}",
            }
        retrain_result = r.json()
    except requests.exceptions.ConnectionError:
        return {
            "status":  "connection_error",
            "message": "Module 3 is not running (port 8002)",
        }
    except Exception as e:
        return {
            "status":  "error",
            "message": str(e),
        }

    # ── Step 3: Save performance snapshot ─────────────────────────
    snapshot = {
        "feedback_used":  fb_stats["total"],
        "anomalies_used": len(anomalies),
        "normals_used":   len(normals),
        "pushed":         pushed,
        "push_errors":    errors,
        "retrain_result": retrain_result,
        "timestamp":      datetime.now().isoformat(),
    }
    save_performance_snapshot(snapshot)

    # ── Step 4: Clear feedback if requested ───────────────────────
    if clear_after:
        clear_feedback()

    logger.info(f"Retrain complete — pushed {pushed} entries, {errors} errors")

    return {
        "status":         "success",
        "message":        f"Model retrained with {fb_stats['total']} feedback entries",
        "pushed":         pushed,
        "push_errors":    errors,
        "feedback_used":  fb_stats["total"],
        "retrain_result": retrain_result,
        "feedback_cleared": clear_after,
    }


def submit_bulk_feedback(pipeline_results: dict, auto_label: bool = True) -> dict:
    """
    Automatically label results from a pipeline run as feedback.
    CRITICAL anomalies → confirmed=True
    LOW severity non-anomalies → confirmed=False (normal)

    This is the key function that makes the system learn automatically
    without requiring human input on every run.
    """
    from feedback_store import save_feedback_entry

    labeled = 0
    skipped = 0

    # Get anomaly results from detection report
    detection = pipeline_results.get("detection", {})
    rca_results = pipeline_results.get("rca_results", [])

    # Auto-label CRITICAL and HIGH as confirmed anomalies
    for result in rca_results:
        sev = result.get("severity", "")
        if sev in ("CRITICAL", "HIGH"):
            save_feedback_entry({
                "line_number": result.get("line_number", 0),
                "raw_text":    result.get("raw_text", ""),
                "log_type":    result.get("log_type"),
                "label":       "confirmed",
                "source":      "auto",
                "severity":    sev,
                "rule_id":     result.get("rule_id", ""),
            })
            labeled += 1
        else:
            skipped += 1

    return {
        "labeled":  labeled,
        "skipped":  skipped,
        "source":   "auto",
    }


def get_model_status() -> dict:
    """Get current model status from M3."""
    try:
        r = requests.get(f"{M3_URL}/health/full", timeout=5)
        if r.status_code == 200:
            return r.json()
    except Exception:
        pass
    return {"status": "unknown", "error": "Could not reach Module 3"}
