# main.py — Module 8: Feedback & Continuous Learning
# Port: 8007

import os
import uvicorn
from fastapi import FastAPI
from loguru import logger
from routes import router

app = FastAPI(
    title="Echo-Log — Feedback & Continuous Learning API",
    description="""
    ## Module 8: Feedback & Continuous Learning

    Makes the anomaly detection model improve automatically with every pipeline run.

    ### How it works:
    1. Every time the pipeline runs, call `POST /api/v8/record-run` with the results
    2. CRITICAL/HIGH anomalies are auto-labeled as confirmed feedback
    3. Once 10+ feedback entries accumulate, model retrains automatically
    4. M3's Isolation Forest + LOF models update with the new knowledge
    5. Next pipeline run uses the improved model

    ### Human feedback:
    - `POST /api/v8/feedback` — manually confirm or reject a specific anomaly
    - `POST /api/v8/retrain` — manually trigger a retrain
    - `GET  /api/v8/status` — see learning progress and trend

    ### Auto-retrain triggers when:
    - 10+ feedback entries accumulated
    - 3+ runs since last retrain
    """,
    version="1.0.0"
)

os.makedirs("logs",           exist_ok=True)
os.makedirs("feedback_store", exist_ok=True)

logger.add(
    "logs/feedback.log",
    rotation="10 MB",
    retention="7 days",
    level="INFO",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}"
)

app.include_router(router, prefix="/api/v8")


@app.get("/")
async def root():
    return {
        "project": "Echo-Log",
        "module":  "Module 8 — Feedback & Continuous Learning",
        "port":    8007,
        "status":  "running",
        "docs":    "Visit /docs for interactive API documentation",
    }


if __name__ == "__main__":
    logger.info("🚀 Starting Echo-Log Feedback & Learning Server on port 8007...")
    uvicorn.run("main:app", host="0.0.0.0", port=8007, reload=False)
