# routes.py — Module 8: Feedback & Continuous Learning API

import requests
from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional
from loguru import logger

from feedback_store import (
    save_run, get_runs, get_run,
    save_feedback_entry, get_feedback_stats, get_all_feedback,
    get_performance_history, get_learning_trend,
    should_auto_retrain, clear_feedback,
)
from learning_engine import trigger_retrain, submit_bulk_feedback, get_model_status

router = APIRouter()

M5_URL = "http://localhost:8004/api/v5"


# ── Schemas ───────────────────────────────────────────────────────────────────

class RunRecordRequest(BaseModel):
    pipeline_data:  dict
    log_filename:   str  = "unknown"
    auto_feedback:  bool = True   # auto-label CRITICAL/HIGH as confirmed feedback


class FeedbackRequest(BaseModel):
    line_number: int
    raw_text:    str
    label:       str          # "confirmed" | "rejected" | "uncertain"
    log_type:    Optional[str] = None
    severity:    Optional[str] = None
    run_id:      Optional[str] = None


class RetrainRequest(BaseModel):
    clear_after: bool = True  # clear feedback after successful retrain


# ── Routes ────────────────────────────────────────────────────────────────────

@router.post("/record-run")
async def record_run(request: RunRecordRequest, background_tasks: BackgroundTasks):
    """
    Record a completed pipeline run and optionally auto-label results as feedback.
    Call this after every M5 /full-pipeline run to enable continuous learning.
    """
    pipeline = request.pipeline_data
    detection = pipeline.get("detection", {})

    # Build run record
    run_record = {
        "log_file":      request.log_filename,
        "total_entries": detection.get("total_entries", 0),
        "anomaly_count": detection.get("anomaly_count", 0),
        "critical_count":detection.get("critical_count", 0),
        "anomaly_rate":  detection.get("anomaly_rate", 0),
        "overall_action":pipeline.get("escalation", {}).get("overall_action", "MONITOR"),
    }
    run_id = save_run(run_record)

    # Auto-label feedback in background
    feedback_result = {}
    if request.auto_feedback:
        rca = pipeline.get("rca", {})
        full_rca = rca.get("rca_results", []) if isinstance(rca, dict) else []
        feedback_result = submit_bulk_feedback({
            "detection":  detection,
            "rca_results": full_rca,
        })

    # Check if auto-retrain should trigger
    auto_check = should_auto_retrain()
    retrain_triggered = False
    if auto_check["should_retrain"]:
        logger.info("Auto-retrain threshold reached — triggering in background")
        background_tasks.add_task(trigger_retrain, True)
        retrain_triggered = True

    return {
        "status":             "success",
        "run_id":             run_id,
        "feedback_labeled":   feedback_result.get("labeled", 0),
        "auto_retrain":       retrain_triggered,
        "retrain_status":     auto_check,
    }


@router.post("/feedback")
async def submit_feedback(request: FeedbackRequest):
    """Submit human feedback on a specific log entry."""
    if request.label not in ("confirmed", "rejected", "uncertain"):
        raise HTTPException(status_code=400, detail="label must be: confirmed | rejected | uncertain")

    fb_id = save_feedback_entry({
        "line_number": request.line_number,
        "raw_text":    request.raw_text,
        "log_type":    request.log_type,
        "severity":    request.severity,
        "run_id":      request.run_id,
        "label":       request.label,
        "source":      "human",
    })

    stats = get_feedback_stats()
    return {
        "status":      "saved",
        "feedback_id": fb_id,
        "stats":       stats,
        "ready_for_training": stats["ready_for_training"],
    }


@router.post("/retrain")
async def retrain(request: RetrainRequest, background_tasks: BackgroundTasks):
    """
    Manually trigger a model retrain using accumulated feedback.
    Runs in background — returns immediately with job status.
    """
    stats = get_feedback_stats()
    if stats["total"] < 10:
        raise HTTPException(
            status_code=400,
            detail=f"Need at least 10 feedback entries. Currently have {stats['total']}. "
                   f"Need {stats['min_needed']} more."
        )
    background_tasks.add_task(trigger_retrain, request.clear_after)
    return {
        "status":   "triggered",
        "message":  f"Retraining started with {stats['total']} feedback entries",
        "feedback": stats,
    }


@router.post("/retrain-now")
async def retrain_now(request: RetrainRequest):
    """
    Trigger retrain synchronously — waits for completion.
    Use for testing. For production use /retrain (background).
    """
    result = trigger_retrain(request.clear_after)
    if result["status"] != "success":
        raise HTTPException(status_code=500, detail=result["message"])
    return result


@router.get("/status")
async def get_status():
    """Full learning system status — feedback, runs, trends, model."""
    fb_stats    = get_feedback_stats()
    auto_check  = should_auto_retrain()
    trend       = get_learning_trend()
    model       = get_model_status()
    runs        = get_runs(limit=5)
    perf        = get_performance_history(limit=5)

    return {
        "status":           "online",
        "feedback":         fb_stats,
        "auto_retrain":     auto_check,
        "learning_trend":   trend,
        "model_status":     model,
        "recent_runs":      runs,
        "recent_retrains":  perf,
    }


@router.get("/runs")
async def list_runs(limit: int = 20):
    """List all recorded pipeline runs."""
    return {"status": "success", "runs": get_runs(limit=limit)}


@router.get("/runs/{run_id}")
async def get_run_detail(run_id: str):
    """Get details of a specific run."""
    run = get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found")
    return {"status": "success", "run": run}


@router.get("/feedback/stats")
async def feedback_stats():
    """Get feedback statistics."""
    return get_feedback_stats()


@router.get("/feedback/all")
async def all_feedback():
    """Get all feedback entries."""
    return get_all_feedback()


@router.delete("/feedback/clear")
async def clear_all_feedback():
    """Clear all feedback (use after manual review)."""
    clear_feedback()
    return {"status": "success", "message": "All feedback cleared"}


@router.get("/performance")
async def performance_history(limit: int = 20):
    """Get model performance history across retrains."""
    return {
        "status":  "success",
        "history": get_performance_history(limit=limit),
        "trend":   get_learning_trend(),
    }


@router.get("/health")
async def health():
    return {"status": "healthy", "port": 8007}
