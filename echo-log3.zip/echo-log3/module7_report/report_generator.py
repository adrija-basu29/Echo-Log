# report_generator.py — Module 7: AI Report Generation Engine
# Takes full pipeline output (M3+M4+M5) and generates a structured report
# Output formats: JSON (structured), HTML (human readable), Markdown

import json
import os
from datetime import datetime
from pathlib import Path
from loguru import logger

REPORTS_DIR = "reports"
os.makedirs(REPORTS_DIR, exist_ok=True)


# ─────────────────────────────────────────────────────────────────────────────
# Severity helpers
# ─────────────────────────────────────────────────────────────────────────────

SEVERITY_RANK = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}

def severity_color(sev: str) -> str:
    return {
        "CRITICAL": "#ff4455",
        "HIGH":     "#ff8833",
        "MEDIUM":   "#ffcc00",
        "LOW":      "#3399ff",
    }.get(sev, "#888")

def severity_emoji(sev: str) -> str:
    return {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵"}.get(sev, "⚪")

def action_emoji(action: str) -> str:
    return {"ESCALATE": "🚨", "RESCALE": "⚡", "AUTO_FIX": "🔧", "MONITOR": "👁️"}.get(action, "•")


# ─────────────────────────────────────────────────────────────────────────────
# Report builder
# ─────────────────────────────────────────────────────────────────────────────

def build_report(pipeline_data: dict, log_filename: str = "unknown") -> dict:
    """
    Takes the full pipeline output from M5 /full-pipeline and builds
    a structured report dict that can be rendered as HTML, Markdown, or JSON.
    """
    detection  = pipeline_data.get("detection", {})
    rca        = pipeline_data.get("rca", {})
    escalation = pipeline_data.get("escalation", {})

    # ── Executive Summary ─────────────────────────────────────────
    total_entries  = detection.get("total_entries", 0)
    anomaly_count  = detection.get("anomaly_count", 0)
    critical_count = detection.get("critical_count", 0)
    chains         = rca.get("chains_detected", 0)
    overall_action = escalation.get("overall_action", "MONITOR")
    urgency        = escalation.get("overall_urgency", "LOW")
    action_counts  = escalation.get("action_counts", {})
    top_fixes      = rca.get("top_fixes", [])
    escalations    = escalation.get("escalations", [])
    executed       = escalation.get("executed_actions", [])
    rescales       = escalation.get("rescale_details", [])
    teams          = escalation.get("teams_to_notify", [])
    sys_before     = escalation.get("system_before", {})
    sys_after      = escalation.get("system_after", {})
    recovery       = escalation.get("recovery_status", {})

    anomaly_rate = round((anomaly_count / total_entries * 100), 1) if total_entries > 0 else 0

    # ── Health Score (0-100, higher = healthier) ──────────────────
    health_score = 100
    health_score -= min(critical_count * 15, 60)
    health_score -= min((anomaly_count - critical_count) * 2, 30)
    health_score -= (10 if overall_action == "ESCALATE" else 5 if overall_action == "RESCALE" else 0)
    health_score = max(0, min(100, health_score))

    if health_score >= 80:   health_label = "Healthy"
    elif health_score >= 60: health_label = "Warning"
    elif health_score >= 40: health_label = "Degraded"
    else:                    health_label = "Critical"

    # ── Key Findings ──────────────────────────────────────────────
    findings = []
    if critical_count > 0:
        findings.append({
            "severity": "CRITICAL",
            "finding": f"{critical_count} critical anomalies detected requiring immediate attention",
        })
    if chains > 0:
        findings.append({
            "severity": "HIGH",
            "finding": f"{chains} causal chain(s) identified — events are correlated, not isolated",
        })
    if anomaly_rate > 20:
        findings.append({
            "severity": "HIGH",
            "finding": f"High anomaly rate: {anomaly_rate}% of log entries are anomalous",
        })
    if overall_action == "ESCALATE":
        findings.append({
            "severity": "CRITICAL",
            "finding": f"Human escalation required — {len(escalations)} item(s) flagged for engineer review",
        })
    if overall_action == "RESCALE":
        findings.append({
            "severity": "HIGH",
            "finding": f"Resource scaling required — {len(rescales)} resource(s) need expansion",
        })
    if executed:
        findings.append({
            "severity": "LOW",
            "finding": f"{len(executed)} auto-fix action(s) executed successfully",
        })
    if not findings:
        findings.append({
            "severity": "LOW",
            "finding": "System operating within normal parameters — no critical issues detected",
        })

    # ── Recommendations ───────────────────────────────────────────
    recommendations = []
    for fix in top_fixes:
        recommendations.append({
            "priority":   fix.get("severity", "MEDIUM"),
            "rule_id":    fix.get("rule_id", ""),
            "category":   fix.get("category", ""),
            "root_cause": fix.get("root_cause", ""),
            "actions":    fix.get("fix_steps", []),
            "prevention": fix.get("prevention", ""),
            "affects":    fix.get("affects_count", 1),
        })

    # ── Assemble full report ──────────────────────────────────────
    report = {
        "report_id":      f"RPT-{datetime.now().strftime('%Y%m%d-%H%M%S')}",
        "generated_at":   datetime.now().isoformat(),
        "log_file":       log_filename,

        # Executive summary
        "executive_summary": {
            "health_score":   health_score,
            "health_label":   health_label,
            "overall_action": overall_action,
            "urgency":        urgency,
            "headline":       _build_headline(overall_action, critical_count, anomaly_count, log_filename),
        },

        # Stats
        "stats": {
            "total_entries":  total_entries,
            "anomaly_count":  anomaly_count,
            "anomaly_rate":   anomaly_rate,
            "critical_count": critical_count,
            "chains_detected": chains,
            "action_counts":  action_counts,
        },

        # Findings and recommendations
        "key_findings":      findings,
        "recommendations":   recommendations,

        # Escalations
        "escalations":       escalations,
        "escalation_count":  len(escalations),
        "teams_to_notify":   teams,

        # Actions taken
        "executed_actions":  executed,
        "rescale_details":   rescales,

        # System state
        "system_before":     sys_before,
        "system_after":      sys_after,
        "recovery_status":   recovery,
    }

    logger.info(f"Report built: {report['report_id']} | Health={health_score} | Action={overall_action}")
    return report


def _build_headline(action: str, critical: int, anomalies: int, log_file: str) -> str:
    fname = Path(log_file).name if log_file else "log file"
    if action == "ESCALATE":
        return f"⚠️ Immediate attention required — {critical} critical anomalies in {fname}"
    elif action == "RESCALE":
        return f"Resource constraints detected in {fname} — scaling recommended"
    elif action == "AUTO_FIX":
        return f"Anomalies detected in {fname} — automated remediation applied"
    elif anomalies == 0:
        return f"✅ {fname} analysis complete — system healthy"
    else:
        return f"{anomalies} anomalies detected in {fname} — monitoring recommended"


# ─────────────────────────────────────────────────────────────────────────────
# Save report to disk
# ─────────────────────────────────────────────────────────────────────────────

def save_report_json(report: dict) -> str:
    """Save report as JSON and return the file path."""
    path = os.path.join(REPORTS_DIR, f"{report['report_id']}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, default=str)
    logger.info(f"Report saved: {path}")
    return path


def load_report(report_id: str) -> dict | None:
    """Load a saved report by ID."""
    path = os.path.join(REPORTS_DIR, f"{report_id}.json")
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def list_reports(limit: int = 20) -> list:
    """List all saved reports, newest first."""
    reports = []
    for f in sorted(Path(REPORTS_DIR).glob("*.json"), key=os.path.getmtime, reverse=True):
        try:
            with open(f) as fp:
                data = json.load(fp)
            reports.append({
                "report_id":    data.get("report_id"),
                "generated_at": data.get("generated_at"),
                "log_file":     data.get("log_file"),
                "health_score": data.get("executive_summary", {}).get("health_score"),
                "health_label": data.get("executive_summary", {}).get("health_label"),
                "action":       data.get("executive_summary", {}).get("overall_action"),
                "anomaly_count": data.get("stats", {}).get("anomaly_count", 0),
            })
        except Exception:
            pass
        if len(reports) >= limit:
            break
    return reports
