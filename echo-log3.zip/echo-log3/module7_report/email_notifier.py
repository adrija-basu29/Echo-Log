# email_notifier.py — Module 7: Escalation Email Sender
# Sends a rich HTML email when the pipeline action is ESCALATE
# Reuses the same Gmail credentials from alert_manager.py

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime
from loguru import logger

# ─────────────────────────────────────────────────────────────────────────────
# EMAIL CONFIG — same credentials as alert_manager.py
# ─────────────────────────────────────────────────────────────────────────────

EMAIL_CONFIG = {
    "enabled":   True,
    "smtp_host": "smtp.gmail.com",
    "smtp_port": 587,
    "username":  "adritaghosh586@gmail.com",
    "password":  "oktr ncsz ldex mjuv",
    "from_addr": "adritaghosh586@gmail.com",
    "to_addrs":  ["adritaghosh586@gmail.com"],
}

DASHBOARD_URL = "http://localhost:8005"


# ─────────────────────────────────────────────────────────────────────────────
# Main function
# ─────────────────────────────────────────────────────────────────────────────

def send_escalation_email(report: dict, extra_recipients: list = []) -> dict:
    """
    Send escalation email if report action is ESCALATE.
    extra_recipients: additional emails entered by user in the UI.
    Returns {"sent": True/False, "reason": "..."}
    """
    if not EMAIL_CONFIG["enabled"]:
        return {"sent": False, "reason": "Email disabled in config"}

    es     = report.get("executive_summary", {})
    action = es.get("overall_action", "")

    if action != "ESCALATE":
        return {"sent": False, "reason": f"Action is {action} — email only sent for ESCALATE"}

    report_id   = report.get("report_id", "")
    log_file    = report.get("log_file", "unknown")
    health      = es.get("health_score", 0)
    label       = es.get("health_label", "")
    headline    = es.get("headline", "")
    urgency     = es.get("urgency", "")
    stats       = report.get("stats", {})
    findings    = report.get("key_findings", [])
    recs        = report.get("recommendations", [])
    escalations = report.get("escalations", [])
    teams       = report.get("teams_to_notify", [])
    executed    = report.get("executed_actions", [])
    gen_time    = report.get("generated_at", "")[:19].replace("T", " ")

    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"🚨 ESCALATE [{urgency}] — {log_file} | Echo-Log Alert"
        msg["From"]    = EMAIL_CONFIG["from_addr"]
        # Merge config recipients with any extra ones from UI
        all_recipients = list(set(EMAIL_CONFIG["to_addrs"] + (extra_recipients or [])))
        msg["To"]      = ", ".join(all_recipients)

        text = _build_text(report_id, log_file, health, label, headline,
                           stats, findings, recs, escalations, teams, executed, gen_time)
        html = _build_html(report_id, log_file, health, label, headline,
                           urgency, stats, findings, recs, escalations, teams, executed, gen_time)

        msg.attach(MIMEText(text, "plain"))
        msg.attach(MIMEText(html, "html"))

        with smtplib.SMTP(EMAIL_CONFIG["smtp_host"], EMAIL_CONFIG["smtp_port"]) as server:
            server.ehlo()
            server.starttls()
            server.login(EMAIL_CONFIG["username"], EMAIL_CONFIG["password"])
            server.sendmail(EMAIL_CONFIG["from_addr"], all_recipients, msg.as_string())

        logger.info(f"✅ Escalation email sent for {report_id} to {all_recipients}")
        return {"sent": True, "recipients": all_recipients, "report_id": report_id}

    except smtplib.SMTPAuthenticationError:
        msg = "Gmail auth failed — check App Password"
        logger.error(msg)
        return {"sent": False, "reason": msg}
    except Exception as e:
        logger.error(f"Email failed: {e}")
        return {"sent": False, "reason": str(e)}


# ─────────────────────────────────────────────────────────────────────────────
# Plain text version
# ─────────────────────────────────────────────────────────────────────────────

def _build_text(report_id, log_file, health, label, headline,
                stats, findings, recs, escalations, teams, executed, gen_time) -> str:
    lines = [
        "=" * 60,
        "  ECHO-LOG — ESCALATION ALERT",
        "  Human intervention required",
        "=" * 60,
        "",
        f"Report ID  : {report_id}",
        f"Generated  : {gen_time}",
        f"Log File   : {log_file}",
        f"Health     : {health}/100 — {label}",
        f"Anomalies  : {stats.get('anomaly_count', 0)} ({stats.get('anomaly_rate', 0)}%)",
        f"Critical   : {stats.get('critical_count', 0)}",
        "",
        headline,
        "",
        "KEY FINDINGS",
        "-" * 40,
    ]
    for f in findings:
        lines.append(f"[{f.get('severity','')}] {f.get('finding','')}")

    if escalations:
        lines += ["", "ESCALATIONS REQUIRING HUMAN ACTION", "-" * 40]
        for e in escalations:
            lines.append(f"[{e.get('urgency','')}] {e.get('root_cause','')}")
            lines.append(f"  Team: {e.get('team','')}")

    if teams:
        lines += ["", f"Teams to notify: {', '.join(teams)}"]

    if recs:
        lines += ["", "TOP RECOMMENDATIONS", "-" * 40]
        for r in recs[:3]:
            lines.append(f"• {r.get('root_cause','')}")
            for step in r.get("actions", [])[:3]:
                lines.append(f"  → {step}")

    lines += [
        "",
        f"View full report: {DASHBOARD_URL}/reports",
        "",
        "─" * 60,
        "Echo-Log Automated Analysis System",
    ]
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# HTML version
# ─────────────────────────────────────────────────────────────────────────────

def _build_html(report_id, log_file, health, label, headline,
                urgency, stats, findings, recs, escalations, teams, executed, gen_time) -> str:

    # Health color
    if health >= 80:   hc = "#00b894"
    elif health >= 60: hc = "#fdcb6e"
    elif health >= 40: hc = "#e17055"
    else:              hc = "#d63031"

    sev_colors = {"CRITICAL": "#d63031", "HIGH": "#e17055", "MEDIUM": "#fdcb6e", "LOW": "#0984e3"}

    # Findings rows
    finding_rows = ""
    for f in findings:
        col   = sev_colors.get(f.get("severity", "LOW"), "#888")
        emoji = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵"}.get(f.get("severity"), "⚪")
        finding_rows += f"""
        <tr>
          <td style="padding:10px 16px;border-bottom:1px solid #f0f0f0;">
            <span style="background:{col};color:white;padding:2px 8px;border-radius:3px;
                         font-size:11px;font-weight:bold;">{f.get('severity','')}</span>
            &nbsp; {emoji} {f.get('finding','')}
          </td>
        </tr>"""

    # Escalation rows
    esc_rows = ""
    for e in escalations:
        esc_rows += f"""
        <tr>
          <td style="padding:10px 16px;border-bottom:1px solid #f0f0f0;">
            <span style="background:#d63031;color:white;padding:2px 8px;
                         border-radius:3px;font-size:11px;font-weight:bold;">
              {e.get('urgency','')}
            </span>
            &nbsp; <strong>{e.get('root_cause','')[:100]}</strong><br>
            <small style="color:#636e72;margin-left:8px;">
              Team: {e.get('team','')}
            </small>
          </td>
        </tr>"""

    # Recommendations
    rec_html = ""
    for i, r in enumerate(recs[:3], 1):
        steps = "".join(f"<li style='margin:4px 0;color:#555;'>{s}</li>"
                        for s in r.get("actions", [])[:4])
        rec_html += f"""
        <div style="background:#f8f9fa;border-left:3px solid #d63031;
                    padding:12px 16px;margin-bottom:10px;border-radius:0 4px 4px 0;">
          <strong style="color:#2d3436;">{i}. {r.get('root_cause','')}</strong>
          <ul style="margin:8px 0 0 16px;padding:0;">{steps}</ul>
          {"<p style='margin:8px 0 0;font-size:12px;color:#00b894;'><strong>Prevention:</strong> " + r.get('prevention','') + "</p>" if r.get('prevention') else ""}
        </div>"""

    # Teams
    teams_html = "".join(
        f'<span style="background:#e8f5e9;color:#2e7d32;padding:4px 12px;'
        f'border-radius:3px;margin:3px;font-size:12px;display:inline-block;">{t}</span>'
        for t in teams
    )

    # Executed actions
    exec_html = ""
    if executed:
        exec_rows = ""
        for e in executed:
            st   = e.get("result", {}).get("status", "?")
            col  = "#00b894" if st == "success" else "#d63031"
            exec_rows += f"""<tr>
              <td style="padding:8px 16px;border-bottom:1px solid #f0f0f0;font-family:monospace;font-size:12px;">
                {e.get('script', e.get('action',''))}
              </td>
              <td style="padding:8px 16px;border-bottom:1px solid #f0f0f0;color:{col};font-weight:bold;">
                {st}
              </td>
            </tr>"""
        exec_html = f"""
        <h3 style="color:#2d3436;font-size:14px;margin:24px 0 10px;
                   padding-bottom:6px;border-bottom:2px solid #eee;">
          🔧 Auto-Remediation Actions Taken
        </h3>
        <table style="width:100%;border-collapse:collapse;border:1px solid #eee;border-radius:4px;">
          <thead>
            <tr style="background:#f8f9fa;">
              <th style="padding:8px 16px;text-align:left;font-size:11px;color:#636e72;text-transform:uppercase;">Action</th>
              <th style="padding:8px 16px;text-align:left;font-size:11px;color:#636e72;text-transform:uppercase;">Status</th>
            </tr>
          </thead>
          <tbody>{exec_rows}</tbody>
        </table>"""

    return f"""<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="font-family:Arial,sans-serif;color:#2d3436;max-width:680px;margin:auto;padding:0;">

  <!-- Header -->
  <div style="background:#d63031;padding:24px 28px;border-radius:8px 8px 0 0;">
    <div style="color:white;font-size:11px;font-family:monospace;opacity:0.8;margin-bottom:6px;">
      ECHO-LOG AUTOMATED ALERT
    </div>
    <h1 style="color:white;margin:0;font-size:20px;">🚨 Human Intervention Required</h1>
    <p style="color:#ff8a80;margin:6px 0 0;font-size:13px;">{urgency} urgency — immediate action needed</p>
  </div>

  <!-- Subheader -->
  <div style="background:#fff5f5;padding:14px 28px;border:1px solid #ffcdd2;border-top:none;">
    <strong style="color:#c62828;">{headline}</strong>
  </div>

  <!-- Body -->
  <div style="background:white;padding:24px 28px;border:1px solid #eee;border-top:none;">

    <!-- Stats row -->
    <div style="display:flex;gap:0;margin-bottom:24px;">
      <div style="flex:1;text-align:center;padding:16px;border:1px solid #eee;border-radius:6px 0 0 6px;">
        <div style="font-size:28px;font-weight:bold;color:{hc};">{health}</div>
        <div style="font-size:11px;color:#636e72;text-transform:uppercase;letter-spacing:1px;">Health Score</div>
        <div style="font-size:12px;color:{hc};font-weight:bold;">{label}</div>
      </div>
      <div style="flex:1;text-align:center;padding:16px;border:1px solid #eee;border-left:none;">
        <div style="font-size:28px;font-weight:bold;color:#d63031;">{stats.get('critical_count',0)}</div>
        <div style="font-size:11px;color:#636e72;text-transform:uppercase;letter-spacing:1px;">Critical</div>
      </div>
      <div style="flex:1;text-align:center;padding:16px;border:1px solid #eee;border-left:none;">
        <div style="font-size:28px;font-weight:bold;color:#e17055;">{stats.get('anomaly_count',0)}</div>
        <div style="font-size:11px;color:#636e72;text-transform:uppercase;letter-spacing:1px;">Anomalies</div>
      </div>
      <div style="flex:1;text-align:center;padding:16px;border:1px solid #eee;border-left:none;border-radius:0 6px 6px 0;">
        <div style="font-size:28px;font-weight:bold;color:#0984e3;">{stats.get('chains_detected',0)}</div>
        <div style="font-size:11px;color:#636e72;text-transform:uppercase;letter-spacing:1px;">Chains</div>
      </div>
    </div>

    <!-- Key Findings -->
    <h3 style="color:#2d3436;font-size:14px;margin:0 0 10px;
               padding-bottom:6px;border-bottom:2px solid #eee;">
      🔍 Key Findings
    </h3>
    <table style="width:100%;border-collapse:collapse;border:1px solid #eee;
                  border-radius:4px;margin-bottom:20px;">
      <tbody>{finding_rows}</tbody>
    </table>

    <!-- Escalations -->
    {"<h3 style='color:#d63031;font-size:14px;margin:0 0 10px;padding-bottom:6px;border-bottom:2px solid #ffcdd2;'>🚨 Escalations Requiring Human Action</h3><table style='width:100%;border-collapse:collapse;border:1px solid #ffcdd2;border-radius:4px;margin-bottom:20px;'><tbody>" + esc_rows + "</tbody></table>" if escalations else ""}

    <!-- Teams -->
    {"<div style='margin-bottom:20px;'><strong style='font-size:13px;'>Teams to notify:</strong><br><div style='margin-top:8px;'>" + teams_html + "</div></div>" if teams else ""}

    <!-- Recommendations -->
    {"<h3 style='color:#2d3436;font-size:14px;margin:0 0 10px;padding-bottom:6px;border-bottom:2px solid #eee;'>📋 Top Recommendations</h3>" + rec_html if recs else ""}

    <!-- Executed actions -->
    {exec_html}

    <!-- View Report Button -->
    <div style="text-align:center;margin:28px 0 8px;">
      <a href="{DASHBOARD_URL}/reports"
         style="background:#d63031;color:white;padding:12px 32px;border-radius:4px;
                text-decoration:none;font-weight:bold;font-size:14px;
                display:inline-block;">
        📊 View Full Report
      </a>
    </div>

  </div>

  <!-- Footer -->
  <div style="background:#f8f9fa;padding:14px 28px;border:1px solid #eee;
              border-top:none;border-radius:0 0 8px 8px;
              font-size:11px;color:#636e72;display:flex;justify-content:space-between;">
    <span>Echo-Log Automated Analysis System</span>
    <span>{report_id} — {gen_time}</span>
  </div>

</body>
</html>"""
