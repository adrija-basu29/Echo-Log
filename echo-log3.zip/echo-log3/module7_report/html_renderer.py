# html_renderer.py — Module 7: HTML Report Renderer
# Generates a self-contained, printable HTML report from a report dict

from datetime import datetime
from report_generator import severity_color, severity_emoji, action_emoji


def render_html(report: dict) -> str:
    """Render a full self-contained HTML report."""

    es       = report.get("executive_summary", {})
    stats    = report.get("stats", {})
    findings = report.get("key_findings", [])
    recs     = report.get("recommendations", [])
    escs     = report.get("escalations", [])
    executed = report.get("executed_actions", [])
    rescales = report.get("rescale_details", [])
    teams    = report.get("teams_to_notify", [])
    sys_b    = report.get("system_before", {})
    sys_a    = report.get("system_after", {})
    recovery = report.get("recovery_status", {})

    health_score = es.get("health_score", 0)
    action       = es.get("overall_action", "MONITOR")
    urgency      = es.get("urgency", "")

    # Health score color
    if health_score >= 80:   hs_color = "#00d4aa"
    elif health_score >= 60: hs_color = "#ffcc00"
    elif health_score >= 40: hs_color = "#ff8833"
    else:                    hs_color = "#ff4455"

    action_colors = {
        "ESCALATE": "#ff4455", "RESCALE": "#ff8833",
        "AUTO_FIX": "#00d4aa", "MONITOR": "#3399ff"
    }
    action_color = action_colors.get(action, "#888")

    gen_time = report.get("generated_at", "")[:19].replace("T", " ")

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Echo-Log Report — {report.get('report_id', '')}</title>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
  :root {{
    --bg:#0a0c0f; --surface:#111318; --border:#1e2229; --border2:#2a2f3a;
    --text:#d4d8e0; --muted:#5a6070; --accent:#00d4aa;
    --red:#ff4455; --orange:#ff8833; --yellow:#ffcc00; --blue:#3399ff;
    --font:'IBM Plex Sans',sans-serif; --mono:'IBM Plex Mono',monospace;
  }}
  * {{ margin:0; padding:0; box-sizing:border-box; }}
  body {{ background:var(--bg); color:var(--text); font-family:var(--font);
          font-size:14px; line-height:1.6; padding:40px; }}
  @media print {{
    body {{ background:#fff; color:#000; padding:20px; }}
    .no-print {{ display:none; }}
  }}

  .report-header {{
    display:flex; justify-content:space-between; align-items:flex-start;
    margin-bottom:32px; padding-bottom:24px;
    border-bottom:2px solid var(--accent);
  }}
  .report-brand {{ font-family:var(--mono); font-size:22px; font-weight:600; color:var(--accent); }}
  .report-brand span {{ color:var(--muted); }}
  .report-meta {{ text-align:right; font-family:var(--mono); font-size:11px; color:var(--muted); }}
  .report-meta strong {{ color:var(--text); display:block; font-size:13px; margin-bottom:4px; }}

  .headline {{
    font-size:20px; font-weight:600; color:var(--text);
    margin-bottom:28px; line-height:1.4;
  }}

  /* Summary cards */
  .summary-grid {{
    display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin-bottom:28px;
  }}
  .summary-card {{
    background:var(--surface); border:1px solid var(--border);
    border-radius:6px; padding:16px; position:relative; overflow:hidden;
  }}
  .summary-card::before {{
    content:''; position:absolute; top:0; left:0; right:0; height:2px;
  }}
  .summary-card .card-label {{
    font-family:var(--mono); font-size:10px; text-transform:uppercase;
    letter-spacing:1.5px; color:var(--muted); margin-bottom:8px;
  }}
  .summary-card .card-value {{
    font-family:var(--mono); font-size:28px; font-weight:600; line-height:1;
  }}
  .summary-card .card-sub {{ font-size:12px; color:var(--muted); margin-top:6px; }}

  /* Health score */
  .health-card {{
    background:var(--surface); border:1px solid var(--border);
    border-radius:6px; padding:20px; margin-bottom:28px;
    display:flex; align-items:center; gap:24px;
  }}
  .health-score-circle {{
    width:80px; height:80px; border-radius:50%;
    border:4px solid {hs_color};
    display:flex; align-items:center; justify-content:center;
    flex-shrink:0;
  }}
  .health-score-num {{
    font-family:var(--mono); font-size:24px; font-weight:600;
    color:{hs_color};
  }}
  .health-info h3 {{ font-size:16px; font-weight:600; margin-bottom:6px; }}
  .health-info p {{ font-size:13px; color:var(--muted); }}

  /* Action badge */
  .action-badge {{
    display:inline-flex; align-items:center; gap:8px;
    padding:8px 16px; border-radius:4px; font-family:var(--mono);
    font-size:13px; font-weight:600; margin-bottom:28px;
    background:rgba(255,255,255,0.05); border:1px solid {action_color};
    color:{action_color};
  }}

  /* Section */
  .section {{ margin-bottom:28px; }}
  .section-title {{
    font-family:var(--mono); font-size:11px; font-weight:500;
    text-transform:uppercase; letter-spacing:2px; color:var(--muted);
    margin-bottom:12px; padding-bottom:8px;
    border-bottom:1px solid var(--border);
  }}

  /* Findings */
  .finding {{
    padding:12px 16px; border-radius:4px; margin-bottom:8px;
    border-left:3px solid;
    background:rgba(255,255,255,0.02);
    display:flex; align-items:flex-start; gap:10px; font-size:13px;
  }}

  /* Recommendations */
  .rec-card {{
    background:var(--surface); border:1px solid var(--border);
    border-radius:6px; padding:16px; margin-bottom:12px;
  }}
  .rec-header {{
    display:flex; align-items:center; gap:10px; margin-bottom:10px;
  }}
  .rec-cause {{ font-size:14px; font-weight:500; flex:1; }}
  .rec-steps {{
    font-family:var(--mono); font-size:11px; color:var(--muted);
    line-height:2; margin-left:4px;
  }}
  .rec-prevention {{
    margin-top:10px; padding-top:10px; border-top:1px solid var(--border);
    font-size:12px; color:rgba(0,212,170,0.7);
    font-family:var(--mono);
  }}

  /* Badge */
  .badge {{
    display:inline-block; padding:2px 8px; border-radius:3px;
    font-family:var(--mono); font-size:10px; font-weight:600;
    text-transform:uppercase; letter-spacing:0.5px;
  }}
  .badge-CRITICAL {{ background:rgba(255,68,85,0.15);  color:#ff4455; border:1px solid rgba(255,68,85,0.3); }}
  .badge-HIGH     {{ background:rgba(255,136,51,0.15); color:#ff8833; border:1px solid rgba(255,136,51,0.3); }}
  .badge-MEDIUM   {{ background:rgba(255,204,0,0.12);  color:#ffcc00; border:1px solid rgba(255,204,0,0.25); }}
  .badge-LOW      {{ background:rgba(51,153,255,0.12); color:#3399ff; border:1px solid rgba(51,153,255,0.25); }}

  /* Table */
  table {{ width:100%; border-collapse:collapse; }}
  th {{
    font-family:var(--mono); font-size:10px; text-transform:uppercase;
    letter-spacing:1px; color:var(--muted); text-align:left;
    padding:10px 12px; border-bottom:1px solid var(--border);
    background:var(--bg);
  }}
  td {{
    padding:10px 12px; border-bottom:1px solid var(--border);
    font-size:13px; vertical-align:middle;
  }}
  tr:last-child td {{ border-bottom:none; }}

  /* Metric bars */
  .metric-row {{ display:flex; align-items:center; gap:12px; margin-bottom:10px; }}
  .metric-label {{ font-family:var(--mono); font-size:11px; color:var(--muted); width:70px; }}
  .metric-bar-wrap {{ flex:1; height:6px; background:var(--border); border-radius:3px; overflow:hidden; }}
  .metric-bar {{ height:100%; border-radius:3px; }}
  .metric-val {{ font-family:var(--mono); font-size:12px; width:45px; text-align:right; }}

  /* Teams */
  .team-tag {{
    display:inline-block; padding:4px 12px; border-radius:3px;
    font-family:var(--mono); font-size:11px; margin:3px;
    background:rgba(0,212,170,0.08); border:1px solid rgba(0,212,170,0.2);
    color:var(--accent);
  }}

  /* Footer */
  .report-footer {{
    margin-top:40px; padding-top:16px; border-top:1px solid var(--border);
    font-family:var(--mono); font-size:11px; color:var(--muted);
    display:flex; justify-content:space-between;
  }}

  /* Print button */
  .print-btn {{
    position:fixed; bottom:24px; right:24px;
    background:var(--accent); color:#000; border:none; padding:10px 20px;
    border-radius:4px; font-family:var(--mono); font-size:12px;
    font-weight:600; cursor:pointer; z-index:100;
  }}
  .print-btn:hover {{ background:#00e8bb; }}
</style>
</head>
<body>

<button class="print-btn no-print" onclick="window.print()">⎙ Print / Save PDF</button>

<!-- HEADER -->
<div class="report-header">
  <div>
    <div class="report-brand">echo<span>-</span>log</div>
    <div style="font-size:12px;color:var(--muted);margin-top:4px;">Automated Log Analysis Report</div>
  </div>
  <div class="report-meta">
    <strong>{report.get('report_id', '')}</strong>
    Generated: {gen_time}<br>
    Log file: {report.get('log_file', 'unknown')}
  </div>
</div>

<!-- HEADLINE -->
<div class="headline">{es.get('headline', '')}</div>

<!-- HEALTH + ACTION -->
<div style="display:flex;gap:16px;align-items:center;margin-bottom:28px;">
  <div class="health-card" style="flex:1;margin-bottom:0;">
    <div class="health-score-circle">
      <span class="health-score-num">{health_score}</span>
    </div>
    <div class="health-info">
      <h3>System Health: {es.get('health_label', '')}</h3>
      <p>Based on {stats.get('anomaly_count',0)} anomalies across {stats.get('total_entries',0):,} log entries
      ({stats.get('anomaly_rate',0)}% anomaly rate)</p>
    </div>
  </div>
  <div style="text-align:center;padding:0 8px;">
    <div class="action-badge">
      {action_emoji(action)} {action} — {urgency}
    </div>
  </div>
</div>

<!-- SUMMARY CARDS -->
<div class="summary-grid">
  <div class="summary-card" style="">
    <div style="position:absolute;top:0;left:0;right:0;height:2px;background:#ff4455;"></div>
    <div class="card-label">Critical</div>
    <div class="card-value" style="color:#ff4455;">{stats.get('critical_count',0)}</div>
    <div class="card-sub">anomalies</div>
  </div>
  <div class="summary-card">
    <div style="position:absolute;top:0;left:0;right:0;height:2px;background:#ff8833;"></div>
    <div class="card-label">Total Anomalies</div>
    <div class="card-value" style="color:#ff8833;">{stats.get('anomaly_count',0)}</div>
    <div class="card-sub">from {stats.get('total_entries',0):,} entries</div>
  </div>
  <div class="summary-card">
    <div style="position:absolute;top:0;left:0;right:0;height:2px;background:#00d4aa;"></div>
    <div class="card-label">Causal Chains</div>
    <div class="card-value" style="color:#00d4aa;">{stats.get('chains_detected',0)}</div>
    <div class="card-sub">correlated events</div>
  </div>
  <div class="summary-card">
    <div style="position:absolute;top:0;left:0;right:0;height:2px;background:#3399ff;"></div>
    <div class="card-label">Actions Taken</div>
    <div class="card-value" style="color:#3399ff;">{len(executed)}</div>
    <div class="card-sub">auto-remediated</div>
  </div>
</div>

<!-- KEY FINDINGS -->
<div class="section">
  <div class="section-title">Key Findings</div>
  {"".join(_render_finding(f) for f in findings)}
</div>

<!-- RECOMMENDATIONS -->
{_render_recommendations(recs)}

<!-- ESCALATIONS -->
{_render_escalations(escs, teams)}

<!-- EXECUTED ACTIONS -->
{_render_executed(executed)}

<!-- RESCALE -->
{_render_rescales(rescales)}

<!-- SYSTEM METRICS -->
{_render_metrics(sys_b, sys_a, recovery)}

<!-- FOOTER -->
<div class="report-footer">
  <span>Echo-Log Automated Analysis System</span>
  <span>{report.get('report_id','')} — {gen_time}</span>
</div>

</body>
</html>"""

    return html


# ─────────────────────────────────────────────────────────────────────────────
# Section renderers
# ─────────────────────────────────────────────────────────────────────────────

def _render_finding(f: dict) -> str:
    sev   = f.get("severity", "LOW")
    color = severity_color(sev)
    emoji = severity_emoji(sev)
    return f"""<div class="finding" style="border-left-color:{color};">
    <span>{emoji}</span>
    <span>{f.get('finding','')}</span>
  </div>"""


def _render_recommendations(recs: list) -> str:
    if not recs:
        return ""
    cards = ""
    for r in recs:
        sev   = r.get("priority", "MEDIUM")
        steps = "".join(f"<div>→ {s}</div>" for s in r.get("actions", [])[:5])
        cards += f"""<div class="rec-card">
    <div class="rec-header">
      <span class="badge badge-{sev}">{sev}</span>
      <span style="font-family:var(--mono);font-size:10px;color:var(--muted);">[{r.get('rule_id','')}]</span>
      <span class="rec-cause">{r.get('root_cause','')}</span>
      <span style="font-family:var(--mono);font-size:11px;color:var(--muted);">{r.get('affects',1)} affected</span>
    </div>
    <div class="rec-steps">{steps}</div>
    {"<div class='rec-prevention'>Prevention: " + r.get('prevention','') + "</div>" if r.get('prevention') else ""}
  </div>"""
    return f"""<div class="section">
  <div class="section-title">Recommendations ({len(recs)})</div>
  {cards}
</div>"""


def _render_escalations(escs: list, teams: list) -> str:
    if not escs:
        return ""
    rows = ""
    for e in escs:
        rows += f"""<tr>
    <td><span class="badge badge-CRITICAL">{e.get('urgency','')}</span></td>
    <td>{e.get('root_cause','')[:100]}</td>
    <td style="font-family:var(--mono);font-size:11px;color:#00d4aa;">{e.get('team','')}</td>
  </tr>"""
    teams_html = "".join(f'<span class="team-tag">{t}</span>' for t in teams)
    return f"""<div class="section">
  <div class="section-title">🚨 Human Escalations Required ({len(escs)})</div>
  {f'<div style="margin-bottom:12px;">{teams_html}</div>' if teams else ""}
  <table><thead><tr><th>Urgency</th><th>Issue</th><th>Team</th></tr></thead>
  <tbody>{rows}</tbody></table>
</div>"""


def _render_executed(executed: list) -> str:
    if not executed:
        return ""
    rows = ""
    for e in executed:
        st  = e.get("result", {}).get("status", "?")
        col = "#00d4aa" if st == "success" else "#ff4455"
        freed = e.get("result", {}).get("freed_mb", 0)
        rows += f"""<tr>
    <td style="font-family:var(--mono);font-size:12px;">{e.get('script', e.get('action',''))}</td>
    <td><span style="color:{col};font-family:var(--mono);font-size:11px;">● {st}</span></td>
    <td style="font-family:var(--mono);font-size:11px;color:var(--muted);">
      {f'{freed:.1f} MB freed' if freed else '—'}
    </td>
  </tr>"""
    return f"""<div class="section">
  <div class="section-title">🔧 Auto-Remediation Actions ({len(executed)})</div>
  <table><thead><tr><th>Action</th><th>Status</th><th>Result</th></tr></thead>
  <tbody>{rows}</tbody></table>
</div>"""


def _render_rescales(rescales: list) -> str:
    if not rescales:
        return ""
    items = ""
    for r in rescales:
        items += f"""<div style="padding:12px 16px;background:rgba(255,136,51,0.06);
      border:1px solid rgba(255,136,51,0.2);border-radius:4px;margin-bottom:8px;">
      <strong style="color:#ff8833;">⚡ {r.get('resource','').upper()}</strong>
      — Scale by {r.get('scale_by','')}<br>
      <span style="font-size:12px;color:var(--muted);">{r.get('reason','')}</span>
    </div>"""
    return f"""<div class="section">
  <div class="section-title">⚡ Rescale Recommendations</div>
  {items}
</div>"""


def _render_metrics(sys_b: dict, sys_a: dict, recovery: dict) -> str:
    if not sys_b or "cpu_percent" not in sys_b:
        return ""

    def bar(val, color):
        v = min(float(val or 0), 100)
        return f'<div class="metric-bar" style="width:{v}%;background:{color};"></div>'

    def arrow(b, a):
        b, a = float(b or 0), float(a or 0)
        if a < b - 0.5:   return f'<span style="color:#00d4aa;">↓ {a:.1f}%</span>'
        elif a > b + 0.5: return f'<span style="color:#ff4455;">↑ {a:.1f}%</span>'
        else:              return f'<span style="color:var(--muted);">→ {a:.1f}%</span>'

    cpu_b  = sys_b.get("cpu_percent", 0)
    mem_b  = sys_b.get("memory_percent", 0)
    disk_b = sys_b.get("disk_percent", 0)
    cpu_a  = sys_a.get("cpu_percent", cpu_b)
    mem_a  = sys_a.get("memory_percent", mem_b)
    disk_a = sys_a.get("disk_percent", disk_b)

    rec_html = ""
    if recovery.get("status") == "improved":
        rec_html = f'<div style="color:#00d4aa;margin-top:12px;font-size:13px;">✅ {recovery.get("message","")}</div>'
    elif recovery.get("status") == "degraded":
        rec_html = f'<div style="color:#ff4455;margin-top:12px;font-size:13px;">⚠️ {recovery.get("message","")}</div>'

    return f"""<div class="section">
  <div class="section-title">System Metrics (Before → After)</div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;">
    <div>
      <div class="metric-row">
        <span class="metric-label">CPU</span>
        <div class="metric-bar-wrap">{bar(cpu_b, '#5a6070')}</div>
        <span class="metric-val" style="color:var(--muted);">{float(cpu_b):.0f}%</span>
      </div>
      <div class="metric-row">
        <span class="metric-label">Memory</span>
        <div class="metric-bar-wrap">{bar(mem_b, '#5a6070')}</div>
        <span class="metric-val" style="color:var(--muted);">{float(mem_b):.0f}%</span>
      </div>
      <div class="metric-row">
        <span class="metric-label">Disk</span>
        <div class="metric-bar-wrap">{bar(disk_b, '#5a6070')}</div>
        <span class="metric-val" style="color:var(--muted);">{float(disk_b):.0f}%</span>
      </div>
    </div>
    <div>
      <div class="metric-row">
        <span class="metric-label">CPU</span>
        <div class="metric-bar-wrap">{bar(cpu_a, '#00d4aa' if float(cpu_a or 0) <= float(cpu_b or 0) else '#ff4455')}</div>
        <span class="metric-val">{arrow(cpu_b, cpu_a)}</span>
      </div>
      <div class="metric-row">
        <span class="metric-label">Memory</span>
        <div class="metric-bar-wrap">{bar(mem_a, '#00d4aa' if float(mem_a or 0) <= float(mem_b or 0) else '#ff4455')}</div>
        <span class="metric-val">{arrow(mem_b, mem_a)}</span>
      </div>
      <div class="metric-row">
        <span class="metric-label">Disk</span>
        <div class="metric-bar-wrap">{bar(disk_a, '#00d4aa' if float(disk_a or 0) <= float(disk_b or 0) else '#ff4455')}</div>
        <span class="metric-val">{arrow(disk_b, disk_a)}</span>
      </div>
    </div>
  </div>
  {rec_html}
</div>"""
