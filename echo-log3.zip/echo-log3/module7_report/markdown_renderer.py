# markdown_renderer.py — Module 7: Markdown Report Renderer

from report_generator import severity_emoji, action_emoji


def render_markdown(report: dict) -> str:
    es       = report.get("executive_summary", {})
    stats    = report.get("stats", {})
    findings = report.get("key_findings", [])
    recs     = report.get("recommendations", [])
    escs     = report.get("escalations", [])
    executed = report.get("executed_actions", [])
    rescales = report.get("rescale_details", [])
    teams    = report.get("teams_to_notify", [])
    recovery = report.get("recovery_status", {})

    action = es.get("overall_action", "MONITOR")
    gen_time = report.get("generated_at", "")[:19].replace("T", " ")

    lines = []
    lines.append(f"# Echo-Log Analysis Report")
    lines.append(f"")
    lines.append(f"**Report ID:** `{report.get('report_id', '')}`  ")
    lines.append(f"**Generated:** {gen_time}  ")
    lines.append(f"**Log File:** `{report.get('log_file', 'unknown')}`")
    lines.append(f"")
    lines.append(f"---")
    lines.append(f"")

    # Executive Summary
    lines.append(f"## Executive Summary")
    lines.append(f"")
    lines.append(f"> {es.get('headline', '')}")
    lines.append(f"")
    lines.append(f"| Metric | Value |")
    lines.append(f"|--------|-------|")
    lines.append(f"| Health Score | **{es.get('health_score', 0)}/100** — {es.get('health_label', '')} |")
    lines.append(f"| Overall Action | {action_emoji(action)} **{action}** |")
    lines.append(f"| Urgency | {es.get('urgency', '')} |")
    lines.append(f"| Total Entries | {stats.get('total_entries', 0):,} |")
    lines.append(f"| Anomalies | {stats.get('anomaly_count', 0)} ({stats.get('anomaly_rate', 0)}%) |")
    lines.append(f"| Critical | {stats.get('critical_count', 0)} |")
    lines.append(f"| Causal Chains | {stats.get('chains_detected', 0)} |")
    lines.append(f"")

    # Action breakdown
    counts = stats.get("action_counts", {})
    if counts:
        lines.append(f"**Action Breakdown:**")
        for a, c in counts.items():
            if c > 0:
                lines.append(f"- {action_emoji(a)} {a}: {c}")
        lines.append(f"")

    # Key Findings
    lines.append(f"---")
    lines.append(f"")
    lines.append(f"## Key Findings")
    lines.append(f"")
    for f in findings:
        emoji = severity_emoji(f.get("severity", "LOW"))
        lines.append(f"- {emoji} **{f.get('severity', '')}** — {f.get('finding', '')}")
    lines.append(f"")

    # Recommendations
    if recs:
        lines.append(f"---")
        lines.append(f"")
        lines.append(f"## Recommendations")
        lines.append(f"")
        for i, r in enumerate(recs, 1):
            lines.append(f"### {i}. [{r.get('rule_id', '')}] {r.get('root_cause', '')}")
            lines.append(f"**Severity:** {r.get('priority', '')} | **Affects:** {r.get('affects', 1)} anomalies")
            lines.append(f"")
            lines.append(f"**Fix Steps:**")
            for step in r.get("actions", [])[:5]:
                lines.append(f"1. {step}")
            if r.get("prevention"):
                lines.append(f"")
                lines.append(f"**Prevention:** {r.get('prevention', '')}")
            lines.append(f"")

    # Escalations
    if escs:
        lines.append(f"---")
        lines.append(f"")
        lines.append(f"## 🚨 Human Escalations Required")
        lines.append(f"")
        if teams:
            lines.append(f"**Teams to notify:** {', '.join(teams)}")
            lines.append(f"")
        lines.append(f"| Urgency | Issue | Team |")
        lines.append(f"|---------|-------|------|")
        for e in escs:
            lines.append(f"| {e.get('urgency','')} | {e.get('root_cause','')[:80]} | {e.get('team','')} |")
        lines.append(f"")

    # Executed actions
    if executed:
        lines.append(f"---")
        lines.append(f"")
        lines.append(f"## 🔧 Auto-Remediation Actions Taken")
        lines.append(f"")
        for e in executed:
            st    = e.get("result", {}).get("status", "?")
            freed = e.get("result", {}).get("freed_mb", 0)
            icon  = "✅" if st == "success" else "❌"
            extra = f" — {freed:.1f} MB freed" if freed else ""
            lines.append(f"- {icon} `{e.get('script', e.get('action',''))}` → {st}{extra}")
        lines.append(f"")

    # Rescale
    if rescales:
        lines.append(f"---")
        lines.append(f"")
        lines.append(f"## ⚡ Rescale Recommendations")
        lines.append(f"")
        for r in rescales:
            lines.append(f"- **{r.get('resource','').upper()}** — Scale by {r.get('scale_by','')}  ")
            lines.append(f"  _{r.get('reason','')}_")
        lines.append(f"")

    # Recovery
    if recovery.get("status"):
        lines.append(f"---")
        lines.append(f"")
        icon = "✅" if recovery.get("status") == "improved" else "⚠️"
        lines.append(f"## System Recovery")
        lines.append(f"")
        lines.append(f"{icon} {recovery.get('message', '')}")
        lines.append(f"")

    lines.append(f"---")
    lines.append(f"")
    lines.append(f"*Generated by Echo-Log Automated Analysis System*")

    return "\n".join(lines)
