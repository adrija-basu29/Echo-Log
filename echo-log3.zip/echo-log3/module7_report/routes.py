# routes.py — Module 7: AI Report Generation API

import os
import json
import requests
from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse, PlainTextResponse, FileResponse
from pydantic import BaseModel
from typing import Optional
from loguru import logger

from report_generator import build_report, save_report_json, load_report, list_reports
from email_notifier   import send_escalation_email
from html_renderer    import render_html
from markdown_renderer import render_markdown

router = APIRouter()

M5_URL = "http://localhost:8004/api/v5"


# ── Request schemas ───────────────────────────────────────────────────────────

class GenerateFromPipelineRequest(BaseModel):
    pipeline_data: dict          # full output from M5 /full-pipeline
    log_filename:  str = "unknown"
    save:          bool = True   # save to disk
    recipients:    list = []     # extra email recipients from UI


class GenerateFromLogsRequest(BaseModel):
    structured_logs: list
    dry_run:         bool = False
    log_filename:    str  = "unknown"


# ── Routes ────────────────────────────────────────────────────────────────────

@router.post("/generate")
async def generate_report(request: GenerateFromPipelineRequest):
    """
    Generate a report from already-run pipeline data.
    Input:  pipeline dict from M5 /full-pipeline response
    Output: report JSON + HTML + Markdown
    """
    try:
        report   = build_report(request.pipeline_data, request.log_filename)
        path     = save_report_json(report) if request.save else None
        email_result = send_escalation_email(report, extra_recipients=request.recipients)
        return {
            "status":       "success",
            "report_id":    report["report_id"],
            "report":       report,
            "saved_to":     path,
            "email_sent":   email_result.get("sent", False),
            "email_detail": email_result,
        }
    except Exception as e:
        logger.error(f"Report generation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate-and-run")
async def generate_and_run(request: GenerateFromLogsRequest):
    """
    Full pipeline: structured logs → M5 full-pipeline → generate report.
    One endpoint that does everything.
    """
    logger.info(f"POST /generate-and-run — {len(request.structured_logs)} entries")

    # Call M5 full-pipeline
    try:
        resp = requests.post(
            f"{M5_URL}/full-pipeline",
            json={"structured_logs": request.structured_logs, "dry_run": request.dry_run},
            timeout=300
        )
        if resp.status_code != 200:
            raise HTTPException(status_code=502, detail=f"M5 error: {resp.text[:300]}")
        pipeline_data = resp.json().get("pipeline", {})
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="Module 5 not running (port 8004)")

    report       = build_report(pipeline_data, request.log_filename)
    path         = save_report_json(report)
    email_result = send_escalation_email(report)

    return {
        "status":        "success",
        "report_id":     report["report_id"],
        "report":        report,
        "pipeline_data": pipeline_data,
        "saved_to":      path,
        "email_sent":    email_result.get("sent", False),
        "email_detail":  email_result,
    }


@router.get("/report/{report_id}")
async def get_report_json(report_id: str):
    """Get a saved report as JSON."""
    report = load_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail=f"Report {report_id} not found")
    return {"status": "success", "report": report}


@router.get("/report/{report_id}/html", response_class=HTMLResponse)
async def get_report_html(report_id: str):
    """Render a saved report as HTML."""
    report = load_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail=f"Report {report_id} not found")
    return render_html(report)


@router.get("/report/{report_id}/markdown", response_class=PlainTextResponse)
async def get_report_markdown(report_id: str):
    """Render a saved report as Markdown."""
    report = load_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail=f"Report {report_id} not found")
    return render_markdown(report)


@router.get("/report/{report_id}/download")
async def download_report_html(report_id: str):
    """Download the HTML report as a file."""
    report = load_report(report_id)
    if not report:
        raise HTTPException(status_code=404, detail=f"Report {report_id} not found")

    html_path = f"reports/{report_id}.html"
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(render_html(report))

    return FileResponse(
        html_path,
        media_type="text/html",
        filename=f"echo-log-report-{report_id}.html"
    )


@router.get("/reports")
async def get_all_reports(limit: int = 20):
    """List all saved reports."""
    return {"status": "success", "reports": list_reports(limit=limit)}


@router.delete("/report/{report_id}")
async def delete_report(report_id: str):
    """Delete a saved report."""
    path = f"reports/{report_id}.json"
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Report not found")
    os.remove(path)
    html_path = f"reports/{report_id}.html"
    if os.path.exists(html_path):
        os.remove(html_path)
    return {"status": "success", "deleted": report_id}


@router.get("/health")
async def health():
    return {"status": "healthy", "port": 8006}
