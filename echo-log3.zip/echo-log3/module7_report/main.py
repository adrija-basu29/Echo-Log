# main.py — Module 7: AI Report Generation
# Port: 8006

import os
import uvicorn
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from loguru import logger
from routes import router

app = FastAPI(
    title="Echo-Log — Report Generation API",
    description="""
    ## Module 7: AI Report Generation

    Generates professional analysis reports from pipeline output (M3+M4+M5).

    ### Output Formats:
    - **JSON** — structured data for programmatic use
    - **HTML** — printable, self-contained report with charts
    - **Markdown** — clean text report for docs/wikis

    ### Endpoints:
    - `POST /api/v7/generate` — generate report from existing pipeline data
    - `POST /api/v7/generate-and-run` — run full pipeline + generate report in one call
    - `GET  /api/v7/report/{id}/html` — view report in browser
    - `GET  /api/v7/report/{id}/download` — download HTML report
    - `GET  /api/v7/reports` — list all saved reports
    """,
    version="1.0.0"
)

os.makedirs("logs",    exist_ok=True)
os.makedirs("reports", exist_ok=True)

logger.add(
    "logs/report.log",
    rotation="10 MB",
    retention="7 days",
    level="INFO",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}"
)

app.include_router(router, prefix="/api/v7")


@app.get("/")
async def root():
    return {
        "project": "Echo-Log",
        "module":  "Module 7 — AI Report Generation",
        "port":    8006,
        "status":  "running",
        "docs":    "Visit /docs for interactive API documentation"
    }


if __name__ == "__main__":
    logger.info("🚀 Starting Echo-Log Report Generation Server on port 8006...")
    uvicorn.run("main:app", host="0.0.0.0", port=8006, reload=False)
