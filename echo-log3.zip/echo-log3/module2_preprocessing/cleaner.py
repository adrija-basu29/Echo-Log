# cleaner.py
# Responsible for cleaning raw log text
# Think of this as "washing" the logs before cooking them

import re
from loguru import logger


def clean_line(raw_line: str) -> str:
    """
    Cleans a single raw log line.
    
    Steps:
    1. Strip leading/trailing whitespace
    2. Remove special invisible characters
    3. Normalize multiple spaces into one
    4. Remove ANSI color codes (some logs have terminal colors)
    """

    # Step 1: Strip whitespace from both ends
    line = raw_line.strip()

    # Step 2: Remove ANSI escape codes
    # These are color codes like \x1b[31m that appear in terminal logs
    # Example: "\x1b[31mERROR\x1b[0m" becomes "ERROR"
    ansi_escape = re.compile(r'\x1b\[[0-9;]*m')
    line = ansi_escape.sub('', line)

    # Step 3: Replace multiple spaces/tabs with single space
    line = re.sub(r'\s+', ' ', line)

    # Step 4: Remove null bytes and other invisible characters
    line = line.replace('\x00', '').replace('\r', '')

    return line


def is_empty_line(line: str) -> bool:
    """
    Check if a line is empty or just whitespace.
    We skip these during parsing.
    """
    return len(line.strip()) == 0


def is_continuation_line(line: str) -> bool:
    """
    Some log messages span multiple lines.
    This detects lines that are continuations (like stack traces).
    
    Example continuation lines:
      "    at java.lang.Thread.run(Thread.java:748)"
      "Caused by: java.lang.NullPointerException"
    """
    # Lines starting with whitespace are usually continuations
    if line.startswith('    ') or line.startswith('\t'):
        return True

    # Java/Python stack trace patterns
    continuation_patterns = [
        r'^\s+at ',           # Java stack trace
        r'^\s+File "',        # Python stack trace
        r'^Caused by:',       # Java exception chain
        r'^Traceback',        # Python traceback
    ]

    for pattern in continuation_patterns:
        if re.match(pattern, line):
            return True

    return False

def is_corrupted_line(line: str) -> bool:
    """
    Detects lines that are incomplete or corrupted.
    
    Examples of corrupted lines:
      "12.213.42.20"              ← just an IP, nothing else
      "GET"                        ← just a method, nothing else
      "---"                        ← just dashes
    """
    import re
    stripped = line.strip()

    # Just an IP address with nothing else
    if re.fullmatch(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', stripped):
        return True

    # Line is too short to be meaningful (less than 10 characters)
    if len(stripped) < 10:
        return True

    return False

def normalize_log_level(level_str: str) -> str:
    """
    Normalize different spellings of log levels.
    
    Examples:
      "err"   → "ERROR"
      "warn"  → "WARNING"
      "info"  → "INFO"
    """
    level_map = {
        "err": "ERROR",
        "error": "ERROR",
        "warn": "WARNING",
        "warning": "WARNING",
        "info": "INFO",
        "information": "INFO",
        "debug": "DEBUG",
        "dbg": "DEBUG",
        "critical": "CRITICAL",
        "crit": "CRITICAL",
        "fatal": "CRITICAL",
    }

    return level_map.get(level_str.lower(), level_str.upper())