# models.py
# Defines the data structure of a parsed log entry
# Pydantic automatically validates data types for us

from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class RawLogEntry(BaseModel):
    """
    Represents one raw unparsed line from a log file.
    This is the INPUT to our preprocessing pipeline.
    """
    line_number: int          # Which line in the file
    raw_text: str             # The original unprocessed text


class StructuredLogEntry(BaseModel):
    """
    Represents one fully parsed and structured log entry.
    This is the OUTPUT of our preprocessing pipeline.
    ML model in Module 3 will consume this.
    """
    line_number: int
    timestamp: Optional[str] = None      # When the event happened
    level: Optional[str] = None          # INFO, ERROR, WARNING, DEBUG
    service: Optional[str] = None        # Which service/component
    message: str                         # The actual log message
    is_error: bool = False               # Quick flag for errors
    is_warning: bool = False             # Quick flag for warnings
    raw_text: str                        # Original line (kept for reference)


class PreprocessingResult(BaseModel):
    """
    The final result returned after processing an entire log file.
    """
    filename: str
    total_lines: int
    parsed_lines: int
    failed_lines: int
    error_count: int
    warning_count: int
    info_count: int
    structured_logs: list[StructuredLogEntry]