# parser.py
# The core of Module 2 — reads each log line and extracts:
# timestamp, log level, service name, and message
# Handles: Standard logs, Apache/Nginx logs, Multiple entries per line

import re
from loguru import logger
from models import RawLogEntry, StructuredLogEntry
from cleaner import clean_line, is_empty_line, normalize_log_level, is_corrupted_line


# ─────────────────────────────────────────────
# Define common log patterns using Regex
# We try each pattern until one matches
# ─────────────────────────────────────────────

LOG_PATTERNS = [

    # Pattern 0: Apache/Nginx Access Log (HIGHEST PRIORITY)
    # Example: 147.144.103.249 - - [27/Dec/2037:12:00:00 +0530] "PUT /usr/login HTTP/1.0" 404 5042
    {
        "name": "apache_access_log",
        "regex": re.compile(
            r'(?P<client_ip>\d+\.\d+\.\d+\.\d+)'          # Client IP
            r'\s+-\s+-\s+'                                  # Identity & auth (ignored)
            r'\[(?P<timestamp>[^\]]+)\]'                    # [Timestamp]
            r'\s+"(?P<method>\w+)'                          # HTTP Method
            r'\s+(?P<url>\S+)'                              # URL path
            r'\s+(?P<protocol>[^"]+)"'                      # Protocol
            r'\s+(?P<status_code>\d+)'                      # Status code
            r'\s+(?P<size>\d+)'                             # Response size
            r'(?:\s+"(?P<referrer>[^"]*)")?'                # Referrer URL
            r'(?:\s+"(?P<user_agent>[^"]*)")?',             # User agent
            re.IGNORECASE
        )
    },

    # Pattern 1: Standard format
    # Example: "2024-01-01 10:00:00 ERROR [DatabaseService] Connection failed"
    {
        "name": "standard",
        "regex": re.compile(
            r'(?P<timestamp>\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2})'
            r'\s+(?P<level>INFO|ERROR|WARNING|WARN|DEBUG|CRITICAL|FATAL)'
            r'(?:\s+\[(?P<service>[^\]]+)\])?'
            r'\s+(?P<message>.+)',
            re.IGNORECASE
        )
    },

    # Pattern 2: Log level first
    # Example: "ERROR 2024-01-01 10:00:00 Something went wrong"
    {
        "name": "level_first",
        "regex": re.compile(
            r'(?P<level>INFO|ERROR|WARNING|WARN|DEBUG|CRITICAL|FATAL)'
            r'\s+(?P<timestamp>\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2})'
            r'\s+(?P<message>.+)',
            re.IGNORECASE
        )
    },

    # Pattern 3: With milliseconds
    # Example: "2024-01-01 10:00:00.123 INFO Server started"
    {
        "name": "with_milliseconds",
        "regex": re.compile(
            r'(?P<timestamp>\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}\.\d+)'
            r'\s+(?P<level>INFO|ERROR|WARNING|WARN|DEBUG|CRITICAL|FATAL)'
            r'(?:\s+\[(?P<service>[^\]]+)\])?'
            r'\s+(?P<message>.+)',
            re.IGNORECASE
        )
    },

    # Pattern 4: Apache/Nginx error log style
    # Example: "[Mon Jan 01 10:00:00 2024] [error] Connection refused"
    {
        "name": "apache_error_log",
        "regex": re.compile(
            r'\[(?P<timestamp>[^\]]+)\]'
            r'\s+\[(?P<level>info|error|warn|debug|notice|critical)\]'
            r'\s+(?P<message>.+)',
            re.IGNORECASE
        )
    },

    # Pattern 5: Fallback — capture everything as message
    {
        "name": "message_only",
        "regex": re.compile(r'(?P<message>.+)')
    }
]


# ─────────────────────────────────────────────
# Split multiple entries packed on one line
# ─────────────────────────────────────────────

def split_multiple_entries(line: str) -> list[str]:
    """
    Some log files pack multiple entries on one line.
    This function splits them into individual entries.

    It detects a new entry by looking for an IP address pattern
    appearing in the middle of a line.

    Example input (2 entries on 1 line):
    "221.24.16.54 - - [27/Dec/2037...] ... 125.196.127.85 - - [27/Dec/2037...] ..."

    Output:
    ["221.24.16.54 - - [27/Dec/2037...] ...", "125.196.127.85 - - [27/Dec/2037...] ..."]
    """

    # Pattern to detect start of a new log entry (starts with IP address)
    ip_pattern = re.compile(
        r'(?=\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\s+-\s+-\s+\[)'
    )

    # Split wherever a new IP entry begins
    parts = ip_pattern.split(line)

    # Remove empty strings
    parts = [p.strip() for p in parts if p.strip()]

    return parts


# ─────────────────────────────────────────────
# Parse a single log line
# ─────────────────────────────────────────────

def parse_single_line(raw_entry: RawLogEntry) -> StructuredLogEntry:
    """
    Takes one raw log line and returns a structured log entry.
    Tries each regex pattern one by one until one matches.
    """

    # Clean the line first
    cleaned = clean_line(raw_entry.raw_text)

    # Skip empty lines
    if is_empty_line(cleaned):
        return StructuredLogEntry(
            line_number=raw_entry.line_number,
            message="[empty line]",
            raw_text=raw_entry.raw_text
        )
    if is_corrupted_line(cleaned):
        logger.warning(f"Line {raw_entry.line_number} is corrupted: '{cleaned}'")
        return StructuredLogEntry(
            line_number=raw_entry.line_number,
            level="WARNING",
            message=f"[corrupted entry] {cleaned}",
            is_warning=True,
            raw_text=raw_entry.raw_text 
        )
    # Try each pattern
    for pattern in LOG_PATTERNS:
        match = pattern["regex"].match(cleaned)

        if match:
            groups = match.groupdict()
            pattern_name = pattern["name"]

            # ─────────────────────────────────────────────
            # Special handling for Apache Access Log
            # ─────────────────────────────────────────────
            if pattern_name == "apache_access_log":
                status_code = int(groups.get("status_code", 200))

                # Determine log level from HTTP status code
                # 2xx = INFO, 3xx = INFO, 4xx = WARNING, 5xx = ERROR
                if status_code >= 500:
                    level = "ERROR"
                elif status_code >= 400:
                    level = "WARNING"
                else:
                    level = "INFO"

                method  = groups.get("method", "UNKNOWN")
                url     = groups.get("url", "/")
                size    = groups.get("size", "0")
                message = f"{method} {url} → {status_code} ({size} bytes)"

                logger.debug(
                    f"Line {raw_entry.line_number} | "
                    f"Apache Access Log | "
                    f"IP: {groups.get('client_ip')} | "
                    f"Status: {status_code}"
                )

                return StructuredLogEntry(
                    line_number=raw_entry.line_number,
                    timestamp=groups.get("timestamp"),
                    level=level,
                    service=f"WebServer [{groups.get('client_ip')}]",
                    message=message,
                    is_error=status_code >= 500,
                    is_warning=400 <= status_code < 500,
                    raw_text=raw_entry.raw_text
                )

            # ─────────────────────────────────────────────
            # Standard handling for all other patterns
            # ─────────────────────────────────────────────
            timestamp = groups.get("timestamp", None)
            level_raw = groups.get("level", None)
            service   = groups.get("service", None)
            message   = groups.get("message", cleaned)

            level = normalize_log_level(level_raw) if level_raw else None

            logger.debug(
                f"Line {raw_entry.line_number} matched pattern: {pattern_name}"
            )

            return StructuredLogEntry(
                line_number=raw_entry.line_number,
                timestamp=timestamp,
                level=level,
                service=service,
                message=message.strip() if message else cleaned,
                is_error=level in ("ERROR", "CRITICAL") if level else False,
                is_warning=level == "WARNING" if level else False,
                raw_text=raw_entry.raw_text
            )

    # Should never reach here due to fallback pattern
    return StructuredLogEntry(
        line_number=raw_entry.line_number,
        message=cleaned,
        raw_text=raw_entry.raw_text
    )


# ─────────────────────────────────────────────
# Parse entire log file content
# ─────────────────────────────────────────────

def parse_log_file_content(content: str) -> list[StructuredLogEntry]:
    """
    Parses an entire log file content line by line.
    Also handles multiple entries packed on a single line.
    """
    lines = content.split('\n')
    results = []
    line_number = 1

    for line in lines:

        # Skip completely empty lines
        if not line.strip():
            line_number += 1
            continue

        # Check if this line contains multiple log entries
        sub_entries = split_multiple_entries(line)

        if len(sub_entries) > 1:
            # Multiple entries found on one line — parse each separately
            logger.debug(
                f"Line {line_number} contains "
                f"{len(sub_entries)} packed entries — splitting"
            )
            for sub_entry in sub_entries:
                raw_entry = RawLogEntry(
                    line_number=line_number,
                    raw_text=sub_entry
                )
                structured = parse_single_line(raw_entry)
                results.append(structured)
                line_number += 1
        else:
            # Normal single entry line
            raw_entry = RawLogEntry(
                line_number=line_number,
                raw_text=line
            )
            structured = parse_single_line(raw_entry)
            results.append(structured)
            line_number += 1

    logger.info(f"Parsed {len(results)} total entries from log content")
    return results