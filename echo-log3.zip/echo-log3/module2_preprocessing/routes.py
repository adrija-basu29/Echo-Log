# routes.py
# API endpoints for Module 2

from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from loguru import logger
from parser import parse_log_file_content
from structurer import build_preprocessing_result, get_error_summary
import httpx

router = APIRouter()


# ─────────────────────────────────────────────
# ROUTE 1: Health Check
# ─────────────────────────────────────────────
@router.get("/health")
async def health_check():
    return {"status": "✅ Echo-Log Preprocessing API is running"}


# ─────────────────────────────────────────────
# ROUTE 2: Preprocess a log file
# URL: POST /preprocess
# ─────────────────────────────────────────────
@router.post("/preprocess")
async def preprocess_log(file: UploadFile = File(...)):
    """
    Accepts a log file, parses every line,
    and returns fully structured log data.
    """
    logger.info(f"Preprocessing file: {file.filename}")

    # Read file content
    try:
        content_bytes = await file.read()
        # Decode bytes to string (handle different encodings)
        try:
            content = content_bytes.decode("utf-8")
        except UnicodeDecodeError:
            content = content_bytes.decode("latin-1")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not read file: {e}")

    # Parse the content line by line
    structured_logs = parse_log_file_content(content)

    # Build final result
    result = build_preprocessing_result(file.filename, structured_logs)

    return JSONResponse(
        status_code=200,
        content=result.model_dump()
    )


# ─────────────────────────────────────────────
# ROUTE 3: Get only errors from a log file
# URL: POST /errors-only
# ─────────────────────────────────────────────
@router.post("/errors-only")
async def get_errors_only(file: UploadFile = File(...)):
    """
    Returns only ERROR and CRITICAL entries from the log file.
    Quick way to see what went wrong.
    """
    content_bytes = await file.read()
    try:
        content = content_bytes.decode("utf-8")
    except UnicodeDecodeError:
        content = content_bytes.decode("latin-1")

    structured_logs = parse_log_file_content(content)
    errors = get_error_summary(structured_logs)

    return JSONResponse(
        status_code=200,
        content={
            "total_errors": len(errors),
            "errors": errors
        }
    )


# automatically the json file will flow to the next module

@router.post("/preprocess-and-analyze")
async def preprocess_and_analyze(file: UploadFile = File(...)):
    """
    One shot endpoint:
    Upload log file → Module 2 preprocesses → 
    Automatically sends to Module 3 → Returns anomaly report
    """
    # Step 1: Preprocess (Module 2)
    content_bytes = await file.read()
    content = content_bytes.decode("utf-8")
    structured_logs = parse_log_file_content(content)
    result = build_preprocessing_result(file.filename, structured_logs)

    # Step 2: Automatically send to Module 3
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "http://localhost:8002/api/v3/analyze",
            json=result.model_dump(),
            timeout=60.0
        )

    return response.json()