# structurer.py
# Takes all parsed log entries and builds a final structured result
# Also uses Drain3 for log template extraction

from loguru import logger
from models import StructuredLogEntry, PreprocessingResult


def build_preprocessing_result(
    filename: str,
    structured_logs: list[StructuredLogEntry]
) -> PreprocessingResult:
    """
    Takes a list of structured log entries and builds a summary.
    
    Counts errors, warnings, info messages etc.
    This summary goes to Module 3 for ML analysis.
    """

    total_lines = len(structured_logs)

    # Count how many lines were successfully parsed
    # (lines with a detected level are considered "parsed")
    parsed_lines = sum(1 for log in structured_logs if log.level is not None)
    failed_lines = total_lines - parsed_lines

    # Count by severity
    error_count = sum(1 for log in structured_logs if log.is_error)
    warning_count = sum(1 for log in structured_logs if log.is_warning)
    info_count = sum(1 for log in structured_logs if log.level == "INFO")

    logger.info(
        f"File: {filename} | "
        f"Total: {total_lines} | "
        f"Errors: {error_count} | "
        f"Warnings: {warning_count}"
    )

    return PreprocessingResult(
        filename=filename,
        total_lines=total_lines,
        parsed_lines=parsed_lines,
        failed_lines=failed_lines,
        error_count=error_count,
        warning_count=warning_count,
        info_count=info_count,
        structured_logs=structured_logs
    )


def get_error_summary(structured_logs: list[StructuredLogEntry]) -> list[dict]:
    """
    Extracts only the error and critical log entries.
    Useful for quick error review without going through all logs.
    """
    errors = [
        {
            "line": log.line_number,
            "timestamp": log.timestamp,
            "service": log.service,
            "message": log.message
        }
        for log in structured_logs
        if log.is_error
    ]
    return errors