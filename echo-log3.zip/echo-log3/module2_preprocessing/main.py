# main.py
from fastapi import FastAPI
from loguru import logger
import uvicorn
import os
from routes import router

app = FastAPI(
    title="Echo-Log Preprocessing API",
    description="Module 2: Cleans and structures raw log files",
    version="1.0.0"
)

logger.add(
    "logs/preprocessing.log",
    rotation="10 MB",
    retention="7 days",
    level="INFO"
)

app.include_router(router, prefix="/api/v2")

@app.get("/")
async def root():
    return {
        "project": "Echo-Log",
        "module": "Log Preprocessing",
        "status": "running",
        "docs": "Visit /docs for interactive API documentation"
    }

if __name__ == "__main__":
    os.makedirs("logs", exist_ok=True)
    logger.info("🚀 Starting Echo-Log Preprocessing Server...")
    uvicorn.run("main:app", host="0.0.0.0", port=8001, reload=True)