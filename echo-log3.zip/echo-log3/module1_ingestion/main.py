# main.py
# This is the STARTING POINT of the application
# Run this file to launch the server

from fastapi import FastAPI
from loguru import logger
import uvicorn

# Import our routes
from routes import router

# ─────────────────────────────────────────────
# Create the FastAPI application instance
# ─────────────────────────────────────────────
app = FastAPI(
    title="Echo-Log Ingestion API",
    description="Module 1: Accepts and stores log files for AI analysis",
    version="1.0.0"
)

# ─────────────────────────────────────────────
# Setup Loguru — structured logging to file + console
# ─────────────────────────────────────────────
logger.add(
    "logs/ingestion.log",       # Save logs to this file
    rotation="10 MB",           # Create new file after 10MB
    retention="7 days",         # Keep logs for 7 days
    level="INFO",               # Log INFO and above
    format="{time} | {level} | {message}"
)

# ─────────────────────────────────────────────
# Register our routes with a URL prefix
# All routes in routes.py will be under /api/v1/
# Example: /upload becomes /api/v1/upload
# ─────────────────────────────────────────────
app.include_router(router, prefix="/api/v1")


# ─────────────────────────────────────────────
# Root endpoint
# ─────────────────────────────────────────────
@app.get("/")
async def root():
    return {
        "project": "Echo-Log",
        "module": "Log Ingestion",
        "status": "running",
        "docs": "Visit /docs for interactive API documentation"
    }


# ─────────────────────────────────────────────
# Run the server when this file is executed
# ─────────────────────────────────────────────
if __name__ == "__main__":
    import os
    os.makedirs("logs", exist_ok=True)  # Create logs folder
    os.makedirs("uploads", exist_ok=True)  # Create uploads folder

    logger.info("🚀 Starting Echo-Log Ingestion Server...")

    uvicorn.run(
        "main:app",
        host="0.0.0.0",   # Accept connections from any IP
        port=8000,         # Run on port 8000
        reload=True        # Auto-restart on code changes (dev mode)
    )