# routes.py
# Defines all the API "routes" (URLs) for the Log Ingestion module

from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from loguru import logger
from utils import generate_file_id, get_save_path, save_uploaded_file, validate_log_file
import os

# APIRouter is like a mini-app — groups related routes together
router = APIRouter()


# ─────────────────────────────────────────────
# ROUTE 1: Health Check
# URL: GET /health
# Purpose: Verify the server is running
# ─────────────────────────────────────────────
@router.get("/health")
async def health_check():
    """
    Simple endpoint to check if the API is alive.
    Like pinging someone to see if they're awake.
    """
    return {"status": "✅ Echo-Log Ingestion API is running"}


# ─────────────────────────────────────────────
# ROUTE 2: Upload Single Log File
# URL: POST /upload
# Purpose: Accept and save one log file
# ─────────────────────────────────────────────
@router.post("/upload")
async def upload_log_file(file: UploadFile = File(...)):
    """
    Accepts a single log file upload.
    
    UploadFile = FastAPI's built-in way to handle file uploads
    File(...)  = This field is REQUIRED (the ... means required)
    """

    logger.info(f"Incoming upload: {file.filename}")

    # Step 1: Validate the file
    is_valid, reason = validate_log_file(file.filename)
    if not is_valid:
        # HTTP 400 = Bad Request (user sent something wrong)
        raise HTTPException(status_code=400, detail=f"Invalid file: {reason}")

    # Step 2: Generate unique ID and save path
    file_id = generate_file_id()
    save_path = get_save_path(file.filename, file_id)

    # Step 3: Save the file to disk
    try:
        file_size = await save_uploaded_file(file, save_path)
    except Exception as e:
        logger.error(f"Failed to save file: {e}")
        # HTTP 500 = Internal Server Error (our fault)
        raise HTTPException(status_code=500, detail="Failed to save file")

    # Step 4: Return success response
    return JSONResponse(
        status_code=200,
        content={
            "message": "✅ Log file uploaded successfully",
            "file_id": file_id,
            "original_name": file.filename,
            "saved_as": save_path,
            "size_bytes": file_size,
        }
    )


# ─────────────────────────────────────────────
# ROUTE 3: Upload Multiple Log Files
# URL: POST /upload-multiple
# Purpose: Accept up to 10 log files at once
# ─────────────────────────────────────────────
@router.post("/upload-multiple")
async def upload_multiple_files(files: list[UploadFile] = File(...)):
    """
    Accepts multiple log files in one request.
    Useful when sending logs from many servers at once.
    """

    # Safety limit — don't allow too many files at once
    if len(files) > 10:
        raise HTTPException(status_code=400, detail="Max 10 files per request")

    results = []

    for file in files:
        # Validate each file
        is_valid, reason = validate_log_file(file.filename)
        if not is_valid:
            results.append({"file": file.filename, "status": "❌ Failed", "reason": reason})
            continue

        # Save each file
        try:
            file_id = generate_file_id()
            save_path = get_save_path(file.filename, file_id)
            file_size = await save_uploaded_file(file, save_path)
            results.append({
                "file": file.filename,
                "status": "✅ Success",
                "file_id": file_id,
                "size_bytes": file_size
            })
        except Exception as e:
            results.append({"file": file.filename, "status": "❌ Failed", "reason": str(e)})

    return JSONResponse(status_code=200, content={"results": results})


# ─────────────────────────────────────────────
# ROUTE 4: List All Uploaded Files
# URL: GET /files
# Purpose: Show all files currently stored
# ─────────────────────────────────────────────
@router.get("/files")
async def list_uploaded_files():
    """
    Returns a list of all log files that have been uploaded.
    Like checking your inbox.
    """
    upload_dir = "uploads"

    if not os.path.exists(upload_dir):
        return {"files": [], "total": 0}

    files = []
    for filename in os.listdir(upload_dir):
        filepath = os.path.join(upload_dir, filename)
        size = os.path.getsize(filepath)
        files.append({
            "filename": filename,
            "size_bytes": size,
            "path": filepath
        })

    return {
        "total_files": len(files),
        "files": files
    }