# utils.py
# This file contains helper functions used by our API

import os
import uuid
from datetime import datetime
from loguru import logger  # Better than Python's built-in logging

# Define the folder where uploaded log files will be stored
UPLOAD_DIR = "uploads"

# Make sure the uploads folder exists when the app starts
os.makedirs(UPLOAD_DIR, exist_ok=True)


def generate_file_id() -> str:
    """
    Generate a unique ID for each uploaded file.
    This prevents files with same names from overwriting each other.
    Example output: "a3f2c1d4"
    """
    return str(uuid.uuid4()).replace("-", "")[:8]


def get_save_path(original_filename: str, file_id: str) -> str:
    """
    Create a unique file path for saving the uploaded log file.
    
    Example:
      original: "server.log"
      saved as: "uploads/20250221_143022_a3f2c1d4_server.log"
    
    The timestamp + unique ID ensures no two files ever clash.
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_filename = f"{timestamp}_{file_id}_{original_filename}"
    return os.path.join(UPLOAD_DIR, safe_filename)


async def save_uploaded_file(file, file_path: str) -> int:
    """
    Save the uploaded file to disk asynchronously (non-blocking).
    
    'async' means Python won't freeze while saving — 
    it can handle other requests at the same time.
    
    Returns: size of saved file in bytes
    """
    import aiofiles  # Async file writing library

    total_bytes = 0

    # Open the file for writing in binary mode (works for all file types)
    async with aiofiles.open(file_path, 'wb') as out_file:
        # Read the file in chunks (4KB at a time)
        # This is important for LARGE log files — avoids memory overload
        while chunk := await file.read(1024 * 4):  # 4KB chunks
            await out_file.write(chunk)
            total_bytes += len(chunk)

    logger.info(f"File saved: {file_path} | Size: {total_bytes} bytes")
    return total_bytes


def validate_log_file(filename: str) -> tuple[bool, str]:
    """
    Check if the uploaded file is a valid log file.
    
    Returns:
      (True, "ok") if valid
      (False, "reason") if invalid
    """
    # Only allow these file extensions
    allowed_extensions = {".log", ".txt", ".csv", ".json", ".gz"}

    # Get the file extension (e.g., ".log" from "server.log")
    _, ext = os.path.splitext(filename.lower())

    if ext not in allowed_extensions:
        return False, f"File type '{ext}' not allowed. Use: {allowed_extensions}"

    # Block obviously wrong file names
    if len(filename) > 255:
        return False, "Filename too long"

    return True, "ok"