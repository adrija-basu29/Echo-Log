# scorer.py
# Computes anomaly scores + identifies reasons for ALL 16 log types
# Each log type has reasons for all 5 anomaly categories

import re
from loguru import logger

WEIGHTS = {"isolation_forest": 0.40, "lof": 0.35, "statistical": 0.25}

# ─────────────────────────────────────────────────────────────────────────────
# REASON PATTERNS — (regex, reason_text) for all 5 anomaly types per log type
# All patterns searched against the FULL combined text of all fields
# ─────────────────────────────────────────────────────────────────────────────

REASON_PATTERNS = {

    "Apache": [
        # High Error Rate
        (r'\[error\]|\[crit\]|\[alert\]|\[emerg\]', "Apache critical/error level log"),
        (r' 5\d\d | http.*5\d\d',                   "HTTP 5xx server error"),
        (r'segfault|core.*dump',                     "Apache worker crash / segfault"),
        (r'child.*exit|worker.*exit',                "Apache child process exited"),
        # Unauthorized Access
        (r' 403 |forbidden',                         "HTTP 403 Forbidden — access denied"),
        (r' 401 |unauthorized',                      "HTTP 401 Unauthorized"),
        (r'auth.*fail|invalid.*password',            "Authentication failure"),
        # Unusual Operations
        (r'"delete |"put |"patch ',                  "Unusual HTTP method (DELETE/PUT/PATCH)"),
        (r'cannot bind|bind.*fail',                  "Apache cannot bind to port"),
        (r'ssl.*error|certificate.*error',           "SSL/certificate error"),
        (r'proxy.*error|mod_jk.*error',              "Proxy/mod_jk connector error"),
        # Repeated Abuse
        (r'too many|rate.*limit|flood',              "Request flood / rate limit exceeded"),
        # Performance Issues
        (r'timeout|timed out|slow',                  "Apache timeout / slow response"),
        (r'connection.*reset|broken.*pipe',          "Connection reset / broken pipe"),
        (r'resource.*limit|overload',                "Resource limit / server overload"),
    ],

    "OpenSSH": [
        # High Error Rate
        (r'error|fatal',                             "SSH error / fatal condition"),
        # Unauthorized Access
        (r'failed password',                         "SSH failed password attempt"),
        (r'invalid user|illegal user',               "SSH invalid / illegal username"),
        (r'authentication failure|auth.*fail',       "SSH authentication failure"),
        (r'too many authentication',                 "Too many SSH authentication attempts"),
        (r'possible break.in|break.in attempt',      "Possible SSH break-in detected"),
        (r'no supported authentication',             "No supported SSH auth methods"),
        (r'failed publickey',                        "SSH public key authentication failed"),
        # Unusual Operations
        (r'reverse mapping.*fail|address.*not.*associated', "SSH reverse DNS mapping failure"),
        (r'preauth|disconnecting.*preauth',          "SSH connection dropped before auth"),
        (r'bad packet|corrupt.*mac',                 "SSH packet corruption / bad MAC"),
        (r'rsa key.*warning|host key.*changed',      "SSH host key warning"),
        # Repeated Abuse
        (r'failed password.*from|invalid user.*from', "Repeated SSH login failures from IP"),
        # Performance Issues
        (r'timeout|timed out|did not receive',       "SSH connection timeout"),
        (r'connection.*closed.*reset',               "SSH connection reset"),
    ],

    "Hadoop": [
        # High Error Rate
        (r'exception',                               "Hadoop exception thrown"),
        (r'job.*failed|task.*failed',                "Hadoop job / task failed"),
        (r'attempt.*failed|map.*failed|reduce.*failed', "Map/Reduce attempt failed"),
        (r'error',                                   "Hadoop error detected"),
        # Unauthorized Access
        (r'permission denied|access denied',         "Hadoop permission denied"),
        (r'authentication.*fail|not.*authorized',    "Hadoop authentication failure"),
        (r'security.*exception',                     "Hadoop security exception"),
        # Unusual Operations
        (r'outofmemory|out of memory',               "Hadoop JVM out of memory"),
        (r'node.*blacklisted|blacklisted',           "Compute node blacklisted"),
        (r'lost.*tracker|tracker.*lost',             "TaskTracker node lost"),
        (r'heartbeat.*miss|miss.*heartbeat',         "TaskTracker heartbeat missed"),
        (r'task.*killed|job.*abort',                 "Task killed / job aborted"),
        # Repeated Abuse
        (r'attempt_\w+',                             "Repeated task attempt retries"),
        (r'task.*retry|job.*retry',                  "Task / job retrying repeatedly"),
        # Performance Issues
        (r'timeout|timed out|slow|stall',            "Hadoop task timeout / stall"),
        (r'gc.*overhead|garbage.*collection',        "JVM GC overhead warning"),
        (r'disk.*full|no.*space',                    "Disk full — no space left"),
    ],

    "HDFS": [
        # High Error Rate
        (r'corrupt|corrupted',                       "HDFS block corruption detected"),
        (r'ioexception',                             "HDFS I/O exception"),
        (r'error|exception|failed',                  "HDFS error / exception"),
        # Unauthorized Access
        (r'permission denied|access denied',         "HDFS permission denied"),
        (r'not.*permitted|unauthorized',             "HDFS unauthorized access"),
        # Unusual Operations
        (r'replicat.*fail|under.replicated',         "HDFS block replication failure"),
        (r'missing.*block|block.*missing',           "HDFS block missing"),
        (r'checksum.*error|crc.*error',              "HDFS checksum / CRC error"),
        (r'datanode.*lost|dead.*datanode',           "DataNode lost / dead"),
        (r'disk.*fail|disk.*full|no.*space',         "Disk failure or full"),
        (r'quota.*exceed',                           "HDFS quota exceeded"),
        # Repeated Abuse
        (r'blk_-?\d+',                              "Repeated block ID error"),
        (r'failed.*connect|connect.*fail',           "Repeated HDFS connection failure"),
        # Performance Issues
        (r'timeout|timed out|slow',                  "HDFS operation timeout"),
        (r'waiting.*replication|decommission',       "HDFS replication / decommission delay"),
    ],

    "Spark": [
        # High Error Rate
        (r'executorlost|executor.*lost',             "Spark executor lost / crashed"),
        (r'stage.*failed|task.*failed|job.*failed',  "Spark stage / task / job failed"),
        (r'exception|error',                         "Spark exception / error"),
        # Unauthorized Access
        (r'permission denied|access denied',         "Spark permission denied"),
        (r'unauthorized|authentication.*fail',       "Spark authentication failure"),
        # Unusual Operations
        (r'outofmemory|out of memory|heap.*space',   "Spark executor out of memory"),
        (r'gc.*overhead|gc.*pause',                  "Spark JVM GC overhead"),
        (r'fetchfailed|shuffle.*fail',               "Spark shuffle / fetch failure"),
        (r'driver.*stopped|driver.*exit',            "Spark driver stopped"),
        (r'job.*aborted|broadcast.*timeout',         "Spark job aborted / broadcast timeout"),
        # Repeated Abuse
        (r'task.*retry|executor.*\d+.*lost',         "Spark repeated task / executor failure"),
        # Performance Issues
        (r'timeout|timed out|slow|straggler',        "Spark timeout / straggler task"),
        (r'waiting.*resource|backpressure',          "Spark resource starvation"),
    ],

    "Zookeeper": [
        # High Error Rate
        (r'exception|error|failed|failure',          "Zookeeper error / exception"),
        (r'connectionloss|session.*expired',         "Zookeeper session loss / expiry"),
        # Unauthorized Access
        (r'permission denied|access denied',         "Zookeeper permission denied"),
        (r'invalid.*acl|not.*authorized',            "Zookeeper ACL / authorization failure"),
        # Unusual Operations
        (r'leader.*election|new.*leader',            "Zookeeper leader election in progress"),
        (r'quorum.*lost|not.*enough.*participants',  "Zookeeper quorum lost"),
        (r'snap.*corrupt|log.*corrupt',              "Zookeeper snapshot / log corruption"),
        (r'too.*many.*connections',                  "Too many Zookeeper connections"),
        # Repeated Abuse
        (r'session.*timeout.*repeated|connectionloss.*repeated', "Repeated Zookeeper session timeouts"),
        (r'client.*disconnect',                      "Repeated client disconnections"),
        # Performance Issues
        (r'timeout|timed out|fsync.*threshold',      "Zookeeper timeout / fsync slow"),
        (r'high.*latency|slow.*request|sync.*slow',  "Zookeeper high latency"),
    ],

    "BGL": [
        # High Error Rate
        (r'fatal|severe|critical',                   "BGL fatal / severe / critical error"),
        (r'hardware.*error|hardware.*failure',       "BGL hardware failure"),
        (r'error|failed|failure',                    "BGL system error"),
        # Unauthorized Access
        (r'permission denied|access denied',         "BGL permission denied"),
        (r'unauthorized|authentication.*fail',       "BGL authentication failure"),
        # Unusual Operations
        (r'machine check|mce',                       "CPU machine check exception (MCE)"),
        (r'memory.*error|ecc.*error',                "Memory / ECC hardware error"),
        (r'cpu.*error|processor.*error',             "CPU / processor error"),
        (r'kernel.*panic|panic',                     "Kernel panic on BGL node"),
        (r'node.*fail|node.*down',                   "BGL compute node failure"),
        (r'rts.*error|ciod.*error',                  "Runtime system / I/O daemon error"),
        # Repeated Abuse
        (r'R\d{2}-M\d-N\d+',                        "Repeated errors on same BGL node"),
        # Performance Issues
        (r'timeout|latency|congestion|throttl',      "BGL network latency / congestion"),
        (r'link.*error|network.*error',              "BGL network link error"),
    ],

    "HPC": [
        # High Error Rate
        (r'error|failed|failure|fatal',              "HPC system error / failure"),
        (r'job.*fail|node.*fail',                    "HPC job / node failure"),
        # Unauthorized Access
        (r'permission denied|access denied',         "HPC permission denied"),
        (r'authentication.*fail|account.*locked',    "HPC authentication / account lockout"),
        (r'unauthorized|not.*authorized',            "HPC unauthorized access"),
        # Unusual Operations
        (r'node.*down|node.*fail',                   "HPC compute node down"),
        (r'memory.*error|cpu.*error',                "HPC memory / CPU error"),
        (r'mpi.*error|mpi.*abort',                   "MPI communication error / abort"),
        (r'scheduler.*error|queue.*error',           "HPC scheduler / queue error"),
        (r'job.*cancel|job.*kill',                   "HPC job cancelled / killed"),
        # Repeated Abuse
        (r'job.*retry|requeue',                      "HPC job repeated retry / requeue"),
        # Performance Issues
        (r'timeout|slow|stall|overload',             "HPC timeout / overload"),
        (r'waiting.*resource|queue.*full',           "HPC resource starvation / queue full"),
    ],

    "Thunderbird": [
        # High Error Rate
        (r'fatal|severe|critical|panic',             "Thunderbird fatal / critical error"),
        (r'hardware.*error|hardware.*failure',       "Thunderbird hardware failure"),
        (r'error|failed|failure',                    "Thunderbird system error"),
        # Unauthorized Access
        (r'permission denied|unauthorized',          "Thunderbird permission denied"),
        (r'authentication.*fail',                    "Thunderbird authentication failure"),
        # Unusual Operations
        (r'kernel.*panic|kernel.*error',             "Thunderbird kernel panic / error"),
        (r'node.*fail|node.*down',                   "Thunderbird compute node failure"),
        (r'network.*partition|partition.*event',     "Network partition event"),
        (r'rpc.*error|rpc.*fail',                    "RPC error / failure"),
        # Repeated Abuse
        (r'same.*node.*fail|node.*repeated',         "Same node failing repeatedly"),
        # Performance Issues
        (r'timeout|slow|latency|congestion',         "Thunderbird timeout / latency"),
    ],

    "Windows": [
        # High Error Rate
        (r'eventid.*1000|eventid.*1001',             "Windows application crash (EventID 1000/1001)"),
        (r'eventid.*7034|eventid.*7031',             "Windows service crash (EventID 7034/7031)"),
        (r'blue.screen|bsod',                        "Windows Blue Screen of Death"),
        (r'critical|error|failed|failure',           "Windows critical error"),
        # Unauthorized Access
        (r'eventid.*4625|failed.*logon|logon.*fail', "Windows failed logon (EventID 4625)"),
        (r'eventid.*4648',                           "Explicit credential logon (EventID 4648)"),
        (r'account.*lock|locked.*out',               "Windows account locked out"),
        (r'access.*denied|permission.*denied',       "Windows access denied"),
        (r'unauthorized',                            "Windows unauthorized access"),
        # Unusual Operations
        (r'eventid.*4698|scheduled.*task.*created',  "Scheduled task created — persistence risk (EventID 4698)"),
        (r'eventid.*4719|audit.*policy.*changed',    "Audit policy changed (EventID 4719)"),
        (r'eventid.*4720|user.*account.*created',    "New user account created (EventID 4720)"),
        (r'eventid.*4732|member.*added.*group',      "User added to privileged group (EventID 4732)"),
        (r'registry.*change|registry.*corrupt',      "Windows registry change / corruption"),
        # Repeated Abuse
        (r'multiple.*fail.*logon|brute.*force',      "Repeated failed logons — brute force"),
        (r'account.*lock',                           "Account locked due to repeated failures"),
        # Performance Issues
        (r'timeout|slow|high.*cpu|memory.*leak',     "Windows performance issue"),
        (r'eventid.*2019|eventid.*2020',             "Windows memory pool issue"),
    ],

    "Linux": [
        # High Error Rate
        (r'error|failed|failure|fatal',              "Linux system error / failure"),
        (r'kernel.*error|driver.*error|oops|bug:',   "Linux kernel error / oops"),
        # Unauthorized Access
        (r'permission denied|access denied',         "Linux permission denied"),
        (r'authentication.*fail|auth.*fail',         "Linux authentication failure"),
        (r'sudo.*fail|su.*fail|pam.*fail',           "Linux sudo / su / PAM failure"),
        (r'login.*fail|sshd.*fail',                  "Linux login / SSH failure"),
        # Unusual Operations
        (r'oom.killer|out.of.memory.*kill',          "Linux OOM killer — process killed"),
        (r'segfault|segmentation fault',             "Linux segmentation fault"),
        (r'kernel.*panic|panic',                     "Linux kernel panic"),
        (r'call.*trace|oops',                        "Linux kernel call trace / oops"),
        (r'soft.*lockup|hard.*lockup|hung.*task',    "Linux CPU lockup / hung task"),
        (r'rcu.*stall',                              "Linux RCU stall"),
        (r'i/o.*error|disk.*error|filesystem.*error',"Linux I/O / disk / filesystem error"),
        # Repeated Abuse
        (r'repeated.*fail|oom.*killed.*process',     "Repeated failures / OOM kills"),
        # Performance Issues
        (r'timeout|slow|high.*load|swap.*full',      "Linux timeout / high load / swap full"),
        (r'disk.*full|no.*space|cpu.*throttl',       "Linux disk full / CPU throttling"),
        (r'thermal',                                 "Linux thermal throttling"),
    ],

    "Android": [
        # High Error Rate
        (r'anr',                                     "Android ANR — App Not Responding"),
        (r'fatal.*exception|exception.*fatal',       "Android fatal exception / crash"),
        (r'error|crash|wtf/',                        "Android error / crash"),
        (r'stopped.*unexpectedly|force.*close',      "Android app stopped unexpectedly"),
        # Unauthorized Access
        (r'permission.*denied|securityexception',    "Android permission denied / SecurityException"),
        (r'not.*allowed|uid.*not.*allowed',          "Android operation not allowed for UID"),
        (r'permission.*not.*granted',                "Android permission not granted"),
        # Unusual Operations
        (r'outofmemoryerror',                        "Android out of memory error"),
        (r'nullpointerexception',                    "Android NullPointerException"),
        (r'stackoverflowerror',                      "Android StackOverflowError"),
        (r'watchdog.*expired|watchdog',              "Android watchdog expired"),
        (r'deadlock',                                "Android deadlock detected"),
        (r'native.*crash',                           "Android native code crash"),
        # Repeated Abuse
        (r'anr.*in.*\w+\.\w+',                      "Repeated ANR in same app package"),
        (r'fatal.*exception.*main',                  "Repeated fatal exception on main thread"),
        (r'low.*memory.*repeated',                   "Repeated low memory condition"),
        # Performance Issues
        (r'slow.*main.*thread',                      "Android slow main thread operation"),
        (r'gc.*pause|gc.*overhead',                  "Android GC pause / overhead"),
        (r'low.*memory|memory.*pressure',            "Android low memory / memory pressure"),
        (r'frame.*drop|jank',                        "Android frame drop / jank"),
        (r'battery.*drain',                          "Android excessive battery drain"),
    ],

    "HealthApp": [
        # High Error Rate
        (r'error|failed|failure|fatal',              "HealthApp error / failure"),
        (r'sensor.*fail|device.*fail',               "HealthApp sensor / device failure"),
        (r'exception',                               "HealthApp exception"),
        # Unauthorized Access
        (r'permission denied|access denied',         "HealthApp permission denied"),
        (r'unauthorized|authentication.*fail',       "HealthApp authentication failure"),
        # Unusual Operations
        (r'threshold.*exceed|exceed.*threshold',     "Health metric threshold exceeded"),
        (r'critical.*alert|alert.*critical',         "Critical health alert"),
        (r'sensor.*error|sensor.*fail',              "Health sensor error / failure"),
        (r'data.*missing|missing.*data',             "Health data missing"),
        (r'battery.*low|low.*battery',               "Device battery critically low"),
        (r'device.*disconnect',                      "Health device disconnected"),
        # Repeated Abuse
        (r'repeated.*error|alert.*storm',            "Repeated errors / alert storm"),
        (r'sensor.*repeated.*fail',                  "Sensor failing repeatedly"),
        # Performance Issues
        (r'timeout|slow|latency',                    "HealthApp timeout / latency"),
        (r'memory.*full|data.*delay|sync.*fail',     "HealthApp memory full / sync failure"),
    ],

    "Mac": [
        # High Error Rate
        (r'error|failed|failure|fatal',              "macOS error / failure"),
        (r'kernel.*error|crash',                     "macOS kernel error / crash"),
        # Unauthorized Access
        (r'permission denied|access denied',         "macOS permission denied"),
        (r'authentication.*fail|auth.*fail',         "macOS authentication failure"),
        (r'sudo.*fail|su.*fail|pam.*error',          "macOS sudo / PAM failure"),
        (r'keychain.*fail',                          "macOS keychain access failure"),
        # Unusual Operations
        (r'kernel.*panic|panic',                     "macOS kernel panic"),
        (r'segfault|segmentation fault',             "macOS segmentation fault"),
        (r'crash.*reporter|crash.*log',              "macOS app crash (Crash Reporter)"),
        (r'sandbox.*violation|sandbox.*deny',        "macOS sandbox violation"),
        (r'gatekeeper.*block',                       "macOS Gatekeeper block"),
        (r'disk.*full|no.*space',                    "macOS disk full"),
        # Repeated Abuse
        (r'crash.*loop|respawn.*too.*fast',          "macOS crash loop / respawning too fast"),
        # Performance Issues
        (r'timeout|slow|high.*cpu',                  "macOS timeout / high CPU"),
        (r'memory.*pressure|swap.*full',             "macOS memory pressure / swap full"),
        (r'thermal.*throttl',                        "macOS thermal throttling"),
    ],

    "Proxifier": [
        # High Error Rate
        (r'error|failed|failure',                    "Proxifier error / failure"),
        (r'connect.*error|connection.*error',        "Proxifier connection error"),
        # Unauthorized Access
        (r'access denied|denied',                    "Proxifier access denied"),
        (r'blocked|rule.*blocked',                   "Proxifier rule blocked connection"),
        (r'forbidden|unauthorized',                  "Proxifier forbidden / unauthorized"),
        (r'auth.*fail|authentication.*fail',         "Proxifier authentication failure"),
        # Unusual Operations
        (r'certificate.*error|ssl.*error',           "Proxifier SSL / certificate error"),
        (r'invalid.*certificate|cert.*fail',         "Proxifier invalid certificate"),
        (r'proxy.*chain.*fail|socks.*error',         "Proxifier proxy chain / SOCKS error"),
        # Repeated Abuse
        (r'repeated.*block|multiple.*deny',          "Repeated blocks / denials"),
        # Performance Issues
        (r'timeout|timed out|slow|latency',          "Proxifier timeout / slow connection"),
        (r'bandwidth',                               "Proxifier bandwidth issue"),
    ],

    "OpenStack": [
        # High Error Rate
        (r'exception|traceback',                     "OpenStack exception / traceback"),
        (r'error|failed|failure|fatal',              "OpenStack error / failure"),
        (r'http [45]\d\d',                           "OpenStack HTTP 4xx/5xx error"),
        # Unauthorized Access
        (r'unauthorized| 401 ',                      "OpenStack unauthorized (HTTP 401)"),
        (r' 403 |forbidden|access.*denied',          "OpenStack access denied (HTTP 403)"),
        (r'authentication.*fail|auth.*fail',         "OpenStack authentication failure"),
        (r'token.*invalid|token.*expired',           "OpenStack token invalid / expired"),
        (r'permission.*denied',                      "OpenStack permission denied"),
        # Unusual Operations
        (r'instance.*fail|vm.*fail',                 "OpenStack VM instance failure"),
        (r'quota.*exceed|resource.*exhaust',         "OpenStack quota / resource exhausted"),
        (r'neutron.*error|network.*fail',            "OpenStack Neutron network failure"),
        (r'nova.*error|compute.*fail',               "OpenStack Nova compute failure"),
        (r'cinder.*error|storage.*fail',             "OpenStack Cinder storage failure"),
        (r'glance.*error|image.*fail',               "OpenStack Glance image failure"),
        # Repeated Abuse
        (r'request.*flood|rate.*limit|too.*many',    "OpenStack request flood / rate limit"),
        # Performance Issues
        (r'timeout|timed out|slow|overload',         "OpenStack timeout / overload"),
        (r'high.*latency|queue.*full',               "OpenStack high latency / queue full"),
    ],
}

# Fallback patterns for unknown log types
FALLBACK_PATTERNS = [
    (r'fatal|critical',                  "Fatal / critical system error"),
    (r'error|exception|fail',            "System error / failure detected"),
    (r'panic|crash|abort',               "System panic / crash / abort"),
    (r'permission denied|unauthorized',  "Unauthorized / permission denied"),
    (r'timeout|slow',                    "Timeout / performance issue"),
    (r'corrupt|missing|lost',            "Data corruption / data loss"),
    (r'kill|killed',                     "Process killed by system"),
]


def compute_final_score(if_s, lof_s, stat_s) -> float:
    return round((if_s * WEIGHTS["isolation_forest"] +
                  lof_s * WEIGHTS["lof"] +
                  stat_s * WEIGHTS["statistical"]) * 100, 2)


def assign_severity(score: float) -> str:
    if score >= 85:   return "CRITICAL"
    elif score >= 70: return "HIGH"
    elif score >= 50: return "MEDIUM"
    elif score >= 30: return "LOW"
    else:             return "NORMAL"


def get_combined_text(entry: dict) -> str:
    parts = []
    for f in ["raw_text", "message", "event_template", "service"]:
        v = (entry.get(f) or "").strip()
        if v:
            parts.append(v)
    return " ".join(parts).lower()


def identify_reasons(entry: dict, score: float) -> list[str]:
    """Find anomaly reasons by matching patterns against combined text."""
    full     = get_combined_text(entry)
    log_type = (entry.get("log_type") or "Unknown").strip()
    features = entry.get("_features") or {}
    reasons  = []

    # ── Log-type specific patterns ────────────────────
    patterns = REASON_PATTERNS.get(log_type, FALLBACK_PATTERNS)
    for regex, reason in patterns:
        try:
            if re.search(regex, full) and reason not in reasons:
                reasons.append(reason)
        except re.error:
            if regex in full and reason not in reasons:
                reasons.append(reason)
        if len(reasons) >= 6:
            break

    # ── Feature-based reasons (universal) ────────────
    status = features.get("status_code", 0)
    if status >= 500:
        r = f"HTTP {int(status)} server error"
        if r not in reasons:
            reasons.append(r)
    elif status == 403:
        r = "HTTP 403 Forbidden"
        if r not in reasons:
            reasons.append(r)

    ip_freq = features.get("ip_frequency", 0)
    if features.get("ip_is_high_frequency", 0) or ip_freq > 3:
        r = f"High request frequency from same source ({int(ip_freq)} times)"
        if r not in reasons:
            reasons.append(r)

    if features.get("response_time", 0) > 4000:
        r = f"High response time ({int(features['response_time'])}ms)"
        if r not in reasons:
            reasons.append(r)

    # ── If still empty after all checks ──────────────
    if not reasons:
        if score >= 70:
            reasons.append("Statistical outlier detected by ML ensemble")
        else:
            reasons.append("Slight deviation from normal log pattern")

    return reasons[:6]


def build_anomaly_results(entries, if_scores, lof_scores, stat_scores, feature_rows) -> list[dict]:
    results = []
    for i, entry in enumerate(entries):
        score    = compute_final_score(float(if_scores[i]), float(lof_scores[i]), float(stat_scores[i]))
        severity = assign_severity(score)
        entry["_features"] = feature_rows[i]
        results.append({
            "line_number":            entry.get("line_number", i + 1),
            "raw_text":               (entry.get("raw_text") or ""),
            "log_type":               (entry.get("log_type") or "Unknown"),
            "anomaly_score":          score,
            "is_anomaly":             score >= 30,
            "severity":               severity,
            "anomaly_reasons":        identify_reasons(entry, score),
            "isolation_forest_score": round(float(if_scores[i])   * 100, 2),
            "lof_score":              round(float(lof_scores[i])   * 100, 2),
            "statistical_score":      round(float(stat_scores[i]) * 100, 2),
        })
    return results
