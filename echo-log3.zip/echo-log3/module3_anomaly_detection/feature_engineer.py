# feature_engineer.py
# 25 features per entry — works for ALL 16 loghub log types
# Always uses raw_text as primary source

import re
import pandas as pd
import numpy as np
from loguru import logger
from collections import Counter
from log_schemas import (
    ANOMALY_KEYWORDS, NORMAL_KEYWORDS,
    SECURITY_KEYWORDS, CONNECTION_KEYWORDS,
    LOG_TYPE_ERROR_KEYWORDS
)

LEVEL_MAP = {
    "INFO": 1, "I": 1, "NOTICE": 1, "DEBUG": 0, "D": 0,
    "VERBOSE": 0, "V": 0, "WARNING": 2, "WARN": 2, "W": 2,
    "ERROR": 3, "E": 3, "CRITICAL": 4, "FATAL": 4, "F": 4,
}

SENSITIVE_COMPONENTS = [
    "admin", "root", "auth", "security", "kernel",
    "ssh", "sudo", "cron", "firewall", "iptables",
    "sshd", "su", "login", "passwd",
]

URL_SENSITIVITY = {
    "/usr/admin/developer": 10, "/usr/admin": 8,
    "/usr/login": 5, "/usr/register": 3, "/usr": 1,
}


def get_all_text(entry: dict) -> str:
    """Combine ALL text fields — raw_text always first."""
    parts = []
    for f in ["raw_text", "message", "event_template", "service"]:
        v = (entry.get(f) or "").strip()
        if v and v not in parts:
            parts.append(v)
    return " ".join(parts).lower()


def encode_level(level) -> int:
    if not level:
        return 1
    return LEVEL_MAP.get(str(level).upper().strip(), 1)


def extract_ip(entry: dict) -> str:
    for field in ["raw_text", "service", "message"]:
        t = (entry.get(field) or "").strip()
        for pat in [
            r'^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})',
            r'from\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})',
            r'\[(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\]',
            r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})',
        ]:
            m = re.search(pat, t)
            if m:
                return m.group(1)
    return "unknown"


def extract_status_code(text: str) -> int:
    for pat in [r'→\s*(\d{3})', r'\b([2-5]\d{2})\b']:
        m = re.search(pat, text)
        if m:
            return int(m.group(1))
    return -1


def encode_http_method(text: str) -> int:
    for method, val in [("DELETE", 4), ("PATCH", 5), ("PUT", 3),
                        ("POST", 2), ("GET", 1), ("HEAD", 6), ("OPTIONS", 7)]:
        if method in text.upper():
            return val
    return -1


def compute_ip_frequency(entries: list) -> tuple[dict, float]:
    counts = Counter()
    for e in entries:
        ip = extract_ip(e)
        if ip != "unknown":
            counts[ip] += 1
    if not counts:
        return {}, 3.0
    vals = list(counts.values())
    threshold = max(2.0, min(max(len(entries) * 0.04, 2), np.mean(vals) + np.std(vals)))
    return dict(counts), threshold


def engineer_features(entries: list[dict]) -> pd.DataFrame:
    logger.info(f"Engineering features for {len(entries)} entries...")
    ip_freq, ip_threshold = compute_ip_frequency(entries)

    rows = []
    for entry in entries:
        ip      = extract_ip(entry)
        ip_cnt  = ip_freq.get(ip, 1)
        ip_high = int(ip_cnt > ip_threshold)

        # Re-use pre-computed features from trainer if present
        if entry.get("_features"):
            pre = entry["_features"]
            pre["has_ip"] = int(ip != "unknown")
            pre["ip_frequency"] = ip_cnt
            pre["ip_is_high_frequency"] = ip_high
            rows.append(pre)
            continue

        full   = get_all_text(entry)
        raw    = (entry.get("raw_text") or "").lower()
        level  = entry.get("level")
        svc    = (entry.get("service") or "")
        comp   = re.split(r'[\[\(]', svc)[0].strip().lower()
        lt     = (entry.get("log_type") or "")
        lenc   = encode_level(level)
        sc     = extract_status_code(raw)
        menc   = encode_http_method(raw)

        # is_error — level field OR log-type keywords in full text
        err_kws = LOG_TYPE_ERROR_KEYWORDS.get(lt, ["error","fail","fatal","exception","crash"])
        is_err  = int(lenc >= 3 or bool(entry.get("is_error")) or any(k in full for k in err_kws))
        is_warn = int(lenc == 2 or bool(entry.get("is_warning")) or
                      any(w in full for w in ["warn", "warning", "caution"]))

        rows.append({
            # Level (3)
            "level_encoded": lenc,
            "is_error":      is_err,
            "is_warning":    is_warn,
            # Universal keywords (4)
            "has_anomaly_keyword":    int(any(w in full for w in ANOMALY_KEYWORDS)),
            "has_normal_keyword":     int(any(w in full for w in NORMAL_KEYWORDS)),
            "has_security_keyword":   int(any(w in full for w in SECURITY_KEYWORDS)),
            "has_connection_keyword": int(any(w in full for w in CONNECTION_KEYWORDS)),
            # HTTP (8)
            "method_encoded": menc,
            "status_code":    max(sc, 0),
            "status_4xx":     int(400 <= sc < 500) if sc > 0 else 0,
            "status_5xx":     int(sc >= 500)       if sc > 0 else 0,
            "status_403":     int(sc == 403),
            "status_404":     int(sc == 404),
            "status_500":     int(sc == 500),
            "status_502":     int(sc == 502),
            # Endpoint (3)
            "url_sensitivity": next((v for u, v in URL_SENSITIVITY.items() if u in full), 0),
            "is_admin_endpoint":         int(any(k in full for k in ["/admin","/developer","/root","/superuser"])),
            "dangerous_method_on_admin": int(menc >= 3 and any(k in full for k in ["/admin","/developer"])),
            # Size & Time (3)
            "response_size":  int(re.findall(r'\b(\d+)\b', raw)[-2]) if len(re.findall(r'\b(\d+)\b', raw)) >= 2 else 0,
            "response_time":  int(re.findall(r'\b(\d+)\b', raw)[-1]) if re.findall(r'\b(\d+)\b', raw) else 0,
            "message_length": len(full),
            # Component (1)
            "is_sensitive_component": int(any(s in comp for s in SENSITIVE_COMPONENTS) or
                                          any(s in full for s in SENSITIVE_COMPONENTS)),
            # IP (3)
            "has_ip":               int(ip != "unknown"),
            "ip_frequency":         ip_cnt,
            "ip_is_high_frequency": ip_high,
        })

    df = pd.DataFrame(rows).fillna(0)
    logger.info(f"Feature matrix: {df.shape[0]} × {df.shape[1]}")
    return df
