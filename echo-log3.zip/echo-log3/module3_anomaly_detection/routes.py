# routes.py — All FastAPI endpoints for Module 3 Anomaly Detection

import os
import json
from fastapi import APIRouter, HTTPException, UploadFile, File
from fastapi.responses import JSONResponse
from typing import List
from loguru import logger
from pydantic import BaseModel
from typing import Optional

from anomaly_detector import run_detection_pipeline, save_feedback, load_feedback
from evaluator import generate_full_evaluation
from trainer import train_on_multiple_files

router = APIRouter()


# ── Request / Response Schemas ────────────────────────────────────────────────

class LogEntry(BaseModel):
    line_number:    int
    timestamp:      Optional[str] = None
    level:          Optional[str] = None
    service:        Optional[str] = None
    message:        str           = ""
    is_error:       bool          = False
    is_warning:     bool          = False
    raw_text:       str           = ""
    log_type:       Optional[str] = None
    event_template: Optional[str] = None

class AnalyzeRequest(BaseModel):
    structured_logs: List[LogEntry]

class FeedbackRequest(BaseModel):
    line_number:       int
    raw_text:          str
    confirmed_anomaly: bool
    log_type:          Optional[str] = None


# ── Helper ────────────────────────────────────────────────────────────────────

def entries_from_request(req: AnalyzeRequest) -> list[dict]:
    entries = []
    for log in req.structured_logs:
        d = log.dict()
        # Ensure raw_text always has content
        if not d.get("raw_text"):
            parts = [str(d.get(f) or "") for f in ["timestamp", "level", "service", "message"]]
            d["raw_text"] = " ".join(p for p in parts if p)
        if not d.get("message"):
            d["message"] = d.get("raw_text", "")
        if not d.get("event_template"):
            d["event_template"] = ""
        entries.append(d)
    return entries


# ── Routes ────────────────────────────────────────────────────────────────────

@router.post("/analyze")
async def analyze(request: AnalyzeRequest):
    """Run anomaly detection — returns detection report (no graphs)."""
    entries = entries_from_request(request)
    if not entries:
        raise HTTPException(status_code=400, detail="No log entries provided")
    if len(entries) > 50000:
        raise HTTPException(status_code=400, detail="Max 50,000 entries per request")

    logger.info(f"POST /analyze — {len(entries)} entries")
    try:
        report = run_detection_pipeline(entries)
        return {"status": "success", "detection_report": report}
    except Exception as e:
        logger.error(f"Detection failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/analyze-and-evaluate")
async def analyze_and_evaluate(request: AnalyzeRequest):
    """Run anomaly detection + generate all 7 performance graphs."""
    entries = entries_from_request(request)
    if not entries:
        raise HTTPException(status_code=400, detail="No log entries provided")
    if len(entries) > 50000:
        raise HTTPException(status_code=400, detail="Max 50,000 entries per request")

    logger.info(f"POST /analyze-and-evaluate — {len(entries)} entries")
    try:
        report     = run_detection_pipeline(entries)
        evaluation = generate_full_evaluation(report)

        return {
            "status":             "success",
            "detection_report":   {k: v for k, v in report.items() if k != "results"},
            "results":            report.get("results", []),
            "performance_metrics": evaluation.get("metrics", {}),
            "anomaly_type_analysis": report.get("anomaly_type_analysis", {}),
            "graphs_generated":   evaluation.get("graphs_generated", 0),
            "graph_paths":        evaluation.get("graph_paths", {}),
        }
    except Exception as e:
        logger.error(f"Analyze+Evaluate failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/critical-only")
async def critical_only(request: AnalyzeRequest):
    """Returns only CRITICAL and HIGH severity anomalies."""
    entries = entries_from_request(request)
    if not entries:
        raise HTTPException(status_code=400, detail="No log entries provided")

    logger.info(f"POST /critical-only — {len(entries)} entries")
    try:
        report  = run_detection_pipeline(entries)
        results = report.get("results", [])
        critical_results = [r for r in results if r.get("severity") in ("CRITICAL", "HIGH")]
        return {
            "status":          "success",
            "total_analyzed":  len(results),
            "critical_count":  report.get("critical_count", 0),
            "high_count":      report.get("high_count", 0),
            "critical_and_high": critical_results,
        }
    except Exception as e:
        logger.error(f"Critical-only failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/retrain")
async def retrain(request: AnalyzeRequest):
    """Force retrain model on provided log data."""
    entries = entries_from_request(request)
    if not entries:
        raise HTTPException(status_code=400, detail="No log entries provided")

    logger.info(f"POST /retrain — {len(entries)} entries")
    try:
        report = run_detection_pipeline(entries, force_retrain=True)
        return {
            "status":  "success",
            "message": "Model retrained successfully",
            "total_entries_used": len(entries),
        }
    except Exception as e:
        logger.error(f"Retrain failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/train-loghub")
async def train_loghub(files: List[UploadFile] = File(...)):
    """
    Train on loghub datasets — accepts all 16 log types.
    Upload raw .log, _structured.csv, and _templates.csv files.
    """
    if not files:
        raise HTTPException(status_code=400, detail="No files provided")

    logger.info(f"POST /train-loghub — {len(files)} files received")

    # Save uploaded files to training_data directory
    os.makedirs("training_data", exist_ok=True)
    saved_paths = []

    for upload in files:
        save_path = os.path.join("training_data", upload.filename)
        content   = await upload.read()
        with open(save_path, "wb") as f:
            f.write(content)
        saved_paths.append(save_path)
        logger.info(f"Saved: {upload.filename} ({len(content):,} bytes)")

    try:
        result = train_on_multiple_files(saved_paths)
        if result.get("status") == "error":
            raise HTTPException(status_code=400, detail=result.get("message"))
        return {"status": "success", "training_result": result}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Training failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/training-status")
async def training_status():
    """Check current training status and model metadata."""
    meta_path  = "saved_models/training_metadata.json"
    model_path = "saved_models/isolation_forest.pkl"
    scaler_path = "saved_models/scaler.pkl"

    if not os.path.exists(model_path):
        return {"status": "not_trained", "message": "Model not trained yet. Run /train-loghub first."}

    metadata = {}
    if os.path.exists(meta_path):
        with open(meta_path) as f:
            metadata = json.load(f)

    return {
        "status":         "trained",
        "model_exists":   os.path.exists(model_path),
        "scaler_exists":  os.path.exists(scaler_path),
        "model_size_kb":  round(os.path.getsize(model_path) / 1024, 1) if os.path.exists(model_path) else 0,
        "metadata":       metadata,
    }


@router.post("/feedback")
async def feedback(request: FeedbackRequest):
    """Submit feedback on whether a flagged entry is truly anomalous."""
    entry = {
        "line_number": request.line_number,
        "raw_text":    request.raw_text,
        "log_type":    request.log_type or "Unknown",
    }
    save_feedback(entry, request.confirmed_anomaly)
    fb = load_feedback()
    return {
        "status":           "saved",
        "confirmed_anomaly": request.confirmed_anomaly,
        "total_feedback":   len(fb.get("anomalies", [])) + len(fb.get("normals", [])),
    }


@router.post("/retrain-with-feedback")
async def retrain_with_feedback():
    """Retrain model using accumulated human feedback data."""
    fb = load_feedback()
    all_entries = fb.get("anomalies", []) + fb.get("normals", [])

    if len(all_entries) < 10:
        raise HTTPException(
            status_code=400,
            detail=f"Need at least 10 feedback entries to retrain. Currently have {len(all_entries)}."
        )

    logger.info(f"Retraining with {len(all_entries)} feedback entries...")
    try:
        report = run_detection_pipeline(all_entries, force_retrain=True)
        return {
            "status":       "success",
            "message":      f"Model retrained with {len(all_entries)} feedback entries",
            "anomaly_feedback": len(fb.get("anomalies", [])),
            "normal_feedback":  len(fb.get("normals", [])),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/feedback-stats")
async def feedback_stats():
    """View current feedback statistics."""
    fb = load_feedback()
    return {
        "total_anomaly_feedback": len(fb.get("anomalies", [])),
        "total_normal_feedback":  len(fb.get("normals", [])),
        "total_feedback":         len(fb.get("anomalies", [])) + len(fb.get("normals", [])),
    }


@router.get("/health")
async def health():
    """Health check endpoint."""
    model_ok  = os.path.exists("saved_models/isolation_forest.pkl")
    scaler_ok = os.path.exists("saved_models/scaler.pkl")
    return {
        "status":      "healthy" if model_ok else "no_model",
        "model_ready": model_ok and scaler_ok,
        "port":        8002,
    }
