# schemas.py
# All data structures for Module 3

from pydantic import BaseModel
from typing import Optional


class LogEntry(BaseModel):
    line_number: int
    timestamp: Optional[str] = None
    level: Optional[str] = None
    service: Optional[str] = None
    message: str
    is_error: bool = False
    is_warning: bool = False
    raw_text: str


class AnomalyResult(BaseModel):
    line_number: int
    raw_text: str
    anomaly_score: float
    is_anomaly: bool
    severity: str
    anomaly_reasons: list[str]
    isolation_forest_score: float
    lof_score: float
    statistical_score: float


class AnomalyReport(BaseModel):
    total_entries: int
    anomaly_count: int
    normal_count: int
    anomaly_percentage: float
    critical_count: int
    high_count: int
    medium_count: int
    low_count: int
    high_error_rate_detected: bool
    unauthorized_access_detected: bool
    unusual_methods_detected: bool
    ip_abuse_detected: bool
    response_time_spike_detected: bool
    top_suspicious_ips: list[dict]
    results: list[AnomalyResult]
    model_trained_fresh: bool
    total_features_used: int
