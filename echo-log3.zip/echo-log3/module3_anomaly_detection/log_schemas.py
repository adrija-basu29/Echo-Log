# log_schemas.py
# Column mappings + comprehensive keyword banks for all 16 loghub log types

LOG_TYPE_SCHEMAS = {
    "HDFS":        {"date_col":"Date",  "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
    "Hadoop":      {"date_col":"Date",  "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
    "Spark":       {"date_col":"Date",  "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
    "Zookeeper":   {"date_col":"Date",  "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
    "BGL":         {"date_col":"Date",  "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
    "HPC":         {"date_col":"LogId", "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
    "Thunderbird": {"date_col":"Date",  "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
    "Windows":     {"date_col":"Date",  "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
    "Linux":       {"date_col":"Month", "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
    "Android":     {"date_col":"Date",  "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
    "HealthApp":   {"date_col":"Time",  "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
    "Apache":      {"date_col":"Time",  "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
    "OpenSSH":     {"date_col":"Date",  "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
    "OpenStack":   {"date_col":"Date",  "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
    "Mac":         {"date_col":"Month", "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
    "Proxifier":   {"date_col":"Time",  "time_col":"Time",  "level_col":"Level", "component_col":"Component", "content_col":"Content", "event_id_col":"EventId", "template_col":"EventTemplate"},
}

# ─────────────────────────────────────────────
# Universal Keyword Banks
# Used for feature engineering across all log types
# ─────────────────────────────────────────────

ANOMALY_KEYWORDS = [
    # Universal error words
    "error", "failure", "failed", "fail", "fatal", "critical",
    "exception", "refused", "denied", "rejected", "timeout",
    "crash", "panic", "killed", "abort", "invalid",
    "unauthorized", "forbidden", "blocked", "attack",
    "overflow", "corrupt", "missing", "lost", "down",
    # Log-type specific
    "outofmemory", "oom", "segfault", "deadlock", "anr",
    "executorlost", "blacklisted", "heartbeat",
    "break-in", "preauth", "illegal",
    "machine check", "hardware error",
    "replication", "checksum",
]

NORMAL_KEYWORDS = [
    "success", "completed", "started", "initialized",
    "connected", "accepted", "ok", "ready", "running",
    "healthy", "normal", "finished", "done", "info",
    "registered", "synced", "committed", "opened",
]

SECURITY_KEYWORDS = [
    "password", "authentication", "login", "ssh", "root",
    "sudo", "admin", "privilege", "permission", "access",
    "token", "certificate", "key", "credential",
    "auth", "failed password", "invalid user",
    "break-in", "illegal user",
]

CONNECTION_KEYWORDS = [
    "connection", "connect", "disconnect", "socket",
    "port", "bind", "listen", "timeout", "reset", "closed",
    "refused", "handshake", "session",
]

# ─────────────────────────────────────────────
# Per-Log-Type Error Keywords for Feature Engineering
# Used to detect is_error more accurately
# ─────────────────────────────────────────────

LOG_TYPE_ERROR_KEYWORDS = {
    "Hadoop":      ["failed", "exception", "error", "lost", "blacklisted", "outofmemory", "killed", "abort"],
    "HDFS":        ["corrupt", "failed", "exception", "lost", "missing", "error", "ioexception", "replication"],
    "Spark":       ["executorlost", "failed", "exception", "abort", "error", "fetchfailed", "lost"],
    "OpenSSH":     ["failed", "invalid", "error", "refused", "break-in", "illegal", "disconnect", "preauth"],
    "Linux":       ["error", "fail", "panic", "segfault", "oom", "killed", "lockup", "oops", "trace"],
    "Windows":     ["error", "fail", "crash", "4625", "7034", "critical", "bsod", "failed logon"],
    "BGL":         ["fatal", "error", "fail", "panic", "hardware", "machine check", "severe"],
    "Android":     ["anr", "fatal", "error", "crash", "exception", "oom", "deadlock", "not responding"],
    "Mac":         ["panic", "crash", "error", "fail", "denied", "violation", "segfault"],
    "OpenStack":   ["error", "fail", "exception", "timeout", "unauthorized", "traceback", "fault"],
    "Proxifier":   ["blocked", "denied", "timeout", "error", "fail", "refused"],
    "Zookeeper":   ["error", "fail", "expire", "timeout", "loss", "exception", "connectionloss"],
    "Thunderbird": ["fatal", "error", "fail", "panic", "partition", "severe"],
    "HPC":         ["error", "fail", "down", "crash", "mpi", "abort"],
    "HealthApp":   ["error", "warning", "fail", "critical", "threshold", "sensor fail"],
    "Apache":      ["error", "fail", "denied", "segfault", "killed", "crit", "alert", "emerg"],
}

# ─────────────────────────────────────────────
# All 5 Anomaly Type Patterns Per Log Type
# Used by reporter.py for comprehensive detection
# Format: {"anomaly_type": [regex_patterns]}
# ─────────────────────────────────────────────

LOG_TYPE_ALL_ANOMALIES = {

    "Apache": {
        "high_error_rate": [
            r"\[error\]", r"\[crit\]", r"\[alert\]", r"\[emerg\]",
            r" 5\d\d ", r"http.*5\d\d", r"error", r"fail",
            r"mod_jk.*error", r"worker.*error", r"child.*exit",
            r"segfault", r"abort", r"core.*dump",
        ],
        "unauthorized_access": [
            r" 403 ", r"forbidden", r"access denied", r"auth.*fail",
            r" 401 ", r"unauthorized", r"invalid.*password",
            r"authentication.*required",
        ],
        "unusual_operations": [
            r'"delete ', r'"put ', r'"patch ',
            r"cannot bind", r"bind.*fail",
            r"child.*killed", r"worker.*killed",
            r"rewrite.*fail", r"proxy.*error",
            r"ssl.*error", r"certificate.*error",
        ],
        "repeated_abuse": [
            r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}",
            r"too many", r"rate.*limit", r"flood",
        ],
        "performance_issues": [
            r"timeout", r"timed out", r"slow",
            r"connection.*reset", r"broken.*pipe",
            r"resource.*limit", r"overload",
        ],
    },

    "OpenSSH": {
        "high_error_rate": [
            r"error", r"failed", r"failure", r"fatal",
            r"invalid", r"illegal", r"refused",
        ],
        "unauthorized_access": [
            r"failed password", r"failed publickey",
            r"invalid user", r"illegal user",
            r"authentication failure", r"auth.*fail",
            r"too many authentication",
            r"possible break-in", r"break.in attempt",
            r"did not receive identification",
            r"bad protocol", r"protocol error",
            r"no supported authentication",
        ],
        "unusual_operations": [
            r"reverse mapping.*failed",
            r"address.*not.*associated",
            r"rsa key.*warning",
            r"opened.*for.*root",
            r"preauth",
            r"disconnecting.*preauth",
            r"bad packet", r"corrupt.*mac",
        ],
        "repeated_abuse": [
            r"from \d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}",
            r"failed password.*from",
            r"invalid user.*from",
            r"repeated.*auth.*fail",
        ],
        "performance_issues": [
            r"timeout", r"timed out",
            r"connection.*closed", r"connection.*reset",
            r"did not receive", r"slow.*connect",
        ],
    },

    "Hadoop": {
        "high_error_rate": [
            r"error", r"exception", r"failed", r"failure",
            r"fatal", r"warn",
            r"task.*failed", r"job.*failed",
            r"attempt.*failed", r"reduce.*failed", r"map.*failed",
            r"lost.*connection", r"node.*lost",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"unauthorized", r"authentication.*fail",
            r"security.*exception", r"not.*authorized",
        ],
        "unusual_operations": [
            r"killed", r"blacklisted", r"node.*blacklisted",
            r"lost.*tracker", r"tracker.*lost",
            r"outofmemory", r"out of memory",
            r"heartbeat.*miss", r"miss.*heartbeat",
            r"speculative.*task", r"job.*abort",
        ],
        "repeated_abuse": [
            r"attempt_\w+",
            r"task.*retry", r"job.*retry",
            r"failed.*attempt", r"re-run",
            r"multiple.*fail",
        ],
        "performance_issues": [
            r"timeout", r"timed out", r"slow",
            r"waiting", r"stalled",
            r"gc.*overhead", r"garbage.*collection",
            r"disk.*full", r"no.*space",
        ],
    },

    "HDFS": {
        "high_error_rate": [
            r"error", r"exception", r"failed", r"failure",
            r"warn", r"ioexception",
            r"corrupt", r"corrupted",
            r"block.*lost", r"lost.*block",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"unauthorized", r"security.*exception",
            r"not.*permitted",
        ],
        "unusual_operations": [
            r"corrupt", r"corrupted",
            r"replicat.*fail", r"under.replicated",
            r"missing.*block", r"block.*missing",
            r"checksum.*error", r"crc.*error",
            r"disk.*fail", r"disk.*full",
            r"no.*space", r"quota.*exceed",
            r"datanode.*lost", r"dead.*datanode",
        ],
        "repeated_abuse": [
            r"blk_-?\d+",
            r"datanode.*fail", r"failed.*connect",
            r"connect.*fail", r"retry.*connect",
        ],
        "performance_issues": [
            r"timeout", r"timed out", r"slow",
            r"waiting.*replication", r"decommission",
            r"balancer", r"rebalance",
        ],
    },

    "Spark": {
        "high_error_rate": [
            r"error", r"exception", r"failed", r"failure",
            r"fatal", r"warn",
            r"executorlost", r"executor.*lost",
            r"stage.*failed", r"task.*failed",
            r"job.*failed", r"job.*aborted",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"unauthorized", r"authentication.*fail",
        ],
        "unusual_operations": [
            r"outofmemory", r"out of memory",
            r"gc.*overhead", r"heap.*space",
            r"executorlost", r"executor.*lost",
            r"driver.*stopped", r"driver.*exit",
            r"fetchfailed", r"shuffle.*fail",
            r"broadcast.*timeout", r"straggler",
        ],
        "repeated_abuse": [
            r"attempt.*\d+", r"retry.*\d+",
            r"task.*retry", r"resubmit",
            r"executor.*\d+.*lost",
        ],
        "performance_issues": [
            r"timeout", r"timed out", r"slow",
            r"gc.*pause", r"speculative.*task",
            r"waiting.*resource", r"backpressure",
        ],
    },

    "Zookeeper": {
        "high_error_rate": [
            r"error", r"exception", r"failed", r"failure",
            r"warn", r"fatal",
            r"connectionloss", r"session.*expired",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"auth.*fail", r"authentication.*fail",
            r"invalid.*acl", r"not.*authorized",
        ],
        "unusual_operations": [
            r"leader.*election", r"new.*leader",
            r"quorum.*lost", r"not.*enough.*participants",
            r"unable.*read", r"read.*fail",
            r"snap.*corrupt", r"log.*corrupt",
            r"too.*many.*connections",
        ],
        "repeated_abuse": [
            r"session.*timeout", r"connectionloss",
            r"client.*disconnect", r"too.*many.*connect",
            r"session.*expired.*repeated",
        ],
        "performance_issues": [
            r"timeout", r"timed out",
            r"session.*timeout", r"connection.*timeout",
            r"high.*latency", r"slow.*request",
            r"fsync.*threshold", r"sync.*slow",
        ],
    },

    "BGL": {
        "high_error_rate": [
            r"error", r"fatal", r"failure", r"failed",
            r"severe", r"critical",
            r"hardware.*error", r"machine.*check",
            r"rts.*error", r"ciod.*error",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"authentication.*fail", r"unauthorized",
        ],
        "unusual_operations": [
            r"machine check", r"mce",
            r"hardware.*error", r"hardware.*failure",
            r"memory.*error", r"ecc.*error",
            r"cpu.*error", r"processor.*error",
            r"kernel.*panic", r"panic",
            r"node.*fail", r"node.*down", r"fatal",
        ],
        "repeated_abuse": [
            r"R\d{2}-M\d-N\d+",
            r"node.*repeated.*error",
            r"same.*node.*fail",
            r"multiple.*hardware.*error",
        ],
        "performance_issues": [
            r"timeout", r"timed out", r"slow",
            r"network.*error", r"link.*error",
            r"latency", r"congestion", r"throttl",
        ],
    },

    "HPC": {
        "high_error_rate": [
            r"error", r"failed", r"failure", r"fatal",
            r"warn", r"exception",
            r"job.*fail", r"node.*fail",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"authentication.*fail", r"unauthorized",
            r"account.*locked", r"not.*authorized",
        ],
        "unusual_operations": [
            r"node.*down", r"node.*fail",
            r"memory.*error", r"cpu.*error",
            r"mpi.*error", r"mpi.*abort",
            r"scheduler.*error", r"queue.*error",
            r"job.*cancel", r"job.*kill",
        ],
        "repeated_abuse": [
            r"job.*retry", r"requeue",
            r"node.*repeated.*fail",
            r"same.*node.*error",
        ],
        "performance_issues": [
            r"timeout", r"slow", r"stall",
            r"waiting.*resource", r"queue.*full",
            r"load.*high", r"overload",
        ],
    },

    "Thunderbird": {
        "high_error_rate": [
            r"error", r"fatal", r"failure", r"failed",
            r"severe", r"critical", r"panic",
            r"hardware.*error", r"node.*fail",
        ],
        "unauthorized_access": [
            r"permission denied", r"unauthorized",
            r"authentication.*fail",
        ],
        "unusual_operations": [
            r"fatal", r"panic",
            r"hardware.*error", r"hardware.*failure",
            r"node.*fail", r"node.*down",
            r"kernel.*error", r"kernel.*panic",
            r"network.*partition", r"partition.*event",
            r"rpc.*error", r"rpc.*fail",
        ],
        "repeated_abuse": [
            r"node.*\w+.*repeated",
            r"same.*node.*fail",
            r"multiple.*error.*same",
        ],
        "performance_issues": [
            r"timeout", r"slow", r"latency",
            r"network.*slow", r"congestion",
        ],
    },

    "Windows": {
        "high_error_rate": [
            r"error", r"failed", r"failure", r"fatal",
            r"critical", r"warning",
            r"eventid.*1000", r"eventid.*1001",
            r"eventid.*7034", r"eventid.*7031",
            r"blue.screen", r"bsod",
        ],
        "unauthorized_access": [
            r"eventid.*4625", r"failed.*logon", r"logon.*fail",
            r"eventid.*4648",
            r"account.*lock", r"locked.*out",
            r"unauthorized", r"access.*denied",
            r"permission.*denied",
        ],
        "unusual_operations": [
            r"eventid.*4698", r"scheduled.*task.*created",
            r"eventid.*4719", r"audit.*policy.*changed",
            r"eventid.*4720", r"user.*account.*created",
            r"eventid.*4732", r"member.*added.*group",
            r"registry.*change", r"registry.*corrupt",
            r"service.*stop.*unexpected", r"service.*crash",
        ],
        "repeated_abuse": [
            r"eventid.*4625",
            r"multiple.*fail.*logon",
            r"account.*lock",
            r"brute.*force",
        ],
        "performance_issues": [
            r"timeout", r"slow", r"high.*cpu",
            r"memory.*leak", r"disk.*full",
            r"eventid.*2019", r"eventid.*2020",
        ],
    },

    "Linux": {
        "high_error_rate": [
            r"error", r"failed", r"failure", r"fatal",
            r"warn", r"critical",
            r"kernel.*error", r"driver.*error",
            r"oops", r"bug:",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"authentication.*fail", r"auth.*fail",
            r"su.*fail", r"sudo.*fail",
            r"pam.*error", r"pam.*fail",
            r"sshd.*fail", r"login.*fail",
        ],
        "unusual_operations": [
            r"oom.killer", r"out.of.memory.*kill",
            r"segfault", r"segmentation fault",
            r"kernel.*panic", r"panic",
            r"call.*trace", r"oops",
            r"soft.*lockup", r"hard.*lockup",
            r"hung.*task", r"rcu.*stall",
            r"i/o.*error", r"disk.*error",
            r"filesystem.*error", r"ext.*error",
        ],
        "repeated_abuse": [
            r"repeated.*fail", r"multiple.*error",
            r"oom.*killed.*process",
            r"same.*process.*fail",
        ],
        "performance_issues": [
            r"timeout", r"slow", r"high.*load",
            r"swap.*full", r"memory.*pressure",
            r"disk.*full", r"no.*space",
            r"cpu.*throttl", r"thermal",
        ],
    },

    "Android": {
        "high_error_rate": [
            r"error", r"exception", r"fatal",
            r"crash", r"e/", r"wtf/",
            r"anr", r"not.*responding",
            r"force.*close", r"stopped.*unexpectedly",
        ],
        "unauthorized_access": [
            r"permission.*denied", r"securityexception",
            r"access.*denied", r"not.*allowed",
            r"permission.*not.*granted",
            r"uid.*not.*allowed",
        ],
        "unusual_operations": [
            r"anr",
            r"fatal.*exception",
            r"outofmemoryerror",
            r"nullpointerexception",
            r"stackoverflowerror",
            r"watchdog.*expired",
            r"deadlock", r"native.*crash",
        ],
        "repeated_abuse": [
            r"fatal.*exception.*main",
            r"anr.*in.*\w+\.\w+",
            r"force.*close.*\w+",
            r"crash.*repeated",
            r"low.*memory.*repeated",
        ],
        "performance_issues": [
            r"anr",
            r"slow.*main.*thread",
            r"gc.*pause", r"gc.*overhead",
            r"low.*memory", r"memory.*pressure",
            r"frame.*drop", r"jank",
            r"battery.*drain",
        ],
    },

    "HealthApp": {
        "high_error_rate": [
            r"error", r"failed", r"failure", r"fatal",
            r"warn", r"exception",
            r"sensor.*fail", r"device.*fail",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"unauthorized", r"authentication.*fail",
            r"not.*authorized",
        ],
        "unusual_operations": [
            r"threshold.*exceed", r"exceed.*threshold",
            r"critical.*alert", r"alert.*critical",
            r"sensor.*fail", r"sensor.*error",
            r"data.*missing", r"missing.*data",
            r"battery.*low", r"low.*battery",
            r"device.*disconnect",
        ],
        "repeated_abuse": [
            r"repeated.*error", r"sensor.*repeated.*fail",
            r"multiple.*alert", r"alert.*storm",
        ],
        "performance_issues": [
            r"timeout", r"slow", r"latency",
            r"battery.*low", r"memory.*full",
            r"data.*delay", r"sync.*fail",
        ],
    },

    "Mac": {
        "high_error_rate": [
            r"error", r"failed", r"failure", r"fatal",
            r"warn", r"critical",
            r"kernel.*error", r"crash",
        ],
        "unauthorized_access": [
            r"permission denied", r"access denied",
            r"authentication.*fail", r"auth.*fail",
            r"sudo.*fail", r"su.*fail",
            r"pam.*error", r"keychain.*fail",
        ],
        "unusual_operations": [
            r"kernel.*panic", r"panic",
            r"segfault", r"segmentation fault",
            r"crash.*reporter", r"crash.*log",
            r"sandbox.*violation", r"sandbox.*deny",
            r"gatekeeper.*block",
            r"disk.*full", r"no.*space",
        ],
        "repeated_abuse": [
            r"repeated.*error", r"crash.*loop",
            r"respawn.*too.*fast",
        ],
        "performance_issues": [
            r"timeout", r"slow", r"high.*cpu",
            r"memory.*pressure", r"swap.*full",
            r"thermal.*throttl", r"disk.*full",
        ],
    },

    "Proxifier": {
        "high_error_rate": [
            r"error", r"failed", r"failure",
            r"connect.*error", r"connection.*error",
            r"proxy.*error",
        ],
        "unauthorized_access": [
            r"access denied", r"denied",
            r"blocked", r"rule.*blocked",
            r"forbidden", r"unauthorized",
            r"auth.*fail", r"authentication.*fail",
        ],
        "unusual_operations": [
            r"blocked", r"rule.*blocked",
            r"certificate.*error", r"ssl.*error",
            r"invalid.*certificate", r"cert.*fail",
            r"proxy.*chain.*fail", r"socks.*error",
        ],
        "repeated_abuse": [
            r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}",
            r"repeated.*block", r"multiple.*deny",
        ],
        "performance_issues": [
            r"timeout", r"timed out", r"slow",
            r"connection.*timeout", r"proxy.*timeout",
            r"latency", r"bandwidth",
        ],
    },

    "OpenStack": {
        "high_error_rate": [
            r"error", r"exception", r"failed", r"failure",
            r"fatal", r"traceback", r"warn",
            r"http [45]\d\d",
        ],
        "unauthorized_access": [
            r"unauthorized", r" 401 ", r" 403 ",
            r"access.*denied", r"permission.*denied",
            r"authentication.*fail", r"auth.*fail",
            r"token.*invalid", r"token.*expired",
        ],
        "unusual_operations": [
            r"instance.*fail", r"vm.*fail",
            r"quota.*exceed", r"resource.*exhaust",
            r"network.*fail", r"neutron.*error",
            r"compute.*fail", r"nova.*error",
            r"storage.*fail", r"cinder.*error",
            r"image.*fail", r"glance.*error",
        ],
        "repeated_abuse": [
            r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}",
            r"repeated.*fail", r"request.*flood",
            r"rate.*limit",
        ],
        "performance_issues": [
            r"timeout", r"timed out", r"slow",
            r"high.*latency", r"response.*slow",
            r"queue.*full", r"overload",
        ],
    },
}
