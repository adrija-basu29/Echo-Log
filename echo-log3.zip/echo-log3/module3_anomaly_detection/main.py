# main.py
# Module 3 — Anomaly Detection Server
# Port: 8002

import os
import uvicorn
from fastapi import FastAPI
from loguru import logger
from routes import router

app = FastAPI(
    title="Echo-Log — Anomaly Detection API",
    description="""
    ## Module 3: ML-Powered Anomaly Detection

    ### Models Used (Ensemble):
    - **Isolation Forest** (40% weight) — Global outlier detection
    - **Local Outlier Factor** (35% weight) — Local density anomalies
    - **Statistical Z-Score** (25% weight) — Threshold-based detection

    ### Supported Log Types (Training):
    HDFS, Hadoop, Spark, Zookeeper, BGL, HPC, Thunderbird,
    Windows, Linux, Android, HealthApp, Apache, OpenSSH,
    OpenStack, Mac, Proxifier

    ### Severity Levels:
    - 🔴 **CRITICAL** (85-100) — Immediate action needed
    - 🟠 **HIGH** (70-85) — Serious issue
    - 🟡 **MEDIUM** (50-70) — Needs attention
    - 🟢 **LOW** (30-50) — Slightly suspicious
    - ⚪ **NORMAL** (0-30) — All good
    """,
    version="1.0.0"
)

# Logging setup
os.makedirs("logs", exist_ok=True)
logger.add(
    "logs/anomaly_detection.log",
    rotation="10 MB",
    retention="7 days",
    level="INFO",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}"
)

# Register routes
app.include_router(router, prefix="/api/v3")


@app.get("/")
async def root():
    return {
        "project":  "Echo-Log",
        "module":   "Module 3 — Anomaly Detection",
        "port":     8002,
        "status":   "running",
        "models":   ["Isolation Forest", "Local Outlier Factor", "Statistical Z-Score"],
        "routes": {
            "POST /api/v3/analyze":               "Run anomaly detection",
            "POST /api/v3/analyze-and-evaluate":  "Detect + generate graphs",
            "POST /api/v3/critical-only":          "Get only CRITICAL/HIGH results",
            "POST /api/v3/retrain":                "Force retrain model",
            "POST /api/v3/train-loghub":           "Train on loghub datasets (all 16 types)",
            "GET  /api/v3/training-status":        "Check training status",
            "POST /api/v3/feedback":               "Submit anomaly feedback",
            "POST /api/v3/retrain-with-feedback":  "Retrain using feedback data",
            "GET  /api/v3/feedback-stats":         "View feedback statistics",
            "GET  /api/v3/health":                 "Health check"
        },
        "docs": "Visit /docs for interactive API documentation"
    }


if __name__ == "__main__":
    os.makedirs("logs",               exist_ok=True)
    os.makedirs("saved_models",       exist_ok=True)
    os.makedirs("training_data",      exist_ok=True)
    os.makedirs("performance_graphs", exist_ok=True)

    logger.info("🚀 Starting Echo-Log Anomaly Detection Server on port 8002...")
    uvicorn.run("main:app", host="0.0.0.0", port=8002, reload=False)
