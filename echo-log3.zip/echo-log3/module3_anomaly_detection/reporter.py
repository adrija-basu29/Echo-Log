# reporter.py
# All 5 anomaly types always captured for ALL 16 log types
# Each type analysed with its own specific pattern bank

import re
from collections import Counter, defaultdict
from loguru import logger
from log_schemas import LOG_TYPE_ALL_ANOMALIES

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def full_text(r: dict) -> str:
    parts = []
    for f in ["raw_text", "message", "event_template", "service"]:
        v = (r.get(f) or "").strip()
        if v:
            parts.append(v)
    reasons = " ".join(r.get("anomaly_reasons", []))
    return (" ".join(parts) + " " + reasons).lower()


def match(text: str, patterns: list) -> bool:
    for p in patterns:
        try:
            if re.search(p, text):
                return True
        except re.error:
            if p in text:
                return True
    return False


def match_all(text: str, patterns: list) -> list:
    """Return all matched patterns."""
    matched = []
    for p in patterns:
        try:
            if re.search(p, text):
                matched.append(p)
        except re.error:
            if p in text:
                matched.append(p)
    return matched


def get_defs(log_type: str) -> dict:
    return LOG_TYPE_ALL_ANOMALIES.get(log_type) or LOG_TYPE_ALL_ANOMALIES.get("Apache", {})


# ─────────────────────────────────────────────────────────────────────────────
# 5 Anomaly Type Analyzers
# Each returns: detected, count, by_log_type, examples, description
# ─────────────────────────────────────────────────────────────────────────────

def analyze_high_error_rate(results: list) -> dict:
    """
    Detects high error rate for all 16 log types.
    Each log type has its own set of error patterns.
    """
    hits, by_type = [], defaultdict(int)

    for r in results:
        lt   = r.get("log_type", "Unknown")
        defs = get_defs(lt)
        pats = defs.get("high_error_rate", [])
        text = full_text(r)

        # Match against log-type patterns OR check is_error flag
        if match(text, pats) or r.get("is_error") or r.get("severity") in ("CRITICAL", "HIGH"):
            hits.append(r)
            by_type[lt] += 1

    total    = len(results)
    count    = len(hits)
    rate     = round(count / total * 100, 1) if total else 0
    detected = count >= 3 or rate >= 5.0
    examples = [h.get("raw_text", "")[:120] for h in
                sorted(hits, key=lambda x: x.get("anomaly_score", 0), reverse=True)[:3]]

    return {
        "detected":    detected,
        "count":       count,
        "percentage":  rate,
        "by_log_type": dict(by_type),
        "examples":    examples,
        "label":       "High Error Rate",
        "description": f"{count} error entries ({rate}% of total) across {len(by_type)} log type(s)",
    }


def analyze_unauthorized_access(results: list) -> dict:
    """
    Detects unauthorized access for all 16 log types.
    SSH failed password, HTTP 403, Windows 4625, Android permission denied, etc.
    """
    hits, by_type = [], defaultdict(int)

    for r in results:
        lt   = r.get("log_type", "Unknown")
        defs = get_defs(lt)
        pats = defs.get("unauthorized_access", [])
        text = full_text(r)

        if match(text, pats):
            hits.append(r)
            by_type[lt] += 1

    count    = len(hits)
    detected = count >= 1
    examples = [h.get("raw_text", "")[:120] for h in
                sorted(hits, key=lambda x: x.get("anomaly_score", 0), reverse=True)[:3]]

    return {
        "detected":    detected,
        "count":       count,
        "by_log_type": dict(by_type),
        "examples":    examples,
        "label":       "Unauthorized Access",
        "description": f"{count} unauthorized access attempt(s) detected",
    }


def analyze_unusual_operations(results: list) -> dict:
    """
    Detects unusual/dangerous operations for all 16 log types.
    HTTP DELETE on admin, kernel panic, OOM kill, ANR, MCE, Windows EventID 4698, etc.
    """
    hits, by_type = [], defaultdict(int)

    for r in results:
        lt   = r.get("log_type", "Unknown")
        defs = get_defs(lt)
        pats = defs.get("unusual_operations", [])
        text = full_text(r)

        if match(text, pats):
            hits.append(r)
            by_type[lt] += 1

    count    = len(hits)
    detected = count >= 1
    examples = [h.get("raw_text", "")[:120] for h in
                sorted(hits, key=lambda x: x.get("anomaly_score", 0), reverse=True)[:3]]

    return {
        "detected":    detected,
        "count":       count,
        "by_log_type": dict(by_type),
        "examples":    examples,
        "label":       "Unusual Operations",
        "description": f"{count} unusual/dangerous operation(s) detected",
    }


def analyze_repeated_abuse(results: list) -> dict:
    """
    Detects repeated abuse for ALL 16 log types.
    Strategy differs by log type:
      IP-based logs  → IP frequency (Apache, OpenSSH, Proxifier, OpenStack)
      Android        → Same app crashing repeatedly
      Hadoop/Spark   → Same job/task failing repeatedly
      Windows        → Repeated EventID 4625 (failed logon)
      Zookeeper      → Repeated session timeouts
      BGL/HPC        → Same node failing repeatedly
      Others         → Pattern-based + component frequency
    """
    hits, by_type, details = [], defaultdict(int), []

    # ── Method A: Log-type specific patterns ──────────
    for r in results:
        lt   = r.get("log_type", "Unknown")
        defs = get_defs(lt)
        pats = defs.get("repeated_abuse", [])
        text = full_text(r)
        if match(text, pats):
            hits.append(r)
            by_type[lt] += 1

    # ── Method B: IP frequency (for IP-bearing log types) ──
    ip_counts     = Counter()
    ip_to_entries = defaultdict(list)
    for r in results:
        raw = (r.get("raw_text") or "").strip()
        ip  = None
        for pat in [r'^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})',
                    r'from\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})',
                    r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})']:
            m = re.search(pat, raw)
            if m:
                ip = m.group(1)
                break
        if ip:
            ip_counts[ip] += 1
            ip_to_entries[ip].append(r)

    threshold = max(3, len(results) * 0.04)
    for ip, cnt in ip_counts.items():
        if cnt > threshold:
            details.append(f"IP {ip} appeared {cnt} times")
            for r in ip_to_entries[ip]:
                if r not in hits:
                    hits.append(r)
                    by_type[r.get("log_type", "Unknown")] += 1

    # ── Method C: Android — same app crashing ─────────
    app_crashes = defaultdict(list)
    for r in results:
        if r.get("log_type") == "Android":
            text = full_text(r)
            if re.search(r"anr|fatal.*exception|force.*close|crash", text):
                m = re.search(r'([a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]+)+)', text)
                pkg = m.group(1) if m else "unknown_app"
                app_crashes[pkg].append(r)
    for pkg, entries in app_crashes.items():
        if len(entries) >= 2:
            details.append(f"Android app '{pkg}' crashed {len(entries)} times")
            for r in entries:
                if r not in hits:
                    hits.append(r)
                    by_type["Android"] += 1

    # ── Method D: Hadoop/Spark — same job failing ─────
    job_fails = defaultdict(list)
    for r in results:
        if r.get("log_type") in ("Hadoop", "Spark", "HDFS"):
            text = full_text(r)
            m = re.search(r'(job_\d+_\d+|task_\d+_\d+_\w+|stage_\d+)', text)
            if m and re.search(r"fail|error|exception", text):
                job_fails[m.group(1)].append(r)
    for jid, entries in job_fails.items():
        if len(entries) >= 2:
            details.append(f"Job/Task '{jid}' failed {len(entries)} times")
            for r in entries:
                if r not in hits:
                    hits.append(r)
                    by_type[r.get("log_type", "Unknown")] += 1

    # ── Method E: Windows — repeated EventID 4625 ─────
    win_fails = [r for r in results
                 if r.get("log_type") == "Windows"
                 and re.search(r"4625|fail.*logon|logon.*fail", full_text(r))]
    if len(win_fails) >= 3:
        details.append(f"Windows repeated failed logons: {len(win_fails)} events")
        by_type["Windows"] += len(win_fails)
        for r in win_fails:
            if r not in hits:
                hits.append(r)

    # ── Method F: Zookeeper — repeated session timeouts ──
    zk_timeouts = [r for r in results
                   if r.get("log_type") == "Zookeeper"
                   and re.search(r"timeout|session.*expire|connectionloss", full_text(r))]
    if len(zk_timeouts) >= 3:
        details.append(f"Zookeeper repeated timeouts: {len(zk_timeouts)} events")
        by_type["Zookeeper"] += len(zk_timeouts)
        for r in zk_timeouts:
            if r not in hits:
                hits.append(r)

    # ── Method G: Component frequency for other types ──
    comp_fails = Counter()
    for r in results:
        if not r.get("is_anomaly"):
            continue
        svc  = (r.get("service") or "")
        comp = re.split(r'[\[\(]', svc)[0].strip()
        if comp and len(comp) > 2 and comp not in ("unknown", "none"):
            comp_fails[comp] += 1
    for comp, cnt in comp_fails.items():
        if cnt >= 4:
            details.append(f"Component '{comp}' had {cnt} anomalies")

    count    = len(hits)
    detected = count >= 1 or len(details) >= 1
    examples = [h.get("raw_text", "")[:120] for h in
                sorted(hits, key=lambda x: x.get("anomaly_score", 0), reverse=True)[:3]]

    return {
        "detected":    detected,
        "count":       count,
        "by_log_type": dict(by_type),
        "details":     details[:5],
        "examples":    examples,
        "label":       "Repeated Abuse",
        "description": (f"{count} repeated abuse entries. " +
                        (" | ".join(details[:2]) if details else "Pattern-based detection")),
    }


def analyze_performance_issues(results: list) -> dict:
    """
    Detects performance issues for all 16 log types.
    HTTP slow response, Android ANR, Zookeeper timeout, GC pauses, etc.
    """
    hits, by_type = [], defaultdict(int)

    for r in results:
        lt   = r.get("log_type", "Unknown")
        defs = get_defs(lt)
        pats = defs.get("performance_issues", [])
        text = full_text(r)

        matched = match(text, pats)

        # Also check numeric response time
        raw     = (r.get("raw_text") or "")
        numbers = re.findall(r'\b(\d+)\b', raw)
        high_rt = numbers and int(numbers[-1]) > 3000 and r.get("is_anomaly")

        if matched or high_rt:
            hits.append(r)
            by_type[lt] += 1

    count    = len(hits)
    detected = count >= 1
    examples = [h.get("raw_text", "")[:120] for h in
                sorted(hits, key=lambda x: x.get("anomaly_score", 0), reverse=True)[:3]]

    return {
        "detected":    detected,
        "count":       count,
        "by_log_type": dict(by_type),
        "examples":    examples,
        "label":       "Performance Issues",
        "description": f"{count} performance issue entries detected",
    }


# ─────────────────────────────────────────────────────────────────────────────
# Suspicious Entity Extractor
# Works for all log types — IPs, apps, jobs, components
# ─────────────────────────────────────────────────────────────────────────────

def extract_suspicious_entities(results: list) -> list:
    data = {}

    for r in results:
        raw  = (r.get("raw_text") or "").strip()
        lt   = r.get("log_type", "Unknown")
        svc  = (r.get("service") or "")
        entity, etype = None, "ip"

        # IP (Apache, OpenSSH, Proxifier, OpenStack)
        for pat in [r'^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})',
                    r'from\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})',
                    r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})']:
            m = re.search(pat, raw)
            if m:
                entity, etype = m.group(1), "ip"
                break

        # Android — app package
        if not entity and lt == "Android":
            m = re.search(r'([a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]+)+)', raw.lower())
            if m:
                entity, etype = m.group(1), "app"
            else:
                m = re.search(r'[EIDWV]/([^(:\s]+)', raw)
                if m:
                    entity, etype = m.group(1), "app"

        # Hadoop/Spark/HDFS — job/task ID
        if not entity and lt in ("Hadoop", "Spark", "HDFS"):
            m = re.search(r'(job_\d+_\d+|task_\d+_\d+_\w+)', raw)
            if m:
                entity, etype = m.group(1), "job"

        # Windows — EventID
        if not entity and lt == "Windows":
            m = re.search(r'EventID[:\s]+(\d+)', raw, re.IGNORECASE)
            if m:
                entity, etype = f"EventID_{m.group(1)}", "event"

        # BGL/HPC/Thunderbird — node ID
        if not entity and lt in ("BGL", "HPC", "Thunderbird"):
            m = re.search(r'(R\d{2}-M\d-N\d+|\bnode\d+\b)', raw, re.IGNORECASE)
            if m:
                entity, etype = m.group(1), "node"

        # Component / service name fallback
        if not entity and svc:
            comp = re.split(r'[\[\(]', svc)[0].strip()
            if comp and len(comp) > 2:
                entity, etype = comp, "component"

        if not entity:
            entity, etype = lt, "system"

        if entity not in data:
            data[entity] = {
                "ip":            entity,   # kept for backward compat
                "entity":        entity,
                "type":          etype,
                "max_score":     0.0,
                "request_count": 0,
                "total_count":   0,
                "anomaly_count": 0,
            }
        d = data[entity]
        d["total_count"]   += 1
        d["request_count"] += 1
        d["max_score"]      = max(d["max_score"], float(r.get("anomaly_score", 0)))
        if r.get("is_anomaly"):
            d["anomaly_count"] += 1

    return sorted(data.values(),
                  key=lambda x: (x["anomaly_count"], x["max_score"]),
                  reverse=True)[:10]


# ─────────────────────────────────────────────────────────────────────────────
# Master Report Builder
# ─────────────────────────────────────────────────────────────────────────────

def build_full_report(results: list, model_trained_fresh: bool, total_features: int) -> dict:
    total     = len(results)
    anomalies = [r for r in results if r["is_anomaly"]]
    normal    = [r for r in results if not r["is_anomaly"]]
    critical  = [r for r in results if r["severity"] == "CRITICAL"]
    high      = [r for r in results if r["severity"] == "HIGH"]
    medium    = [r for r in results if r["severity"] == "MEDIUM"]
    low       = [r for r in results if r["severity"] == "LOW"]
    anomaly_pct = round(len(anomalies) / total * 100, 2) if total else 0

    logger.info("Analyzing all 5 anomaly types...")
    err_a   = analyze_high_error_rate(results)
    unauth_a = analyze_unauthorized_access(results)
    unusual_a = analyze_unusual_operations(results)
    abuse_a  = analyze_repeated_abuse(results)
    perf_a   = analyze_performance_issues(results)

    entities = extract_suspicious_entities(results)

    logger.info(
        f"Report | Total={total} | Anomalies={len(anomalies)} ({anomaly_pct}%) | "
        f"CRIT={len(critical)} | HIGH={len(high)} | MED={len(medium)} | LOW={len(low)}"
    )
    logger.info(
        f"Anomaly types | ErrorRate={err_a['count']} | "
        f"Unauth={unauth_a['count']} | Unusual={unusual_a['count']} | "
        f"Abuse={abuse_a['count']} | Perf={perf_a['count']}"
    )

    return {
        # Counts
        "total_entries":      total,
        "anomaly_count":      len(anomalies),
        "normal_count":       len(normal),
        "anomaly_percentage": anomaly_pct,
        "critical_count":     len(critical),
        "high_count":         len(high),
        "medium_count":       len(medium),
        "low_count":          len(low),

        # Boolean flags — backward compat
        "high_error_rate_detected":     err_a["detected"],
        "unauthorized_access_detected": unauth_a["detected"],
        "unusual_methods_detected":     unusual_a["detected"],
        "ip_abuse_detected":            abuse_a["detected"],
        "response_time_spike_detected": perf_a["detected"],

        # Detailed per-type analysis (NEW)
        "anomaly_type_analysis": {
            "high_error_rate":     err_a,
            "unauthorized_access": unauth_a,
            "unusual_operations":  unusual_a,
            "repeated_abuse":      abuse_a,
            "performance_issues":  perf_a,
        },

        # Suspicious entities (IPs / apps / jobs / nodes)
        "top_suspicious_ips": entities,

        # All per-entry results
        "results":             results,
        "model_trained_fresh": model_trained_fresh,
        "total_features_used": total_features,
    }
