# anomaly_detector.py — Main detection pipeline

import os
import json
import re
from loguru import logger
from feature_engineer import engineer_features
from models import (train_isolation_forest, load_isolation_forest,
                    predict_isolation_forest, predict_lof,
                    predict_statistical, train_scaler, load_scaler)
from scorer import build_anomaly_results
from reporter import build_full_report

FEEDBACK_FILE = "saved_models/feedback_data.json"

LOG_TYPE_SIGNALS = {
    "HDFS":        ["namenode", "datanode", "hdfs", "blk_", " dfs."],
    "Hadoop":      ["hadoop", "mapreduce", "tasktracker", "jobtracker", "job_20"],
    "Spark":       ["spark", "dagscheduler", "taskscheduler", "sparkcontext", "executor"],
    "Zookeeper":   ["zookeeper", "zxid", "quorum", "sessionexpired", "zkclient"],
    "OpenSSH":     ["sshd", "failed password", "invalid user", "publickey", "ssh2"],
    "OpenStack":   ["nova", "neutron", "glance", "cinder", "keystone", "openstack"],
    "Android":     ["android", "dalvik", "anr", "activitymanager", "androidruntime"],
    "BGL":         ["bluegene", "ciod", "rts kernel", "bgl"],
    "Thunderbird": ["thunderbird", "tbird"],
    "HPC":         ["mpi", "pbs", "torque", "slurm"],
    "HealthApp":   ["healthapp", "heartrate", "bloodpressure", "stepcount"],
    "Proxifier":   ["proxifier", "socks5", "socks4"],
    "Windows":     ["eventid", "winlogon", "ntfs", "registry", "windows"],
    "Mac":         ["darwin", "launchd", "mach-o", "coreaudio"],
    "Linux":       ["kernel", "segfault", "oom killer", "systemd", "dmesg"],
    "Apache":      ["apache", "httpd", "mod_", "worker"],
}


def detect_log_type(entry: dict) -> str:
    content = " ".join([
        (entry.get("raw_text")  or ""),
        (entry.get("service")   or ""),
        (entry.get("message")   or ""),
    ]).lower()

    for lt, signals in LOG_TYPE_SIGNALS.items():
        if any(s in content for s in signals):
            return lt

    # Apache access log — starts with IP + HTTP method
    raw = (entry.get("raw_text") or "").strip()
    if re.match(r'\d+\.\d+\.\d+\.\d+', raw):
        if any(m in content for m in ["get /", "post /", "put /", "delete /"]):
            return "Apache"

    return "Unknown"


def ensure_entry(entry: dict) -> dict:
    """Guarantee raw_text, message, event_template all exist."""
    if not entry.get("raw_text"):
        parts = [str(entry.get(f) or "") for f in ["timestamp", "level", "service", "message"]]
        entry["raw_text"] = " ".join(p for p in parts if p)
    if not entry.get("message"):
        entry["message"] = entry.get("raw_text", "")
    if not entry.get("event_template"):
        entry["event_template"] = ""
    return entry


def save_feedback(entry: dict, confirmed: bool):
    fb = {"anomalies": [], "normals": []}
    if os.path.exists(FEEDBACK_FILE):
        with open(FEEDBACK_FILE) as f:
            fb = json.load(f)
    entry["confirmed_label"] = confirmed
    fb["anomalies" if confirmed else "normals"].append(entry)
    with open(FEEDBACK_FILE, "w") as f:
        json.dump(fb, f, indent=2)


def load_feedback() -> dict:
    if os.path.exists(FEEDBACK_FILE):
        with open(FEEDBACK_FILE) as f:
            return json.load(f)
    return {"anomalies": [], "normals": []}


def run_detection_pipeline(entries: list[dict], force_retrain: bool = False) -> dict:
    logger.info(f"Pipeline starting — {len(entries)} entries")

    # Step 0 — prepare
    type_counts = {}
    for e in entries:
        ensure_entry(e)
        if not e.get("log_type"):
            e["log_type"] = detect_log_type(e)
        type_counts[e["log_type"]] = type_counts.get(e["log_type"], 0) + 1
    logger.info(f"Log types: {type_counts}")

    # Step 1 — features
    feat_df      = engineer_features(entries)
    X            = feat_df.values
    feature_rows = feat_df.to_dict(orient="records")

    # Step 2 — scale
    scaler  = load_scaler()
    trained = False
    if scaler is None or force_retrain:
        scaler  = train_scaler(X)
        trained = True
    X_sc = scaler.transform(X)

    # Step 3 — Isolation Forest
    if_model = load_isolation_forest()
    if if_model is None or force_retrain:
        if_model = train_isolation_forest(X_sc)
        trained  = True
    if_scores = predict_isolation_forest(if_model, X_sc)

    # Step 4 — LOF
    lof_scores = predict_lof(X_sc)

    # Step 5 — Statistical
    stat_scores = predict_statistical(X_sc)

    # Step 6 — Score
    results = build_anomaly_results(entries, if_scores, lof_scores, stat_scores, feature_rows)

    # Step 7 — Report
    report = build_full_report(results, trained, len(feat_df.columns))

    logger.info("Pipeline complete ✅")
    return report
