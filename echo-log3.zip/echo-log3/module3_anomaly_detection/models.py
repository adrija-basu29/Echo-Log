# models.py — ML ensemble: Isolation Forest + LOF + Statistical

import numpy as np
import joblib
import os
from loguru import logger
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.preprocessing import StandardScaler

MODEL_DIR   = "saved_models"
IF_PATH     = os.path.join(MODEL_DIR, "isolation_forest.pkl")
SCALER_PATH = os.path.join(MODEL_DIR, "scaler.pkl")
os.makedirs(MODEL_DIR, exist_ok=True)


def train_isolation_forest(X: np.ndarray) -> IsolationForest:
    logger.info("Training Isolation Forest...")
    model = IsolationForest(n_estimators=300, contamination=0.30,
                            max_samples="auto", random_state=42, n_jobs=-1)
    model.fit(X)
    joblib.dump(model, IF_PATH)
    logger.info(f"Saved → {IF_PATH}")
    return model


def load_isolation_forest():
    return joblib.load(IF_PATH) if os.path.exists(IF_PATH) else None


def predict_isolation_forest(model, X: np.ndarray) -> np.ndarray:
    raw = -model.decision_function(X)
    p5, p95 = np.percentile(raw, 5), np.percentile(raw, 95)
    return np.clip((raw - p5) / (p95 - p5 + 1e-10), 0, 1)


def predict_lof(X: np.ndarray) -> np.ndarray:
    logger.info("Running LOF...")
    n = min(30, max(5, len(X) // 10))
    lof = LocalOutlierFactor(n_neighbors=n, contamination=0.30,
                              novelty=False, metric="euclidean", n_jobs=-1)
    lof.fit_predict(X)
    raw = -lof.negative_outlier_factor_
    p5, p95 = np.percentile(raw, 5), np.percentile(raw, 95)
    return np.clip((raw - p5) / (p95 - p5 + 1e-10), 0, 1)


def predict_statistical(X: np.ndarray) -> np.ndarray:
    logger.info("Running Statistical...")
    z = np.abs((X - np.mean(X, axis=0)) / (np.std(X, axis=0) + 1e-10))
    top3 = np.mean(np.sort(z, axis=1)[:, ::-1][:, :3], axis=1)
    p5, p95 = np.percentile(top3, 5), np.percentile(top3, 95)
    return np.clip((top3 - p5) / (p95 - p5 + 1e-10), 0, 1)


def train_scaler(X: np.ndarray) -> StandardScaler:
    scaler = StandardScaler()
    scaler.fit(X)
    joblib.dump(scaler, SCALER_PATH)
    logger.info(f"Scaler saved → {SCALER_PATH}")
    return scaler


def load_scaler():
    return joblib.load(SCALER_PATH) if os.path.exists(SCALER_PATH) else None
