# run_training.py
# Uploads ALL files (raw .log + structured CSV + templates)
# for all 16 log types — combined training for maximum robustness

import os
import requests

API_URL      = "http://localhost:8002/api/v3/train-loghub"
LOGHUB_DIR   = r"E:\echo-log\loghub"
TRAINING_DIR = r"E:\echo-log\module3_anomaly_detection\training_data"

# All 16 log type folder names in loghub
LOG_TYPE_FOLDERS = [
    "Android", "Apache", "BGL", "Hadoop", "HDFS",
    "HealthApp", "HPC", "Linux", "Mac", "OpenSSH",
    "OpenStack", "Proxifier", "Spark", "Thunderbird",
    "Windows", "Zookeeper"
]


def collect_all_files() -> list[str]:
    """
    Collects ALL 3 file types for each log type:
    1. raw .log file
    2. _structured.csv file
    3. _templates.csv file
    """
    all_files = []
    missing   = []

    print("\n📁 Scanning loghub for all file types...\n")

    for log_type in LOG_TYPE_FOLDERS:
        folder = os.path.join(LOGHUB_DIR, log_type)

        if not os.path.exists(folder):
            missing.append(f"{log_type} folder missing")
            continue

        found_files = os.listdir(folder)
        type_files  = []

        for f in found_files:
            filepath = os.path.join(folder, f)

            # Include all 3 file types
            if (
                f.endswith("_structured.csv") or
                f.endswith("_templates.csv")  or
                f.endswith(".log")
            ):
                type_files.append(filepath)

        if type_files:
            print(f"  ✅ {log_type:<15} → {len(type_files)} files found")
            for f in type_files:
                print(f"       → {os.path.basename(f)}")
            all_files.extend(type_files)
        else:
            missing.append(f"{log_type} — no files found in folder")
            print(f"  ❌ {log_type:<15} → no files found")

    if missing:
        print(f"\n⚠️  Missing: {missing}")

    print(f"\n📊 Total files collected: {len(all_files)}")
    return all_files


def train_model():
    print("=" * 65)
    print("  Echo-Log ML Model Training — Combined Raw + Structured")
    print("=" * 65)

    # Collect all files from loghub
    all_files = collect_all_files()

    if not all_files:
        print("❌ No files found! Check if loghub is cloned correctly.")
        return

    print(f"\n🚀 Starting training on {len(all_files)} files...")
    print("   (raw .log + structured CSV + templates for each type)")
    print("   This may take 2-3 minutes...\n")

    # Open all files
    files_payload = []
    file_handles  = []

    for filepath in all_files:
        filename = os.path.basename(filepath)
        fh = open(filepath, "rb")
        file_handles.append(fh)

        # Set correct mime type
        mime = "text/csv" if filepath.endswith(".csv") else "text/plain"
        files_payload.append(("files", (filename, fh, mime)))

    try:
        response = requests.post(
            API_URL,
            files=files_payload,
            timeout=600  # 10 minute timeout for large dataset
        )

        if response.status_code == 200:
            result   = response.json()
            training = result.get("training_result", {})

            print("=" * 65)
            print("  ✅ TRAINING COMPLETE!")
            print("=" * 65)

            print(f"\n📊 Training Summary:")
            print(f"   Total files used     : {training.get('total_files_used', 0)}")
            print(f"   Total entries        : {training.get('total_entries_trained', 0)}")
            print(f"   Features per entry   : {training.get('feature_count', 0)}")
            print(f"   Templates loaded     : {training.get('templates_loaded', 0)}")

            breakdown = training.get("log_type_breakdown", {})
            if breakdown:
                print(f"\n📋 Log Type Breakdown (Raw + Structured Combined):")
                total = 0
                for log_type, count in sorted(breakdown.items()):
                    print(f"   {log_type:<15} → {count} entries")
                    total += count
                print(f"   {'─' * 30}")
                print(f"   {'TOTAL':<15} → {total} entries")

            print(f"\n💾 Saved to: saved_models/")
            print(f"   → isolation_forest.pkl")
            print(f"   → scaler.pkl")
            print(f"   → training_metadata.json")
            print(f"\n🎯 Model is now trained on BOTH raw + structured data!")
            print(f"   Ready for anomaly detection on any log format.")

        else:
            print(f"❌ Training failed!")
            print(f"   Status : {response.status_code}")
            print(f"   Error  : {response.text[:500]}")

    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to server!")
        print("   Make sure Module 3 server is running: python main.py")

    except Exception as e:
        print(f"❌ Unexpected error: {e}")

    finally:
        for fh in file_handles:
            fh.close()


if __name__ == "__main__":
    train_model()
