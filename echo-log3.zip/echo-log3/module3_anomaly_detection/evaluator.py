# evaluator.py — 7 graphs + performance metrics for all 16 log types

import os
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from loguru import logger

GRAPHS_DIR = "performance_graphs"
os.makedirs(GRAPHS_DIR, exist_ok=True)


# ── Graph 1: Score Distribution ───────────────────────────────────────────────
def plot_score_distribution(results: list) -> str:
    scores  = [r["anomaly_score"] for r in results]
    normal  = [s for s, r in zip(scores, results) if not r["is_anomaly"]]
    anomaly = [s for s, r in zip(scores, results) if r["is_anomaly"]]

    fig, ax = plt.subplots(figsize=(11, 5))
    ax.hist(normal,  bins=30, alpha=0.7, color="#2ecc71", label="Normal",  edgecolor="white")
    ax.hist(anomaly, bins=30, alpha=0.7, color="#e74c3c", label="Anomaly", edgecolor="white")
    ax.axvline(x=30, color="orange", linestyle="--", linewidth=2, label="Threshold (30)")
    ax.set_xlabel("Anomaly Score", fontsize=12)
    ax.set_ylabel("Number of Log Entries", fontsize=12)
    ax.set_title("Anomaly Score Distribution", fontsize=14, fontweight="bold")
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    path = os.path.join(GRAPHS_DIR, "1_score_distribution.png")
    plt.tight_layout(); plt.savefig(path, dpi=150); plt.close()
    logger.info(f"Saved: {path}")
    return path


# ── Graph 2: Severity Breakdown ───────────────────────────────────────────────
def plot_severity_breakdown(report: dict) -> str:
    data = [
        ("CRITICAL", report.get("critical_count", 0), "#c0392b"),
        ("HIGH",     report.get("high_count",     0), "#e74c3c"),
        ("MEDIUM",   report.get("medium_count",   0), "#f39c12"),
        ("LOW",      report.get("low_count",      0), "#f1c40f"),
        ("NORMAL",   report.get("normal_count",   0), "#2ecc71"),
    ]
    data = [(l, s, c) for l, s, c in data if s > 0]
    if not data:
        return None

    labels, sizes, colors = zip(*data)
    explode = [0.1 if i == 0 else 0.03 for i in range(len(labels))]

    fig, ax = plt.subplots(figsize=(8, 8))
    _, _, autotexts = ax.pie(sizes, labels=labels, colors=colors, explode=explode,
                              autopct="%1.1f%%", startangle=140,
                              textprops={"fontsize": 12})
    for at in autotexts:
        at.set_fontweight("bold")
    ax.set_title("Severity Level Breakdown", fontsize=14, fontweight="bold")
    path = os.path.join(GRAPHS_DIR, "2_severity_breakdown.png")
    plt.tight_layout(); plt.savefig(path, dpi=150); plt.close()
    logger.info(f"Saved: {path}")
    return path


# ── Graph 3: Model Score Comparison ──────────────────────────────────────────
def plot_model_comparison(results: list) -> str:
    normal    = [r for r in results if not r["is_anomaly"]]
    anomalous = [r for r in results if r["is_anomaly"]]
    models = ["Isolation Forest", "LOF", "Statistical"]
    keys   = ["isolation_forest_score", "lof_score", "statistical_score"]
    navg   = [np.mean([r[k] for r in normal])    if normal    else 0 for k in keys]
    aavg   = [np.mean([r[k] for r in anomalous]) if anomalous else 0 for k in keys]

    x, w = np.arange(len(models)), 0.35
    fig, ax = plt.subplots(figsize=(10, 6))
    b1 = ax.bar(x - w/2, navg, w, label="Normal",  color="#2ecc71", edgecolor="white")
    b2 = ax.bar(x + w/2, aavg, w, label="Anomaly", color="#e74c3c", edgecolor="white")
    ax.set_xlabel("ML Model", fontsize=12)
    ax.set_ylabel("Average Score", fontsize=12)
    ax.set_title("Model Score Comparison: Normal vs Anomaly", fontsize=14, fontweight="bold")
    ax.set_xticks(x); ax.set_xticklabels(models, fontsize=11)
    ax.legend(fontsize=11); ax.grid(True, axis="y", alpha=0.3); ax.set_ylim(0, 100)
    for bar in list(b1) + list(b2):
        h = bar.get_height()
        ax.annotate(f"{h:.1f}", xy=(bar.get_x() + bar.get_width()/2, h),
                    xytext=(0, 3), textcoords="offset points", ha="center", fontsize=9)
    path = os.path.join(GRAPHS_DIR, "3_model_comparison.png")
    plt.tight_layout(); plt.savefig(path, dpi=150); plt.close()
    logger.info(f"Saved: {path}")
    return path


# ── Graph 4: Top Suspicious Entities ─────────────────────────────────────────
def plot_top_suspicious_ips(report: dict) -> str:
    entities = report.get("top_suspicious_ips", [])
    if not entities:
        return None

    labels  = [str(e.get("entity") or e.get("ip") or "?")[:28] for e in entities[:10]]
    scores  = [float(e.get("max_score", 0))   for e in entities[:10]]
    counts  = [int(e.get("anomaly_count", 0)) for e in entities[:10]]
    etypes  = [str(e.get("type", "ip"))        for e in entities[:10]]
    colors  = ["#c0392b" if s >= 85 else "#e74c3c" if s >= 70 else "#f39c12" for s in scores]

    type_set = set(etypes)
    title = ("Top Suspicious IP Addresses" if type_set == {"ip"} else
             "Top Suspicious Apps / Packages" if "app" in type_set else
             "Top Suspicious Jobs / Tasks"    if "job" in type_set else
             "Top Suspicious Entities")

    fig, ax = plt.subplots(figsize=(13, 6))
    bars = ax.barh(labels, scores, color=colors, edgecolor="white")
    ax.set_xlabel("Max Anomaly Score", fontsize=12)
    ax.set_title(title, fontsize=14, fontweight="bold")
    ax.set_xlim(0, 115)
    ax.axvline(x=85, color="#c0392b", linestyle="--", alpha=0.7, label="Critical (85)")
    ax.axvline(x=70, color="#e74c3c", linestyle="--", alpha=0.7, label="High (70)")
    ax.legend(fontsize=10)
    ax.grid(True, axis="x", alpha=0.3)
    for bar, cnt, et in zip(bars, counts, etypes):
        ax.text(bar.get_width() + 0.5, bar.get_y() + bar.get_height()/2,
                f"{cnt} anomalies [{et}]", va="center", fontsize=9)
    path = os.path.join(GRAPHS_DIR, "4_suspicious_ips.png")
    plt.tight_layout(); plt.savefig(path, dpi=150); plt.close()
    logger.info(f"Saved: {path}")
    return path


# ── Graph 5: Anomaly Types — with COUNTS not just yes/no ─────────────────────
def plot_anomaly_types(report: dict) -> str:
    analysis = report.get("anomaly_type_analysis", {})

    if analysis:
        rows = [
            ("High Error Rate",     analysis.get("high_error_rate",     {}).get("count", 0)),
            ("Unauthorized Access", analysis.get("unauthorized_access",  {}).get("count", 0)),
            ("Unusual Operations",  analysis.get("unusual_operations",   {}).get("count", 0)),
            ("Repeated Abuse",      analysis.get("repeated_abuse",       {}).get("count", 0)),
            ("Performance Issues",  analysis.get("performance_issues",   {}).get("count", 0)),
        ]
    else:
        # Fallback to boolean flags
        rows = [
            ("High Error Rate",     int(report.get("high_error_rate_detected",     False))),
            ("Unauthorized Access", int(report.get("unauthorized_access_detected",  False))),
            ("Unusual Operations",  int(report.get("unusual_methods_detected",      False))),
            ("Repeated Abuse",      int(report.get("ip_abuse_detected",             False))),
            ("Performance Issues",  int(report.get("response_time_spike_detected",  False))),
        ]

    labels  = [r[0] for r in rows]
    counts  = [r[1] for r in rows]
    colors  = ["#e74c3c" if c > 0 else "#95a5a6" for c in counts]

    fig, ax = plt.subplots(figsize=(13, 6))
    bars = ax.bar(labels, counts, color=colors, edgecolor="white", width=0.5)
    ax.set_ylabel("Entries Detected", fontsize=12)
    ax.set_title("All 5 Anomaly Types — Detected Count per Category", fontsize=14, fontweight="bold")
    ax.grid(True, axis="y", alpha=0.3)
    ax.tick_params(axis="x", labelsize=10)

    max_c = max(counts) if any(c > 0 for c in counts) else 1
    for bar, c in zip(bars, counts):
        label = f"✓ {c}" if c > 0 else "✗ 0"
        ax.text(bar.get_x() + bar.get_width()/2,
                bar.get_height() + max_c * 0.02,
                label, ha="center", fontsize=11, fontweight="bold",
                color="#e74c3c" if c > 0 else "#95a5a6")

    path = os.path.join(GRAPHS_DIR, "5_anomaly_types.png")
    plt.tight_layout(); plt.savefig(path, dpi=150); plt.close()
    logger.info(f"Saved: {path}")
    return path


# ── Graph 6: Score Timeline ───────────────────────────────────────────────────
def plot_score_timeline(results: list) -> str:
    lines  = [r["line_number"]   for r in results]
    scores = [r["anomaly_score"] for r in results]

    fig, ax = plt.subplots(figsize=(14, 5))
    ax.plot(lines, scores, color="#3498db", linewidth=0.8, alpha=0.7, label="Anomaly Score")
    ax.fill_between(lines, scores, 30, where=[s > 30 for s in scores],
                    alpha=0.3, color="#e74c3c", label="Anomalous Zone")
    crit_l = [r["line_number"]   for r in results if r["severity"] == "CRITICAL"]
    crit_s = [r["anomaly_score"] for r in results if r["severity"] == "CRITICAL"]
    if crit_l:
        ax.scatter(crit_l, crit_s, color="#c0392b", s=50, zorder=5, label="CRITICAL")
    ax.axhline(y=30, color="orange",  linestyle="--", linewidth=1.5, label="Threshold (30)")
    ax.axhline(y=70, color="#e74c3c", linestyle="--", linewidth=1.5, alpha=0.7, label="High (70)")
    ax.axhline(y=85, color="#c0392b", linestyle="--", linewidth=1.5, alpha=0.7, label="Critical (85)")
    ax.set_xlabel("Log Line Number", fontsize=12)
    ax.set_ylabel("Anomaly Score",   fontsize=12)
    ax.set_title("Anomaly Score Timeline — All Log Entries", fontsize=14, fontweight="bold")
    ax.legend(fontsize=9, loc="upper right")
    ax.set_ylim(0, 105)
    ax.grid(True, alpha=0.3)
    path = os.path.join(GRAPHS_DIR, "6_score_timeline.png")
    plt.tight_layout(); plt.savefig(path, dpi=150); plt.close()
    logger.info(f"Saved: {path}")
    return path


# ── Graph 7: Training Data Breakdown ─────────────────────────────────────────
def plot_training_breakdown() -> str:
    meta_path = "saved_models/training_metadata.json"
    if not os.path.exists(meta_path):
        return None
    with open(meta_path) as f:
        meta = json.load(f)
    breakdown = meta.get("log_type_breakdown", {})
    if not breakdown:
        return None

    log_types = list(breakdown.keys())
    counts    = list(breakdown.values())
    colors    = plt.cm.Set3(np.linspace(0, 1, len(log_types)))

    fig, ax = plt.subplots(figsize=(13, 6))
    bars = ax.bar(log_types, counts, color=colors, edgecolor="white")
    ax.set_xlabel("Log Type", fontsize=12)
    ax.set_ylabel("Training Entries", fontsize=12)
    ax.set_title("Training Data Breakdown by Log Type", fontsize=14, fontweight="bold")
    ax.tick_params(axis="x", rotation=45)
    ax.grid(True, axis="y", alpha=0.3)
    for bar, c in zip(bars, counts):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 10,
                str(c), ha="center", fontsize=9)
    path = os.path.join(GRAPHS_DIR, "7_training_breakdown.png")
    plt.tight_layout(); plt.savefig(path, dpi=150); plt.close()
    logger.info(f"Saved: {path}")
    return path


# ── Performance Metrics ───────────────────────────────────────────────────────
def calculate_metrics(results: list) -> dict:
    scores = np.array([r["anomaly_score"] for r in results])
    is_anom = np.array([r["is_anomaly"] for r in results])
    total   = len(results)
    n_anom  = int(np.sum(is_anom))
    n_norm  = total - n_anom

    avg_a = float(np.mean(scores[is_anom]))  if n_anom else 0
    avg_n = float(np.mean(scores[~is_anom])) if n_norm else 0
    sep   = avg_a - avg_n

    quality = ("🌟 Excellent" if sep >= 40 else
               "🟢 Good"      if sep >= 25 else
               "🟡 Fair"      if sep >= 15 else
               "🔴 Poor — retrain with more data")

    sev = {}
    for r in results:
        sev[r["severity"]] = sev.get(r["severity"], 0) + 1

    return {
        "total_entries":     total,
        "anomaly_count":     n_anom,
        "normal_count":      n_norm,
        "anomaly_rate":      round(n_anom / total * 100, 2) if total else 0,
        "avg_anomaly_score": round(avg_a, 2),
        "avg_normal_score":  round(avg_n, 2),
        "avg_overall_score": round(float(np.mean(scores)), 2),
        "score_std_dev":     round(float(np.std(scores)), 2),
        "score_separation":  round(sep, 2),
        "separation_quality": quality,
        "severity_breakdown": sev,
        "model_components": {
            "isolation_forest_weight": "40%",
            "lof_weight":              "35%",
            "statistical_weight":      "25%",
        },
    }


# ── Master Evaluation ─────────────────────────────────────────────────────────
def generate_full_evaluation(report: dict) -> dict:
    results = report.get("results", [])
    if not results:
        return {"error": "No results to evaluate"}

    logger.info("Generating full evaluation — 7 graphs + metrics...")

    paths = {
        "score_distribution": plot_score_distribution(results),
        "severity_breakdown": plot_severity_breakdown(report),
        "model_comparison":   plot_model_comparison(results),
        "suspicious_ips":     plot_top_suspicious_ips(report),
        "anomaly_types":      plot_anomaly_types(report),
        "score_timeline":     plot_score_timeline(results),
        "training_breakdown": plot_training_breakdown(),
    }
    paths = {k: v for k, v in paths.items() if v}

    metrics = calculate_metrics(results)
    mpath   = os.path.join(GRAPHS_DIR, "performance_metrics.json")
    with open(mpath, "w") as f:
        json.dump(metrics, f, indent=2)

    logger.info(f"✅ {len(paths)} graphs generated | Quality: {metrics['separation_quality']}")
    return {"metrics": metrics, "graphs_generated": len(paths),
            "graph_paths": paths, "metrics_path": mpath}
