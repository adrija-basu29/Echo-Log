# test_pipeline.py
# Automatically chains Module 2 → Module 3
# No copy-pasting needed!

import os
import sys
import json
import requests

MODULE2_URL = "http://localhost:8001/api/v2/preprocess"
MODULE3_URL = "http://localhost:8002/api/v3/analyze-and-evaluate"

# ── Put any log file path here ─────────────────────────
LOG_FILE = r"E:\echo-log\loghub\OpenSSH\OpenSSH_2k.log"
# ───────────────────────────────────────────────────────


def check_server(url: str, name: str) -> bool:
    try:
        r = requests.get(url.replace("/api/v2/preprocess", "")
                           .replace("/api/v3/analyze-and-evaluate", ""),
                         timeout=3)
        print(f"✅ {name} is running")
        return True
    except:
        print(f"❌ {name} is NOT running — start it first!")
        return False


def run_pipeline(log_file_path: str):
    print("=" * 60)
    print("  Echo-Log Pipeline Test: Module 2 → Module 3")
    print("=" * 60)

    # Check servers
    m2_ok = check_server(MODULE2_URL, "Module 2 (port 8001)")
    m3_ok = check_server(MODULE3_URL, "Module 3 (port 8002)")

    if not m2_ok or not m3_ok:
        print("\nPlease start both servers first!")
        return

    if not os.path.exists(log_file_path):
        print(f"\n❌ Log file not found: {log_file_path}")
        print("Update the LOG_FILE variable at the top of this script")
        return

    print(f"\n📂 Log file: {os.path.basename(log_file_path)}")

    # ── Step 1: Send to Module 2 ───────────────────────
    print("\n⏳ Step 1: Preprocessing with Module 2...")
    try:
        with open(log_file_path, "rb") as f:
            response = requests.post(
                MODULE2_URL,
                files={"file": (os.path.basename(log_file_path), f, "text/plain")},
                timeout=60
            )

        if response.status_code != 200:
            print(f"❌ Module 2 failed: {response.status_code}")
            print(response.text[:300])
            return

        m2_result        = response.json()
        structured_logs  = m2_result.get("structured_logs", [])

        print(f"✅ Module 2 done — {len(structured_logs)} log entries parsed")

    except Exception as e:
        print(f"❌ Module 2 error: {e}")
        return

    if not structured_logs:
        print("❌ No structured logs returned by Module 2")
        return

    # ── Step 2: Send to Module 3 ───────────────────────
    print("\n⏳ Step 2: Anomaly Detection with Module 3...")
    try:
        response = requests.post(
            MODULE3_URL,
            json={"structured_logs": structured_logs},
            timeout=120
        )

        if response.status_code != 200:
            print(f"❌ Module 3 failed: {response.status_code}")
            print(response.text[:500])
            return

        m3_result = response.json()

    except Exception as e:
        print(f"❌ Module 3 error: {e}")
        return

    # ── Step 3: Display Results ────────────────────────
    detection = m3_result.get("detection_report", {})
    metrics   = m3_result.get("performance_metrics", {})
    graphs    = m3_result.get("graphs_generated", 0)

    print(f"\n{'=' * 60}")
    print(f"  ✅ ANALYSIS COMPLETE")
    print(f"{'=' * 60}")

    print(f"\n📊 Detection Report:")
    print(f"   Total entries    : {detection.get('total_entries', 0)}")
    print(f"   Anomalies found  : {detection.get('anomaly_count', 0)}")
    print(f"   Anomaly rate     : {detection.get('anomaly_percentage', 0)}%")
    print(f"   CRITICAL         : {detection.get('critical_count', 0)}")
    print(f"   HIGH             : {detection.get('high_count', 0)}")
    print(f"   MEDIUM           : {detection.get('medium_count', 0)}")
    print(f"   LOW              : {detection.get('low_count', 0)}")

    print(f"\n📈 Performance Metrics:")
    print(f"   Avg anomaly score: {metrics.get('avg_anomaly_score', 0)}")
    print(f"   Avg normal score : {metrics.get('avg_normal_score', 0)}")
    print(f"   Separation       : {metrics.get('score_separation', 0)}")
    print(f"   Quality          : {metrics.get('separation_quality', 'N/A')}")

    print(f"\n🖼️  Graphs generated: {graphs}")
    print(f"   Saved to: performance_graphs/ folder")

    # Show top anomalies
    full_results = m3_result.get("detection_report", {})
    all_results  = m3_result.get("results", full_results.get("results", []))

    anomalies = sorted(
        [r for r in all_results if r.get("is_anomaly")],
        key=lambda x: x.get("anomaly_score", 0),
        reverse=True
    )[:5]

    if anomalies:
        print(f"\n🚨 Top {len(anomalies)} Anomalies Detected:")
        for i, a in enumerate(anomalies, 1):
            print(f"\n   [{i}] Line {a.get('line_number')} — {a.get('severity')}")
            print(f"       Score    : {a.get('anomaly_score')}")
            print(f"       Log type : {a.get('log_type', 'Unknown')}")
            print(f"       Raw text : {a.get('raw_text', '')[:80]}...")
            reasons = a.get("anomaly_reasons", [])
            for r in reasons[:3]:
                print(f"       ⚠️  {r}")

    # Save full result to file
    output_path = "last_analysis_result.json"
    with open(output_path, "w") as f:
        json.dump(m3_result, f, indent=2)
    print(f"\n💾 Full result saved to: {output_path}")


if __name__ == "__main__":
    # Allow passing log file as command line argument
    if len(sys.argv) > 1:
        LOG_FILE = sys.argv[1]

    run_pipeline(LOG_FILE)
