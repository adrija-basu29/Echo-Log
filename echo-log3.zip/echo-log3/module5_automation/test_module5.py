# test_module5.py
# Tests Module 5 Escalation & Auto-Remediation
# Run: python test_module5.py <path_to_log_file>
# Or:  python test_module5.py --dry-run <path_to_log_file>

import sys
import json
import requests

M5 = "http://localhost:8004/api/v5"

ICONS = {
    "AUTO_FIX": "🔧",
    "RESCALE":  "⚡",
    "ESCALATE": "🚨",
    "MONITOR":  "👁️",
}


def test_escalation(log_path: str, dry_run: bool = False):
    print("=" * 65)
    print("  Echo-Log — Module 5 Escalation & Auto-Remediation")
    print(f"  {'[ DRY RUN MODE ]' if dry_run else '[ LIVE MODE ]'}")
    print("=" * 65)

    try:
        with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = [l.strip() for l in f if l.strip()]
    except FileNotFoundError:
        print(f"❌ File not found: {log_path}")
        return

    structured_logs = [
        {
            "line_number": i,
            "raw_text":    line,
            "message":     line,
            "level":       "ERROR" if any(w in line.upper() for w in
                           ["ERROR","FATAL","EXCEPTION","FAIL","CRITICAL"]) else "INFO",
            "is_error":    any(w in line.upper() for w in
                           ["ERROR","FATAL","EXCEPTION","FAIL","CRITICAL"]),
            "is_warning":  any(w in line.upper() for w in ["WARN","WARNING"]),
            "service":     "",
            "timestamp":   None,
            "event_template": "",
        }
        for i, line in enumerate(lines[:2000], 1)
    ]

    print(f"\n📂 Loaded {len(structured_logs)} log entries from: {log_path}")
    print(f"\n🔄 Running Escalation pipeline...")

    try:
        resp = requests.post(
            f"{M5}/full-pipeline",
            json={"structured_logs": structured_logs, "dry_run": dry_run},
            timeout=300
        )
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to Module 5 (port 8004). Is it running?")
        return

    if resp.status_code != 200:
        print(f"❌ Error {resp.status_code}: {resp.text[:500]}")
        return

    data       = resp.json()["pipeline"]
    detection  = data["detection"]
    rca        = data["rca"]
    escalation = data["escalation"]

    # Detection Summary
    print("\n" + "=" * 65)
    print("  DETECTION  (Module 3)")
    print("=" * 65)
    print(f"  Total Entries : {detection['total_entries']}")
    print(f"  Anomalies     : {detection['anomaly_count']}")
    print(f"  Critical      : {detection['critical_count']}")

    # RCA Summary
    print("\n" + "=" * 65)
    print("  ROOT CAUSE ANALYSIS  (Module 4)")
    print("=" * 65)
    print(f"  Anomalies Analyzed : {rca['anomaly_count']}")
    print(f"  Causal Chains      : {rca['chains_detected']}")
    for fix in rca.get("top_fixes", []):
        print(f"  [{fix['rule_id']}] {fix['severity']} — {fix['root_cause'][:70]}")

    # Escalation Summary
    print("\n" + "=" * 65)
    print("  ESCALATION & REMEDIATION  (Module 5)")
    print("=" * 65)
    action  = escalation["overall_action"]
    urgency = escalation["overall_urgency"]
    icon    = ICONS.get(action, "•")
    print(f"\n  {icon}  Overall Action : {action}")
    print(f"  ⏱  Urgency        : {urgency}")
    print(f"\n  {escalation['escalation_summary']}")

    counts = escalation.get("action_counts", {})
    print(f"\n  Action Breakdown:")
    for a, c in counts.items():
        if c > 0:
            print(f"    {ICONS.get(a,'•')} {a:<12} : {c}")

    if escalation.get("executed_actions"):
        print(f"\n  Actions Executed:")
        for ea in escalation["executed_actions"]:
            status = ea["result"].get("status", "?")
            print(f"    • {ea['script']} → {status}")
            if ea["result"].get("freed_mb"):
                print(f"      Freed: {ea['result']['freed_mb']:.1f} MB")

    if escalation.get("rescale_needed"):
        print(f"\n  Rescale Recommendations:")
        for r in escalation["rescale_details"]:
            print(f"    ⚡ {r['resource'].upper()} — scale by {r['scale_by']}")
            print(f"       {r['reason']}")

    if escalation.get("escalation_count", 0) > 0:
        print(f"\n  🚨 Human Escalations Required: {escalation['escalation_count']}")
        for e in escalation["escalations"][:3]:
            print(f"    • [{e['urgency']}] {e['root_cause'][:80]}")
            print(f"      Team: {e['team']}")

    teams = escalation.get("teams_to_notify", [])
    if teams:
        print(f"\n  Teams to Notify: {', '.join(teams)}")

    before = escalation.get("system_before", {})
    after  = escalation.get("system_after", {})
    if before and "cpu_percent" in before:
        print(f"\n  System Metrics (Before → After):")
        for metric in ["cpu_percent", "memory_percent", "disk_percent"]:
            b = before.get(metric, 0)
            a = after.get(metric, 0)
            arrow = "↓" if a < b else ("↑" if a > b else "→")
            print(f"    {metric:<18}: {b:.1f}% {arrow} {a:.1f}%")

    recovery = escalation.get("recovery_status", {})
    if recovery.get("status") == "improved":
        print(f"\n  ✅ Recovery: {recovery['message']}")
    elif recovery.get("status") == "degraded":
        print(f"\n  ⚠️  Recovery: {recovery['message']}")

    print("\n" + "=" * 65)
    print("  ✅ Module 5 Escalation Complete")
    print("=" * 65)


if __name__ == "__main__":
    args    = [a for a in sys.argv[1:] if not a.startswith("--")]
    dry_run = "--dry-run" in sys.argv
    path    = args[0] if args else r"E:\echo-log\loghub\OpenSSH\OpenSSH_2k.log"
    test_escalation(path, dry_run=dry_run)
