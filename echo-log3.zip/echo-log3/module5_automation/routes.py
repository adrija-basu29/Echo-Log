# routes.py — Module 5: Escalation & Auto-Remediation API endpoints

import requests
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import Optional, List
from loguru import logger

from escalation_engine import run_escalation
from decision_engine import decide_for_rca_report
from remediation_scripts import (
    get_system_metrics, get_history,
    fix_cleanup_storage, fix_restart_service,
    fix_restart_heavy_processes, fix_restart_network_services,
    rescale_disk, rescale_memory, rescale_cpu,
    execute_action,
)

router = APIRouter()

MODULE4_URL = "http://localhost:8003/api/v4"
MODULE3_URL = "http://localhost:8002/api/v3"


# ── Request Schemas ───────────────────────────────────────────────────────────

class RCAReport(BaseModel):
    rca_results:         List[dict] = []
    causal_chains:       Optional[dict] = {}
    repeated_entities:   Optional[List[dict]] = []
    escalation_needed:   Optional[bool] = False
    anomaly_count:       Optional[int] = 0


class EscalateRequest(BaseModel):
    rca_report: RCAReport
    dry_run:    Optional[bool] = False


class LogEntry(BaseModel):
    line_number:    int
    raw_text:       str
    message:        str = ""
    level:          Optional[str] = None
    service:        Optional[str] = None
    is_error:       bool = False
    is_warning:     bool = False
    log_type:       Optional[str] = None
    event_template: Optional[str] = None
    timestamp:      Optional[str] = None


class FullPipelineRequest(BaseModel):
    structured_logs: List[LogEntry]
    dry_run:         Optional[bool] = False


class ManualFixRequest(BaseModel):
    fix_type:  str          # "cleanup_storage" | "restart_service" | etc.
    service:   Optional[str] = "echo-log"
    dry_run:   Optional[bool] = False


class ManualRescaleRequest(BaseModel):
    resource:  str          # "disk" | "memory" | "cpu"
    amount:    Optional[str] = "2x"
    dry_run:   Optional[bool] = False


# ── Routes ────────────────────────────────────────────────────────────────────

@router.post("/escalate")
async def escalate(request: EscalateRequest):
    """
    Main endpoint — takes RCA report from Module 4 and:
    1. Decides what action to take per anomaly
    2. Executes safe auto-fixes
    3. Recommends rescaling if needed
    4. Flags items needing human escalation
    """
    logger.info(f"POST /escalate — {request.rca_report.anomaly_count} anomalies")
    try:
        report = run_escalation(request.rca_report.dict(), dry_run=request.dry_run)
        return {"status": "success", "escalation_report": report}
    except Exception as e:
        logger.error(f"Escalation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/full-pipeline")
async def full_pipeline(request: FullPipelineRequest):
    """
    Full chain: logs → Module 3 (detect) → Module 4 (RCA) → Module 5 (escalate)
    Single endpoint that runs the entire pipeline.
    """
    logger.info(f"POST /full-pipeline — {len(request.structured_logs)} log entries")

    # Step 1: Module 3 — Anomaly Detection
    try:
        m3_payload = {"structured_logs": [e.dict() for e in request.structured_logs]}
        m3_resp    = requests.post(f"{MODULE3_URL}/analyze", json=m3_payload, timeout=180)
        if m3_resp.status_code != 200:
            raise HTTPException(status_code=502, detail=f"Module 3 error: {m3_resp.text[:300]}")
        detection_report = m3_resp.json().get("detection_report", {})
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="Module 3 (port 8002) is not running.")

    # Step 2: Module 4 — Root Cause Analysis
    try:
        m4_payload = {"detection_report": detection_report}
        m4_resp    = requests.post(f"{MODULE4_URL}/analyze", json=m4_payload, timeout=120)
        if m4_resp.status_code != 200:
            raise HTTPException(status_code=502, detail=f"Module 4 error: {m4_resp.text[:300]}")
        rca_report = m4_resp.json().get("rca_report", {})
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail="Module 4 (port 8003) is not running.")

    # Step 3: Module 5 — Escalation & Remediation
    try:
        escalation_report = run_escalation(rca_report, dry_run=request.dry_run)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Escalation error: {e}")

    return {
        "status": "success",
        "pipeline": {
            "detection": {
                "total_entries":   detection_report.get("total_entries", 0),
                "anomaly_count":   detection_report.get("anomaly_count", 0),
                "critical_count":  detection_report.get("critical_count", 0),
            },
            "rca": {
                "anomaly_count":    rca_report.get("anomaly_count", 0),
                "top_fixes":        rca_report.get("top_fixes", [])[:2],
                "chains_detected":  rca_report.get("causal_chains", {}).get("chains_detected", 0),
            },
            "escalation": escalation_report,
        }
    }


@router.post("/decide-only")
async def decide_only(request: EscalateRequest):
    """
    Returns the decision for each anomaly WITHOUT executing anything.
    Useful for previewing what actions would be taken.
    """
    try:
        decisions = decide_for_rca_report(request.rca_report.dict())
        return {"status": "success", "decisions": decisions}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/manual-fix")
async def manual_fix(request: ManualFixRequest):
    """
    Manually trigger a specific auto-fix script.
    Available: cleanup_storage | restart_service | restart_heavy_processes | restart_network_services
    """
    logger.info(f"POST /manual-fix — {request.fix_type}")

    FIX_MAP = {
        "cleanup_storage":          lambda: fix_cleanup_storage(dry_run=request.dry_run),
        "restart_service":          lambda: fix_restart_service(request.service, dry_run=request.dry_run),
        "restart_heavy_processes":  lambda: fix_restart_heavy_processes(dry_run=request.dry_run),
        "restart_network_services": lambda: fix_restart_network_services(dry_run=request.dry_run),
    }

    fn = FIX_MAP.get(request.fix_type)
    if not fn:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown fix type '{request.fix_type}'. "
                   f"Available: {list(FIX_MAP.keys())}"
        )
    try:
        result = fn()
        return {"status": "success", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/manual-rescale")
async def manual_rescale(request: ManualRescaleRequest):
    """
    Manually trigger a rescale recommendation.
    Available resources: disk | memory | cpu
    """
    logger.info(f"POST /manual-rescale — {request.resource} by {request.amount}")

    RESCALE_MAP = {
        "disk":   lambda: rescale_disk(request.amount, dry_run=request.dry_run),
        "memory": lambda: rescale_memory(request.amount, dry_run=request.dry_run),
        "cpu":    lambda: rescale_cpu(request.amount, dry_run=request.dry_run),
    }

    fn = RESCALE_MAP.get(request.resource)
    if not fn:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown resource '{request.resource}'. Available: disk, memory, cpu"
        )
    try:
        result = fn()
        return {"status": "success", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/system-metrics")
async def system_metrics():
    """Get current server resource usage (CPU, RAM, Disk)."""
    return {"status": "success", "metrics": get_system_metrics()}


@router.get("/history")
async def remediation_history(limit: int = Query(default=50, le=200)):
    """Get history of all auto-fix and rescale actions taken."""
    return {"status": "success", "history": get_history(limit=limit)}


@router.get("/health")
async def health():
    # Instant — no external calls so launcher health check is fast
    return {"status": "healthy", "port": 8004}


@router.get("/health/full")
async def health_full():
    # Full health check with module connectivity and metrics — can be slow
    m4_ok = m3_ok = False
    try:
        m4_ok = requests.get(f"{MODULE4_URL}/health", timeout=3).status_code == 200
    except Exception:
        pass
    try:
        m3_ok = requests.get(f"{MODULE3_URL}/health", timeout=3).status_code == 200
    except Exception:
        pass
    return {
        "status":            "healthy",
        "port":              8004,
        "module3_connected": m3_ok,
        "module4_connected": m4_ok,
        "metrics":           get_system_metrics(),
    }
