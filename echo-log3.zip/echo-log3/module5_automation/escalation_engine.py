# escalation_engine.py
# Master Escalation Orchestrator
# Receives RCA report from Module 4 → decides → executes → returns full action report

import json
from datetime import datetime
from loguru import logger
from decision_engine import decide_for_rca_report, ACTION_ESCALATE, ACTION_RESCALE, ACTION_AUTO_FIX, ACTION_MONITOR
from remediation_scripts import execute_action, get_system_metrics, get_history


def run_escalation(rca_report: dict, dry_run: bool = False) -> dict:
    """
    Master function — full escalation pipeline:
    1. Assess the RCA report
    2. Make decisions for each anomaly
    3. Execute top-priority action
    4. Return complete action report
    """
    logger.info("Starting escalation pipeline...")

    # ── Step 1: Get system state before any action ─────────────────
    metrics_before = get_system_metrics()

    # ── Step 2: Run decision engine ────────────────────────────────
    decisions = decide_for_rca_report(rca_report)
    overall   = decisions["overall_action"]
    urgency   = decisions["overall_urgency"]

    logger.info(f"Decision: {overall} | Urgency: {urgency}")

    # ── Step 3: Execute unique top actions ─────────────────────────
    # Don't execute same action type twice — deduplicate
    executed_actions = []
    seen_scripts     = set()

    for entry in decisions["per_entry_decisions"]:
        fix_script   = entry.get("fix_script")
        rescale_type = entry.get("rescale_type")
        action       = entry.get("action")
        key          = fix_script or rescale_type or action

        if key in seen_scripts:
            continue
        seen_scripts.add(key)

        if action in (ACTION_AUTO_FIX, ACTION_RESCALE):
            result = execute_action(entry, dry_run=dry_run)
            executed_actions.append({
                "triggered_by": entry.get("root_cause", "")[:80],
                "action":       action,
                "script":       fix_script or rescale_type,
                "result":       result,
            })

        # Only process top 3 unique actions
        if len(executed_actions) >= 3:
            break

    # ── Step 4: Escalation entries (for human review) ──────────────
    escalations = [
        {
            "line_number": e.get("line_number"),
            "severity":    e.get("severity"),
            "root_cause":  e.get("root_cause", "")[:120],
            "reason":      e.get("reason"),
            "urgency":     e.get("urgency"),
            "team":        e.get("notify_team"),
        }
        for e in decisions["per_entry_decisions"]
        if e["action"] == ACTION_ESCALATE
    ]

    # ── Step 5: System state after actions ────────────────────────
    metrics_after = get_system_metrics()

    # ── Step 6: Build final report ────────────────────────────────
    report = {
        "timestamp":       datetime.now().isoformat(),
        "dry_run":         dry_run,

        # Decision summary
        "overall_action":  overall,
        "overall_urgency": urgency,
        "escalation_summary": decisions["escalation_summary"],

        # Action counts
        "action_counts":   decisions["action_counts"],

        # What was executed
        "executed_actions": executed_actions,
        "actions_executed": len(executed_actions),

        # Escalations for humans
        "escalations":     escalations,
        "escalation_count": len(escalations),
        "escalation_needed": len(escalations) > 0,

        # Rescaling
        "rescale_needed":  decisions["rescale_needed"],
        "rescale_details": decisions["rescale_details"],

        # Teams notified
        "teams_to_notify": decisions["teams_to_notify"],

        # Active causal chains
        "active_chains":   decisions.get("active_chains", []),

        # System metrics
        "system_before":   metrics_before,
        "system_after":    metrics_after,

        # Recovery assessment
        "recovery_status": _assess_recovery(
            metrics_before, metrics_after, executed_actions
        ),
    }

    logger.info(
        f"Escalation complete | Action={overall} | "
        f"Executed={len(executed_actions)} | "
        f"Escalated={len(escalations)}"
    )
    return report


def _assess_recovery(before: dict, after: dict, actions: list) -> dict:
    """Compare before/after metrics to see if actions helped."""
    if not actions or "error" in before or "error" in after:
        return {"status": "unknown", "message": "Cannot assess recovery — no metrics available"}

    improvements = []
    regressions  = []

    for metric in ["cpu_percent", "memory_percent", "disk_percent"]:
        b = before.get(metric, 0)
        a = after.get(metric, 0)
        if b > 0 and a < b * 0.9:     # 10% improvement
            improvements.append(f"{metric}: {b:.1f}% → {a:.1f}%")
        elif a > b * 1.1:             # 10% worse
            regressions.append(f"{metric}: {b:.1f}% → {a:.1f}%")

    if improvements:
        return {
            "status":       "improved",
            "message":      "System metrics improved after remediation",
            "improvements": improvements,
        }
    if regressions:
        return {
            "status":      "degraded",
            "message":     "System metrics worsened — escalation may be needed",
            "regressions": regressions,
        }
    return {
        "status":  "stable",
        "message": "System metrics unchanged after remediation",
    }
