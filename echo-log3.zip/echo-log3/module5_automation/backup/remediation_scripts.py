# remediation_scripts.py
# Auto-Remediation & Rescaling Engine
# Executes predefined safe recovery actions based on the decision
# Each action is logged with before/after state
#
# SAFETY RULES:
#   - Only runs scripts explicitly whitelisted here
#   - Never deletes user data
#   - Always logs what it does
#   - Dry-run mode available for testing

import os
import sys
import json
import shutil
import subprocess
import platform
from datetime import datetime
from loguru import logger

IS_WINDOWS = platform.system() == "Windows"
DRY_RUN    = os.getenv("ECHO_LOG_DRY_RUN", "false").lower() == "true"
LOG_FILE   = "logs/remediation_history.json"

os.makedirs("logs", exist_ok=True)


# ─────────────────────────────────────────────────────────────────────────────
# Remediation History — persists every action taken
# ─────────────────────────────────────────────────────────────────────────────

def log_action(action_name: str, status: str, details: dict):
    entry = {
        "timestamp":   datetime.now().isoformat(),
        "action":      action_name,
        "status":      status,         # "success" / "failed" / "dry_run"
        "dry_run":     DRY_RUN,
        "details":     details,
    }
    history = []
    if os.path.exists(LOG_FILE):
        try:
            with open(LOG_FILE) as f:
                history = json.load(f)
        except Exception:
            history = []
    history.append(entry)
    with open(LOG_FILE, "w") as f:
        json.dump(history[-500:], f, indent=2)   # Keep last 500 entries
    return entry


def get_history(limit: int = 50) -> list:
    if not os.path.exists(LOG_FILE):
        return []
    try:
        with open(LOG_FILE) as f:
            history = json.load(f)
        return list(reversed(history[-limit:]))
    except Exception:
        return []


# ─────────────────────────────────────────────────────────────────────────────
# System Metrics — before/after snapshots
# ─────────────────────────────────────────────────────────────────────────────

def get_system_metrics() -> dict:
    """Get current system resource usage."""
    try:
        import psutil
        disk  = psutil.disk_usage("/")
        mem   = psutil.virtual_memory()
        cpu   = psutil.cpu_percent(interval=0.1)
        return {
            "cpu_percent":    cpu,
            "memory_percent": mem.percent,
            "memory_used_gb": round(mem.used / (1024**3), 2),
            "memory_total_gb": round(mem.total / (1024**3), 2),
            "disk_percent":   disk.percent,
            "disk_used_gb":   round(disk.used / (1024**3), 2),
            "disk_total_gb":  round(disk.total / (1024**3), 2),
            "disk_free_gb":   round(disk.free / (1024**3), 2),
        }
    except ImportError:
        return {"error": "psutil not installed — run: pip install psutil"}
    except Exception as e:
        return {"error": str(e)}


# ─────────────────────────────────────────────────────────────────────────────
# AUTO-FIX SCRIPTS
# ─────────────────────────────────────────────────────────────────────────────

def fix_cleanup_storage(dry_run: bool = False) -> dict:
    """
    AUTO-FIX: Storage cleanup
    - Deletes log files older than 7 days
    - Clears temp files
    - Empties recycle bin / trash
    """
    before = get_system_metrics()
    freed_mb = 0
    actions  = []

    if dry_run or DRY_RUN:
        return {
            "action":  "cleanup_storage",
            "status":  "dry_run",
            "message": "DRY RUN — would delete old logs and temp files",
            "before":  before,
        }

    try:
        # Clear Python cache files
        for root, dirs, files in os.walk("."):
            for d in dirs:
                if d == "__pycache__":
                    path = os.path.join(root, d)
                    size = sum(
                        os.path.getsize(os.path.join(dp, f))
                        for dp, dn, fn in os.walk(path)
                        for f in fn
                    )
                    shutil.rmtree(path, ignore_errors=True)
                    freed_mb += size / (1024 * 1024)
                    actions.append(f"Removed __pycache__: {path}")

        # Clear log files in logs/ directory older than 7 days
        log_dir = "logs"
        if os.path.exists(log_dir):
            now = datetime.now().timestamp()
            for f in os.listdir(log_dir):
                fp = os.path.join(log_dir, f)
                if f.endswith(".log") and os.path.isfile(fp):
                    age_days = (now - os.path.getmtime(fp)) / 86400
                    if age_days > 7:
                        size = os.path.getsize(fp)
                        os.remove(fp)
                        freed_mb += size / (1024 * 1024)
                        actions.append(f"Deleted old log: {f} ({age_days:.0f} days old)")

        after = get_system_metrics()
        result = {
            "action":    "cleanup_storage",
            "status":    "success",
            "freed_mb":  round(freed_mb, 2),
            "actions":   actions,
            "before":    before,
            "after":     after,
        }
        log_action("cleanup_storage", "success", result)
        logger.info(f"Storage cleanup done — freed {freed_mb:.1f}MB")
        return result

    except Exception as e:
        logger.error(f"Storage cleanup failed: {e}")
        log_action("cleanup_storage", "failed", {"error": str(e)})
        return {"action": "cleanup_storage", "status": "failed", "error": str(e)}


def fix_restart_service(service_name: str = "echo-log", dry_run: bool = False) -> dict:
    """
    AUTO-FIX: Restart a crashed service.
    Windows: kills the process using the port, logs a recommendation.
    Linux:   uses systemctl restart.
    """
    before = get_system_metrics()

    if dry_run or DRY_RUN:
        return {
            "action":  "restart_service",
            "status":  "dry_run",
            "service": service_name,
            "message": f"DRY RUN — would restart service: {service_name}",
            "before":  before,
        }

    # ── Windows path ──────────────────────────────────────────────
    if IS_WINDOWS:
        # On Windows echo-log runs as a Python process, not a Windows service.
        # The safe action is to log the recommendation — killing the process
        # from within itself would take down Module 5 too.
        actions = [
            f"Service '{service_name}' is a Python process on Windows.",
            "Recommended: check Task Manager for high-CPU/memory Python processes.",
            "If a module crashed, the launcher.py will auto-restart it.",
        ]
        entry = {
            "action":  "restart_service",
            "status":  "recommendation",
            "service": service_name,
            "message": "Windows detected — restart handled by launcher.py auto-recovery",
            "actions": actions,
            "before":  before,
            "after":   get_system_metrics(),
        }
        log_action("restart_service", "recommendation", entry)
        logger.info(f"Windows restart recommendation logged for: {service_name}")
        return entry

    # ── Linux path ────────────────────────────────────────────────
    WHITELISTED_SERVICES = [
        "echo-log", "apache2", "nginx", "mysql",
        "postgresql", "redis", "mongodb",
    ]

    if service_name not in WHITELISTED_SERVICES:
        return {
            "action": "restart_service",
            "status": "rejected",
            "reason": f"Service '{service_name}' is not in the whitelist",
        }

    try:
        result = subprocess.run(
            ["systemctl", "restart", service_name],
            capture_output=True, text=True, timeout=30
        )
        status = "success" if result.returncode == 0 else "failed"
        entry = {
            "action":      "restart_service",
            "status":      status,
            "service":     service_name,
            "return_code": result.returncode,
            "stdout":      result.stdout[:200],
            "stderr":      result.stderr[:200],
            "before":      before,
            "after":       get_system_metrics(),
        }
        log_action("restart_service", status, entry)
        logger.info(f"Service restart {status}: {service_name}")
        return entry

    except subprocess.TimeoutExpired:
        log_action("restart_service", "timeout", {"service": service_name})
        return {"action": "restart_service", "status": "timeout", "service": service_name}
    except Exception as e:
        log_action("restart_service", "failed", {"error": str(e)})
        return {"action": "restart_service", "status": "failed", "error": str(e)}


def fix_restart_network_services(dry_run: bool = False) -> dict:
    """
    AUTO-FIX: Restart network-related services.
    Windows: logs recommendation (systemctl not available).
    Linux:   restarts zookeeper/kafka if running.
    """
    before = get_system_metrics()

    if dry_run or DRY_RUN:
        return {
            "action":  "restart_network_services",
            "status":  "dry_run",
            "message": "DRY RUN — would restart: zookeeper, kafka network services",
            "before":  before,
        }

    if IS_WINDOWS:
        entry = {
            "action":  "restart_network_services",
            "status":  "recommendation",
            "message": "Windows detected — systemctl not available",
            "actions": [
                "Check Zookeeper/Kafka in Task Manager if running locally.",
                "If using Docker: run 'docker restart <container_name>'",
                "If using WSL: open WSL terminal and run 'sudo systemctl restart zookeeper'",
            ],
            "before": before,
            "after":  get_system_metrics(),
        }
        log_action("restart_network_services", "recommendation", entry)
        return entry

    results = []
    for svc in ["zookeeper", "kafka"]:
        try:
            r = subprocess.run(
                ["systemctl", "is-active", svc],
                capture_output=True, text=True, timeout=5
            )
            if r.stdout.strip() == "active":
                subprocess.run(["systemctl", "restart", svc], timeout=30)
                results.append(f"Restarted: {svc}")
            else:
                results.append(f"Skipped (not running): {svc}")
        except Exception as e:
            results.append(f"Failed to restart {svc}: {e}")

    entry = {
        "action":  "restart_network_services",
        "status":  "success",
        "results": results,
        "before":  before,
        "after":   get_system_metrics(),
    }
    log_action("restart_network_services", "success", entry)
    return entry


def fix_restart_heavy_processes(dry_run: bool = False) -> dict:
    """
    AUTO-FIX: Identify and restart top memory-consuming processes
    Safe — only kills processes using >80% memory AND are in the safe-to-restart list
    """
    SAFE_TO_RESTART = ["python", "java", "node", "gunicorn", "uvicorn"]

    before = get_system_metrics()

    if dry_run or DRY_RUN:
        return {
            "action":  "restart_heavy_processes",
            "status":  "dry_run",
            "message": "DRY RUN — would identify and restart high-memory processes",
            "before":  before,
        }

    try:
        import psutil
        killed = []
        for proc in psutil.process_iter(["pid", "name", "memory_percent"]):
            try:
                info = proc.info
                mem  = info.get("memory_percent", 0)
                name = (info.get("name") or "").lower()
                if mem > 80 and any(s in name for s in SAFE_TO_RESTART):
                    proc.kill()
                    killed.append(f"{info['name']} (PID {info['pid']}, {mem:.1f}% mem)")
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        entry = {
            "action":  "restart_heavy_processes",
            "status":  "success",
            "killed":  killed,
            "before":  before,
            "after":   get_system_metrics(),
        }
        log_action("restart_heavy_processes", "success", entry)
        logger.info(f"Killed {len(killed)} heavy processes")
        return entry

    except ImportError:
        return {"action": "restart_heavy_processes", "status": "failed",
                "error": "psutil not installed"}
    except Exception as e:
        return {"action": "restart_heavy_processes", "status": "failed", "error": str(e)}


# ─────────────────────────────────────────────────────────────────────────────
# RESCALING ENGINE
# ─────────────────────────────────────────────────────────────────────────────

def rescale_disk(amount: str = "50%", dry_run: bool = False) -> dict:
    """
    RESCALE: Disk expansion recommendation
    In a real cloud environment this would call AWS/GCP/Azure API.
    Here it generates the exact commands to run.
    """
    before = get_system_metrics()

    commands = {
        "aws":   [
            f"# AWS — Resize EBS volume",
            f"aws ec2 modify-volume --volume-id <VOLUME_ID> --size <NEW_SIZE_GB>",
            f"# Then resize filesystem:",
            f"sudo growpart /dev/xvda 1",
            f"sudo resize2fs /dev/xvda1",
        ],
        "gcp":   [
            f"# GCP — Resize persistent disk",
            f"gcloud compute disks resize <DISK_NAME> --size=<NEW_SIZE>GB",
            f"# Then resize filesystem:",
            f"sudo resize2fs /dev/sda1",
        ],
        "linux": [
            f"# Linux — Add swap as emergency storage buffer",
            f"sudo fallocate -l 4G /swapfile",
            f"sudo chmod 600 /swapfile",
            f"sudo mkswap /swapfile",
            f"sudo swapon /swapfile",
        ],
    }

    result = {
        "action":        "rescale_disk",
        "status":        "dry_run" if (dry_run or DRY_RUN) else "recommendation_generated",
        "resource":      "disk",
        "scale_by":      amount,
        "before":        before,
        "commands":      commands,
        "message":       f"Disk rescaling by {amount} recommended. Run commands below.",
        "auto_executed": False,   # Disk resize requires manual approval in production
    }
    log_action("rescale_disk", result["status"], result)
    logger.info(f"Disk rescale recommendation generated: {amount}")
    return result


def rescale_memory(amount: str = "2x", dry_run: bool = False) -> dict:
    """
    RESCALE: Memory expansion
    Adds swap space immediately (can be done without reboot).
    For cloud: generates commands to upgrade instance type.
    """
    before = get_system_metrics()

    # Add swap immediately on Linux; on Windows generate instructions instead
    swap_actions = []
    if IS_WINDOWS:
        swap_actions.append(
            "Windows: Go to System Properties → Advanced → Performance Settings "
            "→ Virtual Memory → increase paging file size by 2048MB."
        )
    elif not (dry_run or DRY_RUN):
        try:
            swap_file = "/tmp/echo_log_swap"
            subprocess.run(["fallocate", "-l", "2G", swap_file], timeout=30)
            subprocess.run(["chmod", "600", swap_file], timeout=5)
            subprocess.run(["mkswap", swap_file], timeout=10)
            subprocess.run(["swapon", swap_file], timeout=10)
            swap_actions.append(f"Added 2GB swap at {swap_file}")
        except Exception as e:
            swap_actions.append(f"Could not add swap: {e}")

    cloud_commands = {
        "aws":   [
            "# AWS — Upgrade instance type (requires stop/start):",
            "aws ec2 stop-instances --instance-ids <INSTANCE_ID>",
            "aws ec2 modify-instance-attribute --instance-id <INSTANCE_ID> --instance-type '{\"Value\": \"m5.xlarge\"}'",
            "aws ec2 start-instances --instance-ids <INSTANCE_ID>",
        ],
        "gcp":   [
            "# GCP — Change machine type:",
            "gcloud compute instances stop <INSTANCE_NAME>",
            "gcloud compute instances set-machine-type <INSTANCE_NAME> --machine-type n2-standard-4",
            "gcloud compute instances start <INSTANCE_NAME>",
        ],
    }

    result = {
        "action":        "rescale_memory",
        "status":        "partial_success",
        "resource":      "memory",
        "scale_by":      amount,
        "before":        before,
        "after":         get_system_metrics(),
        "swap_added":    swap_actions,
        "cloud_commands": cloud_commands,
        "message":       "Swap added immediately. Full memory upgrade requires instance resize.",
        "auto_executed": len(swap_actions) > 0 and not (dry_run or DRY_RUN),
    }
    log_action("rescale_memory", result["status"], result)
    return result


def rescale_cpu(amount: str = "2x", dry_run: bool = False) -> dict:
    """
    RESCALE: CPU scaling recommendation
    Cannot add CPU without instance resize, so generates commands.
    """
    before = get_system_metrics()

    cloud_commands = {
        "aws":   [
            "# AWS — Upgrade to compute-optimized instance:",
            "aws ec2 stop-instances --instance-ids <INSTANCE_ID>",
            "aws ec2 modify-instance-attribute --instance-id <INSTANCE_ID> --instance-type '{\"Value\": \"c5.2xlarge\"}'",
            "aws ec2 start-instances --instance-ids <INSTANCE_ID>",
        ],
        "gcp":   [
            "# GCP — Upgrade to high-CPU machine type:",
            "gcloud compute instances stop <INSTANCE_NAME>",
            "gcloud compute instances set-machine-type <INSTANCE_NAME> --machine-type c2-standard-8",
            "gcloud compute instances start <INSTANCE_NAME>",
        ],
        "local": [
            "# Local — Reduce CPU-heavy processes:",
            "ps aux --sort=-%cpu | head -10    # Find top CPU consumers",
            "renice +10 <PID>                   # Lower priority of heavy processes",
            "cpulimit -p <PID> -l 50            # Limit process to 50% CPU",
        ],
    }

    result = {
        "action":        "rescale_cpu",
        "status":        "dry_run" if (dry_run or DRY_RUN) else "recommendation_generated",
        "resource":      "cpu",
        "scale_by":      amount,
        "before":        before,
        "cloud_commands": cloud_commands,
        "message":       f"CPU scaling by {amount} needed. See commands below.",
        "auto_executed": False,
    }
    log_action("rescale_cpu", result["status"], result)
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Script Dispatcher
# ─────────────────────────────────────────────────────────────────────────────

SCRIPT_MAP = {
    "cleanup_storage":         fix_cleanup_storage,
    "restart_service":         fix_restart_service,
    "restart_network_services": fix_restart_network_services,
    "restart_heavy_processes": fix_restart_heavy_processes,
}

RESCALE_MAP = {
    "disk":   rescale_disk,
    "memory": rescale_memory,
    "cpu":    rescale_cpu,
}


def execute_action(decision: dict, dry_run: bool = False) -> dict:
    """
    Executes the action decided by the decision engine.
    Routes to the correct script or rescale function.
    """
    action      = decision.get("action")
    fix_script  = decision.get("fix_script")
    rescale_type = decision.get("rescale_type")
    rescale_amount = decision.get("rescale_amount", "2x")

    from decision_engine import ACTION_AUTO_FIX, ACTION_RESCALE, ACTION_ESCALATE, ACTION_MONITOR

    if action == ACTION_AUTO_FIX and fix_script:
        fn = SCRIPT_MAP.get(fix_script)
        if fn:
            logger.info(f"Executing auto-fix: {fix_script}")
            return fn(dry_run=dry_run)
        return {"status": "error", "message": f"Unknown fix script: {fix_script}"}

    elif action == ACTION_RESCALE and rescale_type:
        fn = RESCALE_MAP.get(rescale_type)
        if fn:
            logger.info(f"Executing rescale: {rescale_type} by {rescale_amount}")
            return fn(amount=rescale_amount, dry_run=dry_run)
        return {"status": "error", "message": f"Unknown rescale type: {rescale_type}"}

    elif action == ACTION_ESCALATE:
        return {
            "status":  "escalated",
            "message": "Escalation triggered — human engineer must handle this",
            "reason":  decision.get("reason"),
            "urgency": decision.get("urgency"),
        }

    elif action == ACTION_MONITOR:
        return {
            "status":  "monitoring",
            "message": "Logged and monitoring — no automated action taken",
            "reason":  decision.get("reason"),
        }

    return {"status": "unknown", "message": f"Unknown action: {action}"}
