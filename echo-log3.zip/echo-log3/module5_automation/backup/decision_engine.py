# decision_engine.py
# Escalation Decision Engine
# Takes RCA report from Module 4 and decides:
#   AUTO-FIX    → system can fix it automatically
#   RESCALE     → server needs more resources (CPU/RAM/Disk)
#   ESCALATE    → too serious, needs human engineer
#   MONITOR     → watch it but no action yet
#
# Decision is based on:
#   - severity (CRITICAL / HIGH / MEDIUM / LOW)
#   - category (storage / memory / security / network / hardware / application)
#   - should_escalate flag from RCA
#   - causal chains detected
#   - anomaly count thresholds


# ─────────────────────────────────────────────────────────────────────────────
# Action Types
# ─────────────────────────────────────────────────────────────────────────────

ACTION_AUTO_FIX = "AUTO_FIX"       # System executes a fix script
ACTION_RESCALE  = "RESCALE"        # Add more CPU / RAM / Disk
ACTION_ESCALATE = "ESCALATE"       # Alert human engineer
ACTION_MONITOR  = "MONITOR"        # Log and watch, no action yet


# ─────────────────────────────────────────────────────────────────────────────
# Decision Rules
# Priority: ESCALATE > RESCALE > AUTO_FIX > MONITOR
# ─────────────────────────────────────────────────────────────────────────────

DECISION_MATRIX = [

    # ── ALWAYS ESCALATE — security breaches ──────────────────────────────────
    {
        "id":         "DEC-SEC-001",
        "conditions": {"category": "security", "severity": ["CRITICAL"]},
        "action":     ACTION_ESCALATE,
        "reason":     "Critical security incident requires immediate human response",
        "urgency":    "IMMEDIATE",
        "notify_team": "security",
    },
    {
        "id":         "DEC-SEC-002",
        "conditions": {"category": "security", "severity": ["HIGH"],
                       "should_escalate": True},
        "action":     ACTION_ESCALATE,
        "reason":     "High severity security event flagged for escalation",
        "urgency":    "URGENT",
        "notify_team": "security",
    },

    # ── ALWAYS ESCALATE — hardware failures ──────────────────────────────────
    {
        "id":         "DEC-HW-001",
        "conditions": {"category": "hardware", "severity": ["CRITICAL", "HIGH"]},
        "action":     ACTION_ESCALATE,
        "reason":     "Hardware failure cannot be resolved by software — needs physical intervention",
        "urgency":    "URGENT",
        "notify_team": "infrastructure",
    },

    # ── RESCALE — storage running out ─────────────────────────────────────────
    {
        "id":         "DEC-STOR-001",
        "conditions": {"category": "storage", "severity": ["CRITICAL"]},
        "action":     ACTION_RESCALE,
        "reason":     "Storage critically low — expand disk capacity",
        "urgency":    "IMMEDIATE",
        "rescale_type": "disk",
        "rescale_amount": "50%",          # Expand disk by 50%
        "notify_team": "infrastructure",
    },
    {
        "id":         "DEC-STOR-002",
        "conditions": {"category": "storage", "severity": ["HIGH"]},
        "action":     ACTION_AUTO_FIX,
        "reason":     "Storage high — auto-cleanup old logs and temp files",
        "urgency":    "HIGH",
        "fix_script": "cleanup_storage",
        "notify_team": "ops",
    },

    # ── RESCALE — memory exhaustion ───────────────────────────────────────────
    {
        "id":         "DEC-MEM-001",
        "conditions": {"category": "memory", "severity": ["CRITICAL"]},
        "action":     ACTION_RESCALE,
        "reason":     "Memory critically exhausted — scale up RAM or add swap",
        "urgency":    "IMMEDIATE",
        "rescale_type": "memory",
        "rescale_amount": "2x",           # Double the memory
        "notify_team": "infrastructure",
    },
    {
        "id":         "DEC-MEM-002",
        "conditions": {"category": "memory", "severity": ["HIGH"]},
        "action":     ACTION_AUTO_FIX,
        "reason":     "High memory usage — restart memory-heavy processes",
        "urgency":    "HIGH",
        "fix_script": "restart_heavy_processes",
        "notify_team": "ops",
    },

    # ── AUTO-FIX — network/connection issues ──────────────────────────────────
    {
        "id":         "DEC-NET-001",
        "conditions": {"category": "network", "severity": ["CRITICAL", "HIGH"],
                       "should_escalate": False},
        "action":     ACTION_AUTO_FIX,
        "reason":     "Network/connection failure — restart affected services",
        "urgency":    "HIGH",
        "fix_script": "restart_network_services",
        "notify_team": "ops",
    },
    {
        "id":         "DEC-NET-002",
        "conditions": {"category": "network", "severity": ["CRITICAL"],
                       "should_escalate": True},
        "action":     ACTION_ESCALATE,
        "reason":     "Critical network failure requiring manual intervention",
        "urgency":    "URGENT",
        "notify_team": "infrastructure",
    },

    # ── AUTO-FIX — application crashes ───────────────────────────────────────
    {
        "id":         "DEC-APP-001",
        "conditions": {"category": "application", "severity": ["CRITICAL", "HIGH"],
                       "should_escalate": False},
        "action":     ACTION_AUTO_FIX,
        "reason":     "Application failure — restart the affected service",
        "urgency":    "HIGH",
        "fix_script": "restart_service",
        "notify_team": "ops",
    },

    # ── RESCALE — performance under load ─────────────────────────────────────
    {
        "id":         "DEC-PERF-001",
        "conditions": {"category": "performance", "severity": ["CRITICAL", "HIGH"]},
        "action":     ACTION_RESCALE,
        "reason":     "Performance critical — scale up compute resources",
        "urgency":    "HIGH",
        "rescale_type": "cpu",
        "rescale_amount": "2x",
        "notify_team": "infrastructure",
    },
    {
        "id":         "DEC-PERF-002",
        "conditions": {"category": "performance", "severity": ["MEDIUM"]},
        "action":     ACTION_MONITOR,
        "reason":     "Performance degraded but not critical — monitor closely",
        "urgency":    "MEDIUM",
        "notify_team": "ops",
    },

    # ── MONITOR — low severity ────────────────────────────────────────────────
    {
        "id":         "DEC-GEN-001",
        "conditions": {"severity": ["LOW", "MEDIUM"], "should_escalate": False},
        "action":     ACTION_MONITOR,
        "reason":     "Low/medium severity anomaly — log and monitor",
        "urgency":    "LOW",
        "notify_team": "ops",
    },
]


def decide_action(rca_result: dict) -> dict:
    """
    Takes a single RCA result and returns the escalation decision.
    Evaluates decision matrix rules in priority order.
    """
    severity       = rca_result.get("severity", "MEDIUM")
    category       = rca_result.get("category", "general")
    should_escalate = rca_result.get("should_escalate", False)

    # Always escalate CRITICAL security or hardware
    for rule in DECISION_MATRIX:
        cond = rule["conditions"]

        # Check severity match
        if "severity" in cond and severity not in cond["severity"]:
            continue

        # Check category match
        if "category" in cond and cond["category"] != category:
            continue

        # Check escalate flag match
        if "should_escalate" in cond and cond["should_escalate"] != should_escalate:
            continue

        # This rule matches — return decision
        return {
            "decision_id":   rule["id"],
            "action":        rule["action"],
            "reason":        rule["reason"],
            "urgency":       rule.get("urgency", "MEDIUM"),
            "rescale_type":  rule.get("rescale_type"),
            "rescale_amount": rule.get("rescale_amount"),
            "fix_script":    rule.get("fix_script"),
            "notify_team":   rule.get("notify_team", "ops"),
        }

    # Default fallback
    return {
        "decision_id":  "DEC-DEFAULT",
        "action":       ACTION_MONITOR,
        "reason":       "No specific rule matched — defaulting to monitor",
        "urgency":      "LOW",
        "notify_team":  "ops",
    }


def decide_for_rca_report(rca_report: dict) -> dict:
    """
    Takes the full RCA report and decides overall escalation strategy.
    Returns:
      - per-entry decisions
      - global action (the highest priority action across all entries)
      - rescale recommendations
      - teams to notify
    """
    rca_results = rca_report.get("rca_results", [])
    chains      = rca_report.get("causal_chains", {})

    if not rca_results:
        return {
            "overall_action":     ACTION_MONITOR,
            "overall_urgency":    "NONE",
            "per_entry_decisions": [],
            "rescale_needed":     False,
            "rescale_details":    [],
            "teams_to_notify":    [],
            "escalation_summary": "System is clean — no action needed.",
        }

    # Per-entry decisions
    per_entry = []
    for r in rca_results:
        decision = decide_action(r)
        per_entry.append({
            "line_number":   r.get("line_number"),
            "severity":      r.get("severity"),
            "category":      r.get("category"),
            "root_cause":    r.get("root_cause", "")[:100],
            **decision
        })

    # Overall action — highest priority wins
    priority = {ACTION_ESCALATE: 4, ACTION_RESCALE: 3,
                ACTION_AUTO_FIX: 2, ACTION_MONITOR: 1}
    top = max(per_entry, key=lambda x: priority.get(x["action"], 0))
    overall_action  = top["action"]
    overall_urgency = top["urgency"]

    # Rescale details — all unique rescale recommendations
    rescale_details = []
    seen_rescale    = set()
    for d in per_entry:
        if d["action"] == ACTION_RESCALE and d.get("rescale_type"):
            key = d["rescale_type"]
            if key not in seen_rescale:
                seen_rescale.add(key)
                rescale_details.append({
                    "resource":       d["rescale_type"],
                    "scale_by":       d.get("rescale_amount", "2x"),
                    "reason":         d["reason"],
                    "urgency":        d["urgency"],
                })

    # Teams to notify (deduplicated)
    teams_to_notify = list(set(d.get("notify_team", "ops") for d in per_entry))

    # Causal chain boost — if active failure chain, escalate urgency
    active_chains = [c for c in chains.get("chains", [])
                     if "FAILURE OCCURRING" in c.get("status", "")]
    if active_chains and overall_action == ACTION_MONITOR:
        overall_action  = ACTION_AUTO_FIX
        overall_urgency = "HIGH"

    summary = _build_escalation_summary(
        overall_action, overall_urgency, per_entry, rescale_details, active_chains
    )

    return {
        "overall_action":      overall_action,
        "overall_urgency":     overall_urgency,
        "per_entry_decisions": per_entry,
        "rescale_needed":      len(rescale_details) > 0,
        "rescale_details":     rescale_details,
        "teams_to_notify":     teams_to_notify,
        "active_chains":       [c["chain_name"] for c in active_chains],
        "escalation_summary":  summary,

        # Counts per action type
        "action_counts": {
            ACTION_ESCALATE: sum(1 for d in per_entry if d["action"] == ACTION_ESCALATE),
            ACTION_RESCALE:  sum(1 for d in per_entry if d["action"] == ACTION_RESCALE),
            ACTION_AUTO_FIX: sum(1 for d in per_entry if d["action"] == ACTION_AUTO_FIX),
            ACTION_MONITOR:  sum(1 for d in per_entry if d["action"] == ACTION_MONITOR),
        }
    }


def _build_escalation_summary(action, urgency, decisions, rescale, chains) -> str:
    if action == ACTION_ESCALATE:
        return (f"🚨 IMMEDIATE ESCALATION REQUIRED — "
                f"{sum(1 for d in decisions if d['action'] == ACTION_ESCALATE)} "
                f"critical issues need human intervention.")
    if action == ACTION_RESCALE:
        resources = [r["resource"] for r in rescale]
        return (f"⚡ SERVER RESCALING NEEDED — "
                f"Scale up: {', '.join(resources)}. "
                f"System is resource-constrained.")
    if action == ACTION_AUTO_FIX:
        return (f"🔧 AUTO-FIX IN PROGRESS — "
                f"{sum(1 for d in decisions if d['action'] == ACTION_AUTO_FIX)} "
                f"issues being automatically resolved.")
    return "👁️ MONITORING — Anomalies detected but within manageable range."
