# routes.py — Module 4 Root Cause Analysis API endpoints

import requests
from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List
from loguru import logger
from rca_engine import run_rca, analyze_single

router = APIRouter()

MODULE3_URL = "http://localhost:8002/api/v3"


# ── Request Schemas ───────────────────────────────────────────────────────────

class AnomalyResult(BaseModel):
    line_number:      int
    raw_text:         str
    log_type:         Optional[str] = "Unknown"
    anomaly_score:    float
    is_anomaly:       bool
    severity:         str
    anomaly_reasons:  List[str] = []


class DetectionReport(BaseModel):
    total_entries:      int
    anomaly_count:      int
    results:            List[AnomalyResult]
    anomaly_type_analysis: Optional[dict] = {}
    high_error_rate_detected:     Optional[bool] = False
    unauthorized_access_detected: Optional[bool] = False
    unusual_methods_detected:     Optional[bool] = False
    ip_abuse_detected:            Optional[bool] = False
    response_time_spike_detected: Optional[bool] = False


class RCARequest(BaseModel):
    detection_report: DetectionReport


class LogEntry(BaseModel):
    line_number:    int
    timestamp:      Optional[str] = None
    level:          Optional[str] = None
    service:        Optional[str] = None
    message:        str = ""
    is_error:       bool = False
    is_warning:     bool = False
    raw_text:       str = ""
    log_type:       Optional[str] = None
    event_template: Optional[str] = None

class DirectAnalyzeRequest(BaseModel):
    structured_logs: List[LogEntry]


# ── Routes ────────────────────────────────────────────────────────────────────

@router.post("/analyze")
async def rca_analyze(request: RCARequest):
    """
    Run Root Cause Analysis on a detection report from Module 3.
    Input: Module 3 detection report
    Output: Root causes + fix suggestions + causal chains + escalation decision
    """
    logger.info(f"POST /analyze — {request.detection_report.anomaly_count} anomalies")
    try:
        report = request.detection_report.dict()
        rca    = run_rca(report)
        return {"status": "success", "rca_report": rca}
    except Exception as e:
        logger.error(f"RCA failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/analyze-from-logs")
async def rca_from_logs(request: DirectAnalyzeRequest):
    """
    Full pipeline: send raw structured logs → Module 3 detects → Module 4 analyses.
    This chains Module 3 + Module 4 together in one call.
    """
    logger.info(f"POST /analyze-from-logs — {len(request.structured_logs)} entries")

    # Step 1: Call Module 3 for anomaly detection
    try:
        m3_payload = {"structured_logs": [e.dict() for e in request.structured_logs]}
        m3_resp    = requests.post(
            f"{MODULE3_URL}/analyze",
            json=m3_payload,
            timeout=120
        )
        if m3_resp.status_code != 200:
            raise HTTPException(
                status_code=502,
                detail=f"Module 3 returned error: {m3_resp.text[:300]}"
            )
        detection_report = m3_resp.json().get("detection_report", {})
    except requests.exceptions.ConnectionError:
        raise HTTPException(
            status_code=503,
            detail="Cannot connect to Module 3 (port 8002). Make sure it is running."
        )

    # Step 2: Run RCA on detection report
    try:
        rca = run_rca(detection_report)
        return {
            "status":           "success",
            "detection_report": {k: v for k, v in detection_report.items()
                                 if k != "results"},
            "rca_report":       rca,
        }
    except Exception as e:
        logger.error(f"RCA failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/single-entry")
async def rca_single(entry: AnomalyResult):
    """Run RCA on a single anomaly result entry."""
    try:
        result = analyze_single(entry.dict())
        return {"status": "success", "rca": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/causal-chains")
async def get_causal_chains(request: RCARequest):
    """
    Get only causal chain analysis without full RCA.
    Useful for quick chain detection.
    """
    from pattern_correlator import correlate_anomalies, find_repeated_entities
    try:
        results = request.detection_report.dict().get("results", [])
        chains  = correlate_anomalies(results)
        entities = find_repeated_entities(results)
        return {
            "status":            "success",
            "causal_chains":     chains,
            "repeated_entities": entities,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/rules")
async def list_rules():
    """List all RCA rules in the knowledge base."""
    from rca_rules import RCA_RULES
    return {
        "total_rules": len(RCA_RULES),
        "rules": [
            {
                "id":           r["id"],
                "log_types":    r.get("log_types", []),
                "category":     r.get("category"),
                "severity":     r.get("severity"),
                "anomaly_type": r.get("anomaly_type"),
                "root_cause":   r.get("root_cause", "")[:80],
                "escalate":     r.get("escalate", False),
            }
            for r in RCA_RULES
        ]
    }


@router.get("/health")
async def health():
    from rca_rules import RCA_RULES
    m3_ok = False
    try:
        r = requests.get(f"{MODULE3_URL}/health", timeout=3)
        m3_ok = r.status_code == 200
    except Exception:
        pass
    return {
        "status":       "healthy",
        "port":         8003,
        "rules_loaded": len(RCA_RULES),
        "module3_connected": m3_ok,
    }
