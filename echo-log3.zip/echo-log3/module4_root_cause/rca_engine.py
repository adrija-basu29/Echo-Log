# rca_engine.py
# Master Root Cause Analysis Engine
# Takes anomaly results from Module 3 and produces:
#   - Root cause per anomaly
#   - Fix suggestion per anomaly
#   - Causal chain analysis
#   - Escalation decision
#   - Prevention recommendations

import re
from loguru import logger
from rca_rules import RCA_RULES, DEFAULT_RULE
from pattern_correlator import correlate_anomalies, find_repeated_entities


def get_full_text(result: dict) -> str:
    """Combine all text fields for matching."""
    parts = [
        (result.get("raw_text") or ""),
        " ".join(result.get("anomaly_reasons", [])),
        (result.get("log_type") or ""),
    ]
    return " ".join(parts).lower()


def match_rule(result: dict) -> dict:
    """
    Find the best matching RCA rule for a single anomaly result.
    Tries log-type specific rules first, then generic rules.
    Returns the matched rule or DEFAULT_RULE.
    """
    full_text = get_full_text(result)
    log_type  = (result.get("log_type") or "Unknown").strip()
    best_rule = None
    best_score = 0

    for rule in RCA_RULES:
        # Check if rule applies to this log type
        rule_types = rule.get("log_types", [])
        type_match = (not rule_types) or (log_type in rule_types)
        if not type_match:
            continue

        # Count how many triggers match
        triggers    = rule.get("triggers", [])
        match_count = 0
        for trigger in triggers:
            try:
                if re.search(trigger, full_text):
                    match_count += 1
            except re.error:
                if trigger in full_text:
                    match_count += 1

        # Score = match_count * (2 if log_type matched exactly, else 1)
        score = match_count * (2 if log_type in rule_types else 1)
        if score > best_score:
            best_score = score
            best_rule  = rule

    if best_rule and best_score >= 1:
        return best_rule

    # No match — try any rule ignoring log type
    for rule in RCA_RULES:
        triggers    = rule.get("triggers", [])
        match_count = sum(
            1 for t in triggers
            if (re.search(t, full_text)
                if not any(c in t for c in r'\.+*?[](){}|^$')
                else t in full_text)
        )
        if match_count > best_score:
            best_score = match_count
            best_rule  = rule

    return best_rule if best_rule and best_score >= 1 else DEFAULT_RULE


SEVERITY_RANK = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}


def _max_severity(sev_a: str, sev_b: str) -> str:
    """Return whichever severity is higher — rule always wins over ML score."""
    return sev_a if SEVERITY_RANK.get(sev_a, 0) >= SEVERITY_RANK.get(sev_b, 0) else sev_b


def analyze_single(result: dict) -> dict:
    """Produce RCA for one anomaly result."""
    rule = match_rule(result)

    # Use the HIGHER of: ML-detected severity OR rule-defined severity
    # Rationale: if SEC-001 says CRITICAL (SSH brute force), that trumps
    # whatever anomaly score Module 3 assigned (which may be MEDIUM)
    ml_severity   = result.get("severity", "MEDIUM")
    rule_severity = rule.get("severity", "MEDIUM")
    final_severity = _max_severity(rule_severity, ml_severity)

    # If rule says escalate, honour it regardless of ML severity
    should_escalate = rule.get("escalate", False)

    return {
        "line_number":   result.get("line_number"),
        "raw_text":      result.get("raw_text", "")[:200],
        "log_type":      result.get("log_type", "Unknown"),
        "anomaly_score": result.get("anomaly_score", 0),
        "severity":      final_severity,
        "ml_severity":   ml_severity,        # keep original for reference
        "rule_severity": rule_severity,
        "anomaly_reasons": result.get("anomaly_reasons", []),

        # RCA Output
        "rule_id":         rule.get("id", "GEN-001"),
        "root_cause":      rule.get("root_cause", DEFAULT_RULE["root_cause"]),
        "fix_steps":       rule.get("fix", DEFAULT_RULE["fix"]),
        "category":        rule.get("category", "general"),
        "should_escalate": should_escalate,
        "prevention":      rule.get("prevention", DEFAULT_RULE["prevention"]),
        "anomaly_type":    rule.get("anomaly_type", "general"),
    }


def run_rca(detection_report: dict) -> dict:
    """
    Master RCA function.
    Input:  full detection report from Module 3
    Output: complete RCA report with per-entry analysis + global insights
    """
    results   = detection_report.get("results", [])
    anomalies = [r for r in results if r.get("is_anomaly")]

    logger.info(f"Running RCA on {len(anomalies)} anomalies out of {len(results)} total entries...")

    if not anomalies:
        return {
            "status":           "clean",
            "message":          "No anomalies found — system appears healthy.",
            "total_analyzed":   len(results),
            "anomaly_count":    0,
            "rca_results":      [],
            "causal_chains":    {},
            "repeated_entities": [],
            "escalation_needed": False,
            "summary":          _build_summary([], {}, []),
        }

    # ── Step 1: RCA per anomaly ────────────────────────────────────
    rca_results = [analyze_single(r) for r in anomalies]

    # ── Step 2: Causal chain correlation ──────────────────────────
    causal_chains = correlate_anomalies(results)

    # ── Step 3: Repeated entities ──────────────────────────────────
    repeated_entities = find_repeated_entities(results)

    # ── Step 4: Escalation decision ───────────────────────────────
    critical_rcas   = [r for r in rca_results if r["severity"] == "CRITICAL"]
    escalation_rcas = [r for r in rca_results if r["should_escalate"]]
    escalation_needed = len(critical_rcas) > 0 or len(escalation_rcas) > 0

    # ── Step 5: Category breakdown ─────────────────────────────────
    category_counts = {}
    for r in rca_results:
        cat = r.get("category", "general")
        category_counts[cat] = category_counts.get(cat, 0) + 1

    # ── Step 6: Top fix recommendations ───────────────────────────
    # Deduplicate fix recommendations across all anomalies
    seen_rules  = set()
    top_fixes   = []
    for r in sorted(rca_results, key=lambda x: x["anomaly_score"], reverse=True):
        rule_id = r["rule_id"]
        if rule_id not in seen_rules:
            seen_rules.add(rule_id)
            top_fixes.append({
                "rule_id":    rule_id,
                "category":   r["category"],
                "root_cause": r["root_cause"],
                "fix_steps":  r["fix_steps"],
                "severity":   r["severity"],
                "prevention": r["prevention"],
                "affects_count": sum(1 for x in rca_results if x["rule_id"] == rule_id),
            })
        if len(top_fixes) >= 5:
            break

    summary = _build_summary(rca_results, causal_chains, repeated_entities)

    logger.info(
        f"RCA Complete | Analyzed={len(rca_results)} | "
        f"Escalate={escalation_needed} | "
        f"Chains={causal_chains.get('chains_detected', 0)}"
    )

    return {
        "status":             "anomalies_found",
        "total_analyzed":     len(results),
        "anomaly_count":      len(anomalies),
        "rca_results":        rca_results,

        # Global insights
        "causal_chains":      causal_chains,
        "repeated_entities":  repeated_entities,
        "category_breakdown": category_counts,
        "top_fixes":          top_fixes,

        # Escalation
        "escalation_needed":  escalation_needed,
        "critical_count":     len(critical_rcas),
        "escalation_count":   len(escalation_rcas),

        # Summary
        "summary": summary,

        # Pass-through stats from Module 3
        "anomaly_type_analysis": detection_report.get("anomaly_type_analysis", {}),
        "high_error_rate_detected":     detection_report.get("high_error_rate_detected", False),
        "unauthorized_access_detected": detection_report.get("unauthorized_access_detected", False),
        "unusual_methods_detected":     detection_report.get("unusual_methods_detected", False),
        "ip_abuse_detected":            detection_report.get("ip_abuse_detected", False),
        "response_time_spike_detected": detection_report.get("response_time_spike_detected", False),
    }


def _build_summary(rca_results: list, causal_chains: dict, entities: list) -> dict:
    """Build a human-readable summary of findings."""

    if not rca_results:
        return {
            "headline": "✅ System is healthy — no anomalies detected",
            "key_findings": [],
            "immediate_actions": [],
        }

    critical = [r for r in rca_results if r["severity"] == "CRITICAL"]
    high     = [r for r in rca_results if r["severity"] == "HIGH"]
    chains   = causal_chains.get("chains", [])

    headline = (
        f"🔴 {len(critical)} CRITICAL + {len(high)} HIGH anomalies detected"
        if critical else
        f"🟠 {len(high)} HIGH severity anomalies detected"
        if high else
        f"🟡 {len(rca_results)} anomalies detected"
    )

    key_findings = []

    if critical:
        top = critical[0]
        key_findings.append(f"Most critical: {top['root_cause']}")

    if chains:
        top_chain = chains[0]
        key_findings.append(
            f"Causal chain: {top_chain['chain_name']} detected "
            f"({top_chain['confidence']}% confidence)"
        )

    if entities:
        top_entity = entities[0]
        key_findings.append(
            f"Top problematic entity: '{top_entity['entity']}' "
            f"with {top_entity['anomaly_count']} anomalies"
        )

    immediate_actions = []
    seen = set()
    for r in sorted(rca_results, key=lambda x: x["anomaly_score"], reverse=True)[:3]:
        if r["fix_steps"] and r["fix_steps"][0] not in seen:
            seen.add(r["fix_steps"][0])
            immediate_actions.append({
                "for":    r["root_cause"][:80],
                "action": r["fix_steps"][0],
            })

    return {
        "headline":          headline,
        "key_findings":      key_findings,
        "immediate_actions": immediate_actions,
    }
