# pattern_correlator.py
# Correlates multiple anomalies to find causal chains and patterns
# This is the "chain learning" component — finds sequences that lead to failures

import re
from collections import defaultdict
from loguru import logger


# ─────────────────────────────────────────────────────────────────────────────
# Known Causal Chains
# Format: "warning pattern" → "leads to" → "final failure"
# The system learns these chains and alerts before the final failure
# ─────────────────────────────────────────────────────────────────────────────

CAUSAL_CHAINS = {

    "storage_shortage": {
        "name": "Storage Shortage Chain",
        "description": "Sequence of events that leads to disk/storage exhaustion",
        "warning_signs": [
            "disk.*full", "no.*space", "quota.*exceed",
            "storage.*full", "enospc", "disk.*usage",
            "du -sh", "cleanup", "large.*file",
        ],
        "final_failure": ["storage full", "disk full", "enospc", "no space left"],
        "prevention_action": "Auto-expand disk or trigger cleanup script",
        "time_window_minutes": 60,
    },

    "memory_exhaustion": {
        "name": "Memory Exhaustion Chain",
        "description": "Sequence leading to OOM kills",
        "warning_signs": [
            "memory.*pressure", "high.*memory", "low.*memory",
            "gc.*overhead", "gc.*pause", "swap.*high",
            "memory usage", "heap.*grow", "cache.*pressure",
        ],
        "final_failure": ["oom kill", "out of memory", "killed process",
                         "memory exhausted", "outofmemory"],
        "prevention_action": "Restart memory-heavy processes or add swap space",
        "time_window_minutes": 30,
    },

    "ssh_brute_force": {
        "name": "SSH Brute Force Escalation",
        "description": "Progressive SSH attack pattern",
        "warning_signs": [
            "failed password", "invalid user", "authentication fail",
            "repeated.*ssh", "ssh.*attempt",
        ],
        "final_failure": ["break-in", "possible break", "session opened for root",
                         "root login"],
        "prevention_action": "Block source IP immediately, enable fail2ban",
        "time_window_minutes": 10,
    },

    "cascade_node_failure": {
        "name": "Cascade Node Failure",
        "description": "Multiple node failures leading to cluster instability",
        "warning_signs": [
            "heartbeat.*miss", "node.*slow", "high.*load",
            "connection.*timeout", "gc.*overhead",
        ],
        "final_failure": ["node.*lost", "node.*fail", "cluster.*unstable",
                         "quorum.*lost", "tracker.*lost"],
        "prevention_action": "Redistribute load, restart struggling nodes",
        "time_window_minutes": 45,
    },

    "application_crash_loop": {
        "name": "Application Crash Loop",
        "description": "Application crashing repeatedly in a loop",
        "warning_signs": [
            "restarting", "respawn", "exit.*code", "crash.*count",
            "low.*memory", "gc.*pause",
        ],
        "final_failure": ["crash loop", "too many restarts", "failed to start",
                         "fatal exception", "anr", "force close"],
        "prevention_action": "Apply circuit breaker, restart with clean state",
        "time_window_minutes": 15,
    },

    "hadoop_job_failure": {
        "name": "Hadoop Job Failure Chain",
        "description": "Warning signs before a Hadoop job fails completely",
        "warning_signs": [
            "slow.*task", "gc.*overhead", "high.*memory",
            "task.*retry", "attempt.*1", "straggler",
        ],
        "final_failure": ["job.*failed", "job.*aborted", "all.*attempts.*failed",
                         "map.*failed", "reduce.*failed"],
        "prevention_action": "Kill and resubmit with higher memory allocation",
        "time_window_minutes": 120,
    },

    "windows_intrusion": {
        "name": "Windows Intrusion Chain",
        "description": "Sequence of events indicating Windows system compromise",
        "warning_signs": [
            "failed logon", "event 4625", "account locked",
            "unusual.*login", "off.*hours.*login",
        ],
        "final_failure": ["scheduled task created", "event 4698",
                         "user added to admin", "audit policy changed",
                         "event 4719"],
        "prevention_action": "Isolate machine, revoke compromised credentials",
        "time_window_minutes": 60,
    },
}


def find_pattern_in_text(text: str, patterns: list) -> bool:
    """Check if any pattern matches the text."""
    text_lower = text.lower()
    for pat in patterns:
        try:
            if re.search(pat, text_lower):
                return True
        except re.error:
            if pat in text_lower:
                return True
    return False


def get_combined_text(result: dict) -> str:
    """Get all searchable text from a result entry."""
    parts = [
        (result.get("raw_text") or ""),
        " ".join(result.get("anomaly_reasons", [])),
        (result.get("log_type") or ""),
    ]
    return " ".join(parts).lower()


def correlate_anomalies(results: list) -> dict:
    """
    Finds causal chains across multiple anomaly results.
    Returns detected chains with confidence scores.
    """
    logger.info(f"Correlating {len(results)} results for causal chains...")

    anomalies = [r for r in results if r.get("is_anomaly")]
    detected_chains = []

    for chain_id, chain in CAUSAL_CHAINS.items():
        warning_hits = 0
        failure_hits = 0
        warning_examples = []
        failure_examples = []

        for r in anomalies:
            text = get_combined_text(r)

            if find_pattern_in_text(text, chain["warning_signs"]):
                warning_hits += 1
                if len(warning_examples) < 2:
                    warning_examples.append(r.get("raw_text", "")[:100])

            if find_pattern_in_text(text, chain["final_failure"]):
                failure_hits += 1
                if len(failure_examples) < 2:
                    failure_examples.append(r.get("raw_text", "")[:100])

        # A chain is "detected" if we see warning signs OR failure
        if warning_hits >= 2 or failure_hits >= 1:
            confidence = min(100, int(
                (warning_hits * 20) + (failure_hits * 40)
            ))
            detected_chains.append({
                "chain_id":          chain_id,
                "chain_name":        chain["name"],
                "description":       chain["description"],
                "confidence":        confidence,
                "warning_count":     warning_hits,
                "failure_count":     failure_hits,
                "prevention_action": chain["prevention_action"],
                "warning_examples":  warning_examples,
                "failure_examples":  failure_examples,
                "status": (
                    "🔴 FAILURE OCCURRING" if failure_hits > 0
                    else "🟡 WARNING — FAILURE RISK"
                ),
            })

    # Sort by confidence (highest first)
    detected_chains.sort(key=lambda x: x["confidence"], reverse=True)

    logger.info(f"Found {len(detected_chains)} causal chains")
    return {
        "chains_detected":     len(detected_chains),
        "chains":              detected_chains,
        "total_anomalies":     len(anomalies),
        "correlation_summary": _build_summary(detected_chains),
    }


def _build_summary(chains: list) -> str:
    if not chains:
        return "No causal chains detected. Anomalies appear isolated."
    top = chains[0]
    if top["failure_count"] > 0:
        return (f"ACTIVE: '{top['chain_name']}' is occurring now. "
                f"Immediate action needed: {top['prevention_action']}")
    return (f"WARNING: Early signs of '{top['chain_name']}' detected. "
            f"Recommended action: {top['prevention_action']}")


def find_repeated_entities(results: list) -> list:
    """
    Finds entities (IPs, apps, jobs, nodes) that appear repeatedly in anomalies.
    This helps identify the single most problematic source.
    """
    entity_counts = defaultdict(lambda: {
        "count": 0, "anomaly_count": 0,
        "max_score": 0.0, "examples": [], "log_types": set()
    })

    for r in results:
        raw     = (r.get("raw_text") or "").strip()
        lt      = (r.get("log_type") or "Unknown")
        score   = float(r.get("anomaly_score", 0))
        is_anom = r.get("is_anomaly", False)
        entity  = None

        # IP address
        m = re.search(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', raw)
        if m:
            entity = m.group(1)

        # Android app
        if not entity and lt == "Android":
            m = re.search(r'([a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]+)+)', raw.lower())
            if m:
                entity = m.group(1)

        # Hadoop/Spark job
        if not entity and lt in ("Hadoop", "Spark", "HDFS"):
            m = re.search(r'(job_\d+_\d+|task_\d+_\d+_\w+)', raw)
            if m:
                entity = m.group(1)

        # Windows EventID
        if not entity and lt == "Windows":
            m = re.search(r'EventID[:\s]+(\d+)', raw, re.IGNORECASE)
            if m:
                entity = f"EventID_{m.group(1)}"

        # BGL/HPC Node
        if not entity and lt in ("BGL", "HPC", "Thunderbird"):
            m = re.search(r'(R\d{2}-M\d-N\d+|\bnode\d+\b)', raw, re.IGNORECASE)
            if m:
                entity = m.group(1)

        if entity:
            d = entity_counts[entity]
            d["count"] += 1
            d["log_types"].add(lt)
            d["max_score"] = max(d["max_score"], score)
            if is_anom:
                d["anomaly_count"] += 1
            if is_anom and len(d["examples"]) < 2:
                d["examples"].append(raw[:100])

    # Convert to list and filter meaningful ones
    result_list = []
    for entity, data in entity_counts.items():
        if data["anomaly_count"] >= 2:
            result_list.append({
                "entity":        entity,
                "total_count":   data["count"],
                "anomaly_count": data["anomaly_count"],
                "max_score":     round(data["max_score"], 2),
                "log_types":     list(data["log_types"]),
                "examples":      data["examples"],
            })

    return sorted(result_list, key=lambda x: x["anomaly_count"], reverse=True)[:10]
