# rca_rules.py
# Rule Matching Engine — Root Cause Analysis
# Maps anomaly patterns → root cause → fix suggestion → escalation level
# Covers ALL 16 log types × ALL 5 anomaly types

# ─────────────────────────────────────────────────────────────────────────────
# Rule Structure:
# {
#   "id":          unique rule ID
#   "log_types":   which log types this rule applies to ([] = all types)
#   "triggers":    keywords that must appear in anomaly reasons OR raw_text
#   "anomaly_type": which of the 5 anomaly types this belongs to
#   "root_cause":  human-readable root cause explanation
#   "fix":         step-by-step fix suggestion
#   "severity":    CRITICAL / HIGH / MEDIUM / LOW
#   "category":    storage / memory / security / network / performance /
#                  hardware / application / configuration
#   "escalate":    True = needs human, False = can auto-fix
#   "prevention":  what to monitor to prevent recurrence
# }
# ─────────────────────────────────────────────────────────────────────────────

RCA_RULES = [

    # ══════════════════════════════════════════════════════════════
    # STORAGE / DISK ISSUES
    # ══════════════════════════════════════════════════════════════

    {
        "id": "STOR-001",
        "log_types": ["HDFS", "Linux", "Mac", "Android", "Hadoop"],
        "triggers": ["disk full", "no space", "disk space exhausted",
                     "quota exceeded", "storage full", "enospc"],
        "anomaly_type": "high_error_rate",
        "root_cause": "Disk/storage space is fully exhausted. No more data can be written.",
        "fix": [
            "1. Immediately identify largest files: `du -sh /* | sort -rh | head -20`",
            "2. Clear log files older than 7 days: `find /var/log -mtime +7 -delete`",
            "3. Clear temp files: `rm -rf /tmp/* /var/tmp/*`",
            "4. Check and remove unused Docker images: `docker system prune -a`",
            "5. If HDFS: run `hdfs dfs -expunge` to empty trash",
            "6. Long term: expand disk or add storage node",
        ],
        "severity": "CRITICAL",
        "category": "storage",
        "escalate": False,
        "prevention": "Monitor disk usage % — alert at 75%, auto-expand at 85%",
    },

    {
        "id": "STOR-002",
        "log_types": ["HDFS"],
        "triggers": ["block corruption", "corrupt", "checksum error",
                     "crc error", "block missing", "replication failure"],
        "anomaly_type": "unusual_operations",
        "root_cause": "HDFS block corruption detected. Data integrity is compromised.",
        "fix": [
            "1. Run HDFS fsck: `hdfs fsck / -list-corruptfileblocks`",
            "2. Delete corrupt blocks: `hdfs fsck / -delete`",
            "3. Restore from backup if critical data is affected",
            "4. Check DataNode disk health: `hdfs dfsadmin -report`",
            "5. Increase replication factor for critical data: `hdfs dfs -setrep 3 /path`",
        ],
        "severity": "CRITICAL",
        "category": "storage",
        "escalate": True,
        "prevention": "Enable HDFS block scanner, maintain replication factor ≥ 3",
    },

    # ══════════════════════════════════════════════════════════════
    # MEMORY ISSUES
    # ══════════════════════════════════════════════════════════════

    {
        "id": "MEM-001",
        "log_types": ["Linux", "Android", "Hadoop", "Spark", "HDFS"],
        "triggers": ["out of memory", "outofmemory", "oom killer",
                     "oom kill", "killed process", "memory pressure"],
        "anomaly_type": "high_error_rate",
        "root_cause": "System ran out of RAM. The OOM killer terminated processes to recover memory.",
        "fix": [
            "1. Check what was killed: `dmesg | grep -i 'killed process'`",
            "2. Check current memory: `free -h` and `top`",
            "3. Identify memory hogs: `ps aux --sort=-%mem | head -10`",
            "4. If Hadoop/Spark: increase heap size in config",
            "   Hadoop: set `mapreduce.map.memory.mb=4096` in mapred-site.xml",
            "   Spark: set `spark.executor.memory=4g`",
            "5. Add swap space as emergency buffer: `swapon -s`",
            "6. Long term: add more RAM or scale horizontally",
        ],
        "severity": "CRITICAL",
        "category": "memory",
        "escalate": False,
        "prevention": "Monitor memory usage — alert at 80%, add swap before reaching 90%",
    },

    {
        "id": "MEM-002",
        "log_types": ["Spark", "Hadoop", "HDFS"],
        "triggers": ["gc overhead", "gc pause", "garbage collection",
                     "heap space", "jvm out of memory"],
        "anomaly_type": "performance_issues",
        "root_cause": "JVM Garbage Collection is consuming excessive CPU time. Heap space is insufficient.",
        "fix": [
            "1. Increase JVM heap: set `-Xmx8g -Xms4g` in JVM options",
            "2. Switch to G1GC garbage collector: add `-XX:+UseG1GC`",
            "3. For Spark: tune `spark.memory.fraction=0.8`",
            "4. Reduce data partition size to lower per-executor memory",
            "5. Enable off-heap memory: `spark.memory.offHeap.enabled=true`",
        ],
        "severity": "HIGH",
        "category": "memory",
        "escalate": False,
        "prevention": "Set GC logging, alert when GC time exceeds 10% of total CPU time",
    },

    # ══════════════════════════════════════════════════════════════
    # SECURITY ISSUES
    # ══════════════════════════════════════════════════════════════

    {
        "id": "SEC-001",
        "log_types": ["OpenSSH"],
        "triggers": ["failed password", "brute force", "ssh brute",
                     "too many authentication", "invalid user", "illegal user"],
        "anomaly_type": "unauthorized_access",
        "root_cause": "SSH brute force attack detected. An attacker is trying many username/password combinations.",
        "fix": [
            "1. Block the attacking IP immediately:",
            "   `iptables -A INPUT -s <ATTACKER_IP> -j DROP`",
            "2. Install and configure fail2ban:",
            "   `apt install fail2ban`",
            "   Set maxretry=3, bantime=3600 in /etc/fail2ban/jail.conf",
            "3. Disable SSH password auth — use keys only:",
            "   Set `PasswordAuthentication no` in /etc/ssh/sshd_config",
            "4. Change SSH port from 22 to a non-standard port",
            "5. Enable two-factor authentication for SSH",
        ],
        "severity": "CRITICAL",
        "category": "security",
        "escalate": True,
        "prevention": "Deploy fail2ban, disable password auth, use SSH keys only",
    },

    {
        "id": "SEC-002",
        "log_types": ["OpenSSH"],
        "triggers": ["possible break-in", "break-in attempt",
                     "reverse mapping failed", "address not associated"],
        "anomaly_type": "unauthorized_access",
        "root_cause": "Suspicious SSH activity: possible break-in attempt or DNS spoofing detected.",
        "fix": [
            "1. Immediately check active SSH sessions: `who` and `w`",
            "2. Check recently logged-in users: `last | head -20`",
            "3. Review auth logs: `tail -100 /var/log/auth.log`",
            "4. Block suspicious IP: `iptables -A INPUT -s <IP> -j DROP`",
            "5. Verify DNS integrity for your server's hostname",
            "6. Check for unauthorized cron jobs: `crontab -l`",
        ],
        "severity": "CRITICAL",
        "category": "security",
        "escalate": True,
        "prevention": "Enable SIEM alerting, use intrusion detection system (IDS)",
    },

    {
        "id": "SEC-003",
        "log_types": ["Windows"],
        "triggers": ["failed logon", "event 4625", "account locked",
                     "failed windows login", "multiple failed"],
        "anomaly_type": "unauthorized_access",
        "root_cause": "Windows failed logon attempts detected (EventID 4625). Possible brute force or credential stuffing.",
        "fix": [
            "1. Check which account is being targeted in Event Viewer",
            "2. Identify source IP from EventID 4625 details",
            "3. Block the source IP at firewall level",
            "4. Enable Windows Account Lockout Policy:",
            "   Lockout threshold: 5 attempts",
            "   Lockout duration: 30 minutes",
            "5. Enable MFA for all privileged accounts",
            "6. Check if any account was successfully compromised",
        ],
        "severity": "CRITICAL",
        "category": "security",
        "escalate": True,
        "prevention": "Enable Account Lockout Policy, deploy Windows Defender ATP",
    },

    {
        "id": "SEC-004",
        "log_types": ["Windows"],
        "triggers": ["scheduled task created", "event 4698",
                     "audit policy changed", "event 4719",
                     "user account created", "event 4720",
                     "member added group", "event 4732"],
        "anomaly_type": "unusual_operations",
        "root_cause": "Suspicious Windows system change detected — possible attacker establishing persistence.",
        "fix": [
            "1. Immediately review the scheduled task or policy change",
            "2. Check which user/process made the change",
            "3. If unauthorized: delete the scheduled task immediately",
            "4. Review all admin group memberships",
            "5. Run Windows Defender full scan",
            "6. Check for lateral movement: review other EventIDs 4624, 4648",
            "7. Isolate the machine from network if compromise confirmed",
        ],
        "severity": "CRITICAL",
        "category": "security",
        "escalate": True,
        "prevention": "Enable advanced audit logging, use SIEM to alert on EventID 4698/4719/4720",
    },

    {
        "id": "SEC-005",
        "log_types": ["Apache", "OpenStack", "Proxifier"],
        "triggers": ["http 403", "forbidden", "access denied",
                     "unauthorized", "permission denied"],
        "anomaly_type": "unauthorized_access",
        "root_cause": "Repeated unauthorized access attempts to restricted resources.",
        "fix": [
            "1. Identify the source IP making unauthorized requests",
            "2. Check if this is a misconfiguration or actual attack",
            "3. If attack: block IP at firewall or WAF level",
            "4. Review and tighten access control rules",
            "5. Enable rate limiting for the endpoint",
            "6. Check if any successful access occurred before blocking",
        ],
        "severity": "HIGH",
        "category": "security",
        "escalate": False,
        "prevention": "Deploy WAF, implement rate limiting, review ACL rules regularly",
    },

    {
        "id": "SEC-006",
        "log_types": ["Android"],
        "triggers": ["permission denied", "securityexception",
                     "not allowed", "uid not allowed",
                     "permission not granted"],
        "anomaly_type": "unauthorized_access",
        "root_cause": "Android app attempting to access resources without proper permissions.",
        "fix": [
            "1. Identify which app is making unauthorized permission requests",
            "2. Review app's manifest for declared permissions",
            "3. If a system app: check for malware or compromise",
            "4. If user app: revoke permissions in Android Settings",
            "5. Check if device is rooted — increases attack surface",
            "6. Run a security scan on the device",
        ],
        "severity": "HIGH",
        "category": "security",
        "escalate": False,
        "prevention": "Implement runtime permission checks, use Android security scanning",
    },

    # ══════════════════════════════════════════════════════════════
    # NETWORK ISSUES
    # ══════════════════════════════════════════════════════════════

    {
        "id": "NET-001",
        "log_types": ["Zookeeper", "Hadoop", "HDFS", "Spark"],
        "triggers": ["connection loss", "connectionloss", "connection refused",
                     "zookeeper session", "session expired", "session timeout"],
        "anomaly_type": "performance_issues",
        "root_cause": "Zookeeper session lost or timed out. Distributed services depend on Zookeeper for coordination.",
        "fix": [
            "1. Check Zookeeper ensemble health: `echo ruok | nc localhost 2181`",
            "2. Check quorum: ensure at least (n/2)+1 nodes are up",
            "3. Increase session timeout in config:",
            "   `zookeeper.session.timeout.ms=30000`",
            "4. Check network latency between Zookeeper nodes",
            "5. Restart Zookeeper if session storm is occurring",
            "6. Ensure Zookeeper has dedicated resources (not shared CPU/IO)",
        ],
        "severity": "HIGH",
        "category": "network",
        "escalate": False,
        "prevention": "Monitor Zookeeper latency, use dedicated nodes, set up Zookeeper monitoring",
    },

    {
        "id": "NET-002",
        "log_types": ["Zookeeper"],
        "triggers": ["leader election", "quorum lost",
                     "not enough participants", "new leader"],
        "anomaly_type": "unusual_operations",
        "root_cause": "Zookeeper leader election triggered — quorum was lost or a node failed.",
        "fix": [
            "1. Check which Zookeeper node failed: `echo stat | nc <node> 2181`",
            "2. Identify if network partition caused the quorum loss",
            "3. Restart failed Zookeeper nodes",
            "4. After restart, verify leader: `echo stat | nc <leader> 2181`",
            "5. Check clients reconnected after new leader elected",
            "6. Review Zookeeper logs for the failing node",
        ],
        "severity": "HIGH",
        "category": "network",
        "escalate": True,
        "prevention": "Use odd number of Zookeeper nodes (3, 5, 7), monitor quorum health",
    },

    {
        "id": "NET-003",
        "log_types": ["Hadoop", "Spark"],
        "triggers": ["tracker lost", "tasktracker lost", "node lost",
                     "heartbeat missed", "heartbeat miss"],
        "anomaly_type": "high_error_rate",
        "root_cause": "A TaskTracker/worker node lost contact with the master. Node may be down or network interrupted.",
        "fix": [
            "1. Check node status: `hadoop dfsadmin -report`",
            "2. SSH to the failed node and check its health",
            "3. Check network connectivity: `ping <failed_node>`",
            "4. Restart the TaskTracker/NodeManager on the failed node:",
            "   `hadoop-daemon.sh start tasktracker`",
            "5. If node is permanently down: decommission it",
            "6. Increase heartbeat timeout if network is slow:",
            "   `mapreduce.tasktracker.expiry.interval=600000`",
        ],
        "severity": "HIGH",
        "category": "network",
        "escalate": False,
        "prevention": "Monitor node heartbeats, set up automatic node health monitoring",
    },

    {
        "id": "NET-004",
        "log_types": ["Thunderbird", "HPC", "BGL"],
        "triggers": ["network partition", "rpc error", "rpc fail",
                     "mpi error", "mpi abort"],
        "anomaly_type": "high_error_rate",
        "root_cause": "High-Performance Computing network failure — MPI communication or network partition.",
        "fix": [
            "1. Check interconnect health (InfiniBand/Ethernet)",
            "2. Run network diagnostics: check switch logs",
            "3. Identify which nodes are partitioned",
            "4. Restart MPI daemons on affected nodes",
            "5. If hardware failure: replace failed network hardware",
            "6. Requeue failed jobs after network recovery",
        ],
        "severity": "CRITICAL",
        "category": "network",
        "escalate": True,
        "prevention": "Monitor interconnect health, use redundant network paths",
    },

    # ══════════════════════════════════════════════════════════════
    # HARDWARE ISSUES
    # ══════════════════════════════════════════════════════════════

    {
        "id": "HW-001",
        "log_types": ["BGL", "Thunderbird", "HPC", "Linux"],
        "triggers": ["hardware error", "hardware failure", "machine check",
                     "mce", "ecc error", "memory error", "cpu error"],
        "anomaly_type": "unusual_operations",
        "root_cause": "Physical hardware failure detected — CPU or memory hardware error.",
        "fix": [
            "1. Check hardware error details: `mcelog` or `dmesg | grep -i mce`",
            "2. Identify affected memory DIMMs or CPU cores",
            "3. Run memtest86 to confirm memory failure",
            "4. Take the node offline immediately to prevent data corruption",
            "5. Replace faulty hardware (RAM/CPU)",
            "6. After replacement: run diagnostics before returning to service",
        ],
        "severity": "CRITICAL",
        "category": "hardware",
        "escalate": True,
        "prevention": "Enable ECC memory, run regular hardware diagnostics, use IPMI monitoring",
    },

    {
        "id": "HW-002",
        "log_types": ["Linux", "Mac", "BGL"],
        "triggers": ["kernel panic", "kernel panic", "system crash",
                     "oops", "bug:", "call trace"],
        "anomaly_type": "high_error_rate",
        "root_cause": "Kernel panic or kernel bug — the OS encountered an unrecoverable error and crashed.",
        "fix": [
            "1. Check kernel logs after reboot: `dmesg | tail -100`",
            "2. Look at crash dump if available: `/var/crash/`",
            "3. Identify the kernel module that caused the panic",
            "4. Update the kernel: `apt update && apt upgrade`",
            "5. If hardware related: check for faulty RAM or disk",
            "6. If driver related: update or downgrade the problematic driver",
            "7. Enable kdump for future crashes: `systemctl enable kdump`",
        ],
        "severity": "CRITICAL",
        "category": "hardware",
        "escalate": True,
        "prevention": "Keep kernel updated, use ECC memory, enable crash dump collection",
    },

    # ══════════════════════════════════════════════════════════════
    # APPLICATION ISSUES
    # ══════════════════════════════════════════════════════════════

    {
        "id": "APP-001",
        "log_types": ["Android"],
        "triggers": ["anr", "app not responding", "not responding",
                     "application not responding"],
        "anomaly_type": "performance_issues",
        "root_cause": "Android App Not Responding (ANR) — main thread blocked for >5 seconds.",
        "fix": [
            "1. Identify the blocked operation in ANR trace",
            "2. Move heavy operations off the main thread:",
            "   Use AsyncTask, Coroutines, or WorkManager",
            "3. Check for deadlocks between threads",
            "4. Reduce main thread I/O operations",
            "5. Optimize database queries — use Room with background threads",
            "6. Profile the app with Android Profiler",
        ],
        "severity": "HIGH",
        "category": "application",
        "escalate": False,
        "prevention": "Use StrictMode during development, profile main thread operations",
    },

    {
        "id": "APP-002",
        "log_types": ["Android"],
        "triggers": ["fatal exception", "force closed", "force close",
                     "stopped unexpectedly", "nullpointerexception",
                     "stackoverflowerror"],
        "anomaly_type": "high_error_rate",
        "root_cause": "Android application crashed with an unhandled exception.",
        "fix": [
            "1. Get the full crash stack trace from logs",
            "2. Identify the exact exception type and line number",
            "3. Fix the root exception (null check, bounds check, etc.)",
            "4. Add global exception handler to catch future crashes",
            "5. Use Firebase Crashlytics for production crash tracking",
            "6. Add proper null checks and input validation",
        ],
        "severity": "HIGH",
        "category": "application",
        "escalate": False,
        "prevention": "Use crash reporting tools, add comprehensive error handling, test edge cases",
    },

    {
        "id": "APP-003",
        "log_types": ["Spark"],
        "triggers": ["executor lost", "executorlost", "stage failed",
                     "job aborted", "fetch failed", "shuffle fail"],
        "anomaly_type": "high_error_rate",
        "root_cause": "Spark executor crashed or lost. Job/stage failed as a result.",
        "fix": [
            "1. Check executor logs for the actual failure cause",
            "2. Increase executor memory: `spark.executor.memory=8g`",
            "3. Increase driver memory: `spark.driver.memory=4g`",
            "4. Tune shuffle: `spark.sql.shuffle.partitions=400`",
            "5. Enable speculation for slow tasks:",
            "   `spark.speculation=true`",
            "6. Check if node hosting the executor failed",
            "7. Reduce data skew — repartition before heavy operations",
        ],
        "severity": "HIGH",
        "category": "application",
        "escalate": False,
        "prevention": "Monitor executor memory, enable Spark History Server, set up Ganglia",
    },

    {
        "id": "APP-004",
        "log_types": ["Hadoop"],
        "triggers": ["job failed", "job failure", "task failed",
                     "map failed", "reduce failed", "attempt failed"],
        "anomaly_type": "high_error_rate",
        "root_cause": "Hadoop MapReduce job or task failed. Could be OOM, timeout, or data issue.",
        "fix": [
            "1. Check job logs: `yarn logs -applicationId <app_id>`",
            "2. Identify if it's map or reduce task that's failing",
            "3. Check for OOM: increase task heap",
            "   `mapreduce.map.java.opts=-Xmx2048m`",
            "4. Check input data for corrupt records",
            "5. Increase number of retries:",
            "   `mapreduce.map.maxattempts=4`",
            "6. Review input splits — reduce split size if tasks are too heavy",
        ],
        "severity": "HIGH",
        "category": "application",
        "escalate": False,
        "prevention": "Set up YARN resource monitoring, use Hadoop job history server",
    },

    {
        "id": "APP-005",
        "log_types": ["Apache"],
        "triggers": ["segfault", "child killed", "worker killed",
                     "apache child killed", "cannot bind"],
        "anomaly_type": "high_error_rate",
        "root_cause": "Apache web server worker process crashed (segfault or killed by OS).",
        "fix": [
            "1. Check Apache error log: `tail -100 /var/log/apache2/error.log`",
            "2. Check which module caused the segfault",
            "3. Update Apache and all modules: `apt update apache2`",
            "4. If OOM caused the kill: increase server RAM or reduce MaxWorkers",
            "5. If 'cannot bind': check if port is already in use",
            "   `netstat -tlnp | grep :80`",
            "6. Check Apache config syntax: `apachectl configtest`",
            "7. Restart Apache: `systemctl restart apache2`",
        ],
        "severity": "HIGH",
        "category": "application",
        "escalate": False,
        "prevention": "Set up Apache monitoring, use mpm_event with proper worker limits",
    },

    # ══════════════════════════════════════════════════════════════
    # PERFORMANCE ISSUES
    # ══════════════════════════════════════════════════════════════

    {
        "id": "PERF-001",
        "log_types": ["Apache", "OpenStack"],
        "triggers": ["timeout", "timed out", "slow response",
                     "response time", "high response time"],
        "anomaly_type": "performance_issues",
        "root_cause": "HTTP response times are abnormally high. Server may be overloaded or a backend is slow.",
        "fix": [
            "1. Check server load: `top` and `uptime`",
            "2. Identify slow endpoints from access logs",
            "3. Check database query times — slow queries cause timeouts",
            "4. Enable Apache caching for static content",
            "5. Add a CDN for static assets",
            "6. Scale horizontally: add more web server instances",
            "7. Tune Apache workers: MaxRequestWorkers in httpd.conf",
            "8. Check backend services (DB, cache, APIs) for bottlenecks",
        ],
        "severity": "HIGH",
        "category": "performance",
        "escalate": False,
        "prevention": "Set response time SLAs, monitor P95/P99 latency, auto-scale on high load",
    },

    {
        "id": "PERF-002",
        "log_types": ["Linux", "BGL", "HPC", "Thunderbird"],
        "triggers": ["soft lockup", "cpu lockup", "hung task",
                     "rcu stall", "hard lockup"],
        "anomaly_type": "unusual_operations",
        "root_cause": "CPU lockup or kernel hung task. A process is monopolizing CPU or kernel is stuck.",
        "fix": [
            "1. Check which process caused the lockup: `dmesg | grep -i lockup`",
            "2. Kill the hung process: `kill -9 <PID>`",
            "3. Check for I/O bottleneck: `iostat -x 1 5`",
            "4. Check for NFS or network filesystem hangs",
            "5. Update kernel to latest stable version",
            "6. If recurring: check for hardware issues (CPU/memory)",
            "7. Increase watchdog threshold if workload is legitimate",
        ],
        "severity": "CRITICAL",
        "category": "performance",
        "escalate": True,
        "prevention": "Monitor CPU utilization, set process priority limits, use cgroups",
    },

    {
        "id": "PERF-003",
        "log_types": ["HealthApp"],
        "triggers": ["threshold exceeded", "health threshold",
                     "critical alert", "sensor fail", "data missing"],
        "anomaly_type": "high_error_rate",
        "root_cause": "Health monitoring threshold exceeded or sensor malfunction.",
        "fix": [
            "1. Identify which health metric exceeded the threshold",
            "2. Check sensor hardware for physical damage or calibration issues",
            "3. Verify data pipeline — check if data is actually missing or just delayed",
            "4. If medical data: immediately alert healthcare team",
            "5. Switch to backup sensor if available",
            "6. Review and adjust threshold values if they are too sensitive",
        ],
        "severity": "CRITICAL",
        "category": "application",
        "escalate": True,
        "prevention": "Implement redundant sensors, set up backup data collection paths",
    },

    # ══════════════════════════════════════════════════════════════
    # REPEATED ABUSE / IP ABUSE
    # ══════════════════════════════════════════════════════════════

    {
        "id": "ABUSE-001",
        "log_types": ["Apache", "OpenStack", "Proxifier"],
        "triggers": ["high request frequency", "rate limit",
                     "too many requests", "flood", "request flood"],
        "anomaly_type": "repeated_abuse",
        "root_cause": "A single IP or source is sending an abnormally high number of requests — possible DDoS or scraping.",
        "fix": [
            "1. Identify the top offending IP from logs",
            "2. Block the IP immediately:",
            "   `iptables -A INPUT -s <IP> -j DROP`",
            "3. Enable rate limiting in Apache/Nginx:",
            "   Apache: use mod_ratelimit or mod_evasive",
            "   Nginx: `limit_req_zone` directive",
            "4. Deploy a WAF (Web Application Firewall)",
            "5. Enable CAPTCHA for suspicious traffic patterns",
            "6. If DDoS: contact upstream provider for traffic scrubbing",
        ],
        "severity": "HIGH",
        "category": "security",
        "escalate": False,
        "prevention": "Deploy WAF, implement rate limiting, use Cloudflare or similar CDN/DDoS protection",
    },

    {
        "id": "ABUSE-002",
        "log_types": ["OpenSSH"],
        "triggers": ["repeated ssh", "failed password", "brute force",
                     "too many authentication failures"],
        "anomaly_type": "repeated_abuse",
        "root_cause": "Repeated SSH login failures from same source — SSH brute force attack in progress.",
        "fix": [
            "1. Block attacker IP: `iptables -A INPUT -s <IP> -j DROP`",
            "2. Install fail2ban: `apt install fail2ban`",
            "3. Configure fail2ban SSH jail:",
            "   maxretry = 3",
            "   bantime = 86400  # 24 hours",
            "4. Disable root SSH login: `PermitRootLogin no`",
            "5. Use SSH keys only: `PasswordAuthentication no`",
            "6. Move SSH to non-standard port",
        ],
        "severity": "CRITICAL",
        "category": "security",
        "escalate": True,
        "prevention": "Deploy fail2ban, use SSH keys, monitor auth logs in real-time",
    },

    {
        "id": "ABUSE-003",
        "log_types": ["Android"],
        "triggers": ["anr in", "fatal exception main",
                     "repeated crash", "crash repeated", "app crashed"],
        "anomaly_type": "repeated_abuse",
        "root_cause": "Same Android app repeatedly crashing — indicates a persistent software bug.",
        "fix": [
            "1. Identify the crashing app package name from logs",
            "2. Clear app cache and data: Settings → Apps → Clear Data",
            "3. Uninstall and reinstall the app",
            "4. Check if the crash happens after OS update — may need app update",
            "5. If it's your own app: get the crash stack trace and fix the bug",
            "6. Report to app developer if third-party app",
        ],
        "severity": "MEDIUM",
        "category": "application",
        "escalate": False,
        "prevention": "Set up Firebase Crashlytics, implement crash rate monitoring",
    },

    # ══════════════════════════════════════════════════════════════
    # CONFIGURATION ISSUES
    # ══════════════════════════════════════════════════════════════

    {
        "id": "CONF-001",
        "log_types": ["Mac"],
        "triggers": ["sandbox violation", "gatekeeper block",
                     "code signature", "sandbox deny"],
        "anomaly_type": "unusual_operations",
        "root_cause": "macOS security framework blocked an operation — sandbox violation or Gatekeeper denial.",
        "fix": [
            "1. Check which app was blocked: look at the log for app name",
            "2. If legitimate app: check code signing certificate",
            "3. Allow in System Preferences → Security & Privacy if trusted",
            "4. If unknown app: do NOT allow — investigate further",
            "5. Run `codesign -verify <app_path>` to check signature",
            "6. Update the app if signature is expired",
        ],
        "severity": "MEDIUM",
        "category": "security",
        "escalate": False,
        "prevention": "Keep apps updated, only install from App Store or known developers",
    },

    {
        "id": "CONF-002",
        "log_types": ["Proxifier"],
        "triggers": ["connection blocked", "rule blocked",
                     "proxy access denied", "ssl certificate error",
                     "invalid certificate"],
        "anomaly_type": "unauthorized_access",
        "root_cause": "Proxifier blocked a connection due to rule match or SSL certificate issue.",
        "fix": [
            "1. Check which Proxifier rule is blocking the connection",
            "2. If legitimate traffic: update Proxifier rules to allow",
            "3. If SSL error: check if certificate is expired or self-signed",
            "4. Update trusted certificate list in Proxifier settings",
            "5. If malicious traffic was blocked: log and monitor the source",
        ],
        "severity": "MEDIUM",
        "category": "configuration",
        "escalate": False,
        "prevention": "Regularly review Proxifier rules, automate certificate renewal",
    },
]


# ─────────────────────────────────────────────────────────────────────────────
# Default fallback rule when no specific rule matches
# ─────────────────────────────────────────────────────────────────────────────

DEFAULT_RULE = {
    "id": "GEN-001",
    "root_cause": "Anomalous behavior detected by ML model. Specific root cause requires manual investigation.",
    "fix": [
        "1. Review the flagged log entries in detail",
        "2. Check system metrics at the time of the anomaly (CPU, RAM, Disk, Network)",
        "3. Look for correlated events in other services around the same time",
        "4. Check recent deployments or configuration changes",
        "5. Escalate to the relevant team if issue persists",
    ],
    "severity": "MEDIUM",
    "category": "general",
    "escalate": False,
    "prevention": "Set up comprehensive monitoring and alerting for this service",
}
