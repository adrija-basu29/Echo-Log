# pattern_correlator.py
# Correlates multiple anomalies to find causal chains and patterns
# This is the "chain learning" component — finds sequences that lead to failures

import re
from collections import defaultdict
from loguru import logger


# ─────────────────────────────────────────────────────────────────────────────
# Known Causal Chains
# Format: "warning pattern" → "leads to" → "final failure"
# The system learns these chains and alerts before the final failure
# ─────────────────────────────────────────────────────────────────────────────

CAUSAL_CHAINS = {

    "storage_shortage": {
        "name": "Storage Shortage Chain",
        "description": "Sequence of events that leads to disk/storage exhaustion",
        "warning_signs": [
            "disk.*full", "no.*space", "quota.*exceed",
            "storage.*full", "enospc", "disk.*usage",
            "du -sh", "cleanup", "large.*file",
        ],
        "final_failure": ["storage full", "disk full", "enospc", "no space left"],
        "prevention_action": "Auto-expand disk or trigger cleanup script",
        "time_window_minutes": 60,
        # ── Guard: only fire if log_type suggests storage-related service
        "required_log_types": [],   # empty = no restriction
        # ── Guard: suppress if these dominant chains are already detected
        "suppressed_by": [],
    },

    "memory_exhaustion": {
        "name": "Memory Exhaustion Chain",
        "description": "Sequence leading to OOM kills",
        "warning_signs": [
            "memory.*pressure", "high.*memory", "low.*memory",
            "gc.*overhead", "gc.*pause", "swap.*high",
            "memory usage", "heap.*grow", "cache.*pressure",
        ],
        "final_failure": ["oom kill", "out of memory", "killed process",
                         "memory exhausted", "outofmemory"],
        "prevention_action": "Restart memory-heavy processes or add swap space",
        "time_window_minutes": 30,
        "required_log_types": [],
        "suppressed_by": [],
    },

    "ssh_brute_force": {
        "name": "SSH Brute Force Escalation",
        "description": "Progressive SSH attack pattern",
        "warning_signs": [
            "failed password", "invalid user", "authentication fail",
            "repeated.*ssh", "ssh.*attempt",
        ],
        "final_failure": ["break-in", "possible break", "session opened for root",
                         "root login"],
        "prevention_action": "Block source IP immediately, enable fail2ban",
        "time_window_minutes": 10,
        "required_log_types": [],
        "suppressed_by": [],
    },

    "cascade_node_failure": {
        "name": "Cascade Node Failure",
        "description": "Multiple node failures leading to cluster instability",
        "warning_signs": [
            "heartbeat.*miss", "node.*slow", "high.*load",
            # ── FIX: removed "connection.*timeout" — was triggering on SSH drops
            # ── FIX: removed "gc.*overhead" — too generic, fires on non-node logs
            "connection.*refused",   # more specific than timeout
            "node.*unreachable",
        ],
        "final_failure": ["node.*lost", "node.*fail", "cluster.*unstable",
                         "quorum.*lost", "tracker.*lost"],
        "prevention_action": "Redistribute load, restart struggling nodes",
        "time_window_minutes": 45,
        "required_log_types": ["BGL", "HPC", "Hadoop", "Spark", "Thunderbird"],
        # ── FIX: suppress this chain when SSH brute force is the dominant signal
        "suppressed_by": ["ssh_brute_force"],
    },

    "application_crash_loop": {
        "name": "Application Crash Loop",
        "description": "Application crashing repeatedly in a loop",
        "warning_signs": [
            "restarting", "respawn", "exit.*code", "crash.*count",
            "low.*memory", "gc.*pause",
        ],
        "final_failure": ["crash loop", "too many restarts", "failed to start",
                         "fatal exception", "anr", "force close"],
        "prevention_action": "Apply circuit breaker, restart with clean state",
        "time_window_minutes": 15,
        "required_log_types": [],
        "suppressed_by": [],
    },

    "hadoop_job_failure": {
        "name": "Hadoop Job Failure Chain",
        "description": "Warning signs before a Hadoop job fails completely",
        "warning_signs": [
            "slow.*task", "gc.*overhead", "high.*memory",
            "task.*retry", "attempt.*1", "straggler",
        ],
        "final_failure": ["job.*failed", "job.*aborted", "all.*attempts.*failed",
                         "map.*failed", "reduce.*failed"],
        "prevention_action": "Kill and resubmit with higher memory allocation",
        "time_window_minutes": 120,
        "required_log_types": ["Hadoop", "Spark", "HDFS"],
        "suppressed_by": [],
    },

    "windows_intrusion": {
        "name": "Windows Intrusion Chain",
        "description": "Sequence of events indicating Windows system compromise",
        "warning_signs": [
            "failed logon", "event 4625", "account locked",
            "unusual.*login", "off.*hours.*login",
        ],
        "final_failure": ["scheduled task created", "event 4698",
                         "user added to admin", "audit policy changed",
                         "event 4719"],
        "prevention_action": "Isolate machine, revoke compromised credentials",
        "time_window_minutes": 60,
        "required_log_types": ["Windows"],
        "suppressed_by": [],
    },

    # ─────────────────────────────────────────────────────────────────────────
    # NEW CHAINS — added for full 16-log-type coverage
    # ─────────────────────────────────────────────────────────────────────────

    "apache_http_flood": {
        "name": "Apache HTTP Flood / Error Spike",
        "description": "Escalating HTTP errors and request flood leading to server overload",
        "warning_signs": [
            # Rising error rates
            r"HTTP/\d\.\d\" 4\d\d",          # 4xx client errors
            r"HTTP/\d\.\d\" 5\d\d",          # 5xx server errors
            "error.*request", "invalid.*request",
            # Flood indicators
            "too many requests", "rate.*limit", "request.*flood",
            "connection.*limit", "max.*clients",
            # Slow response warnings
            "timeout.*request", "request.*timeout",
            "mod_security", "blocked.*request",
        ],
        "final_failure": [
            "server.*overload", "service.*unavailable",
            "worker.*exhausted", "unable to accept",
            "no space left", "segfault", "child.*killed",
        ],
        "prevention_action": "Enable rate limiting, block offending IPs via mod_security or WAF",
        "time_window_minutes": 15,
        "required_log_types": ["Apache"],
        "suppressed_by": [],
    },

    "linux_kernel_panic": {
        "name": "Linux System Degradation Chain",
        "description": "Kernel/system warning signs escalating to crash or panic",
        "warning_signs": [
            # Disk / filesystem stress
            "i/o error", "read.*error", "write.*error",
            "filesystem.*error", "ext.*error", "journal.*abort",
            # CPU / load stress
            "soft lockup", "rcu.*stall", "cpu.*stuck",
            "load average.*high", "irq.*flood",
            # Memory stress (linux-specific)
            "oom.*killer", "out of memory", "oom-kill",
            "swap.*full", "kswapd",
            # Network stress
            "nf_conntrack.*full", "neighbour.*table.*overflow",
            "dropped.*packet",
        ],
        "final_failure": [
            "kernel panic", "oops:", "bug:", "call trace",
            "general protection fault", "unable to handle kernel",
            "machine check exception", "hard lockup",
        ],
        "prevention_action": "Check hardware health (disk SMART, RAM test), reduce load, apply kernel patches",
        "time_window_minutes": 30,
        "required_log_types": ["Linux"],
        "suppressed_by": [],
    },

    "android_app_crash": {
        "name": "Android App Crash / ANR Chain",
        "description": "App instability warning signs leading to crash or ANR",
        "warning_signs": [
            # Memory pressure
            "low memory", "onlowmemory", "gc.*freed",
            "dalvik.*heap", "art.*heap", "trim.*memory",
            # Performance warnings
            "choreographer.*skipped", "skipped.*frames",
            "anr.*input.*dispatch", "slow.*operation",
            # Service instability
            "service.*crash", "process.*died",
            "activity.*not.*responding", "broadcast.*timeout",
            # Battery / thermal
            "thermal.*throttle", "cpu.*throttled",
        ],
        "final_failure": [
            "fatal exception", "force close", "has stopped",
            "anr in", "application not responding",
            "crash.*count.*exceeded", "process.*killed",
        ],
        "prevention_action": "Profile memory usage, fix memory leaks, optimize background services",
        "time_window_minutes": 20,
        "required_log_types": ["Android"],
        "suppressed_by": [],
    },

    "zookeeper_quorum_loss": {
        "name": "Zookeeper Quorum Degradation",
        "description": "Warning signs of quorum loss leading to cluster coordination failure",
        "warning_signs": [
            # Session / connection issues
            "session.*expired", "connection.*loss", "session.*timeout",
            "client.*disconnect", "unable to read",
            # Election instability
            "new leader.*elected", "looking for leader",
            "follower.*lagged", "sync.*limit.*exceeded",
            # Latency / throughput warnings
            "fsync.*time", "high.*latency", "slow.*disk",
            "outstanding.*requests", "request.*throttled",
            # Node health
            "node.*not.*reachable", "ensemble.*incomplete",
        ],
        "final_failure": [
            "quorum.*lost", "not enough.*alive",
            "no leader", "leader.*shutdown",
            "cluster.*down", "cannot.*connect.*zookeeper",
            "session.*0x.*closed",
        ],
        "prevention_action": "Check Zookeeper ensemble health, ensure odd number of nodes, increase tickTime",
        "time_window_minutes": 30,
        "required_log_types": ["Zookeeper"],
        "suppressed_by": [],
    },

    "health_app_anomaly": {
        "name": "Health App Sensor / Data Anomaly",
        "description": "Abnormal sensor readings or data pipeline issues in health monitoring app",
        "warning_signs": [
            "sensor.*error", "reading.*failed", "data.*missing",
            "step.*count.*abnormal", "heart.*rate.*spike",
            "gps.*lost", "location.*unavailable",
            "sync.*failed", "upload.*failed",
            "battery.*low", "service.*restart",
        ],
        "final_failure": [
            "data.*loss", "pipeline.*failed", "recording.*stopped",
            "critical.*sensor.*failure", "health.*service.*crash",
        ],
        "prevention_action": "Check sensor calibration, verify data pipeline connectivity, restart health service",
        "time_window_minutes": 20,
        "required_log_types": ["HealthApp"],
        "suppressed_by": [],
    },

    "proxifier_connection_abuse": {
        "name": "Proxifier Connection Abuse / Leak",
        "description": "Unusual proxy connection patterns indicating abuse or misconfiguration",
        "warning_signs": [
            "connection.*failed", "proxy.*error", "tunnel.*error",
            "dns.*leak", "auth.*failed", "proxy.*auth",
            "too many.*connections", "connection.*refused",
            "blocked.*rule", "direct.*connection",
        ],
        "final_failure": [
            "proxy.*unreachable", "all.*proxies.*failed",
            "connection.*aborted", "tunnel.*closed.*error",
        ],
        "prevention_action": "Review proxy rules, rotate credentials, check for DNS leaks",
        "time_window_minutes": 15,
        "required_log_types": ["Proxifier"],
        "suppressed_by": [],
    },

    "mac_system_fault": {
        "name": "macOS System Fault Chain",
        "description": "macOS kernel/service warning signs escalating to crash",
        "warning_signs": [
            # Kernel / hardware
            "kernel.*error", "i/o error", "disk.*error",
            "apfs.*error", "hfs.*error",
            # Service crashes
            "launchd.*error", "service.*exit", "crashed",
            "exception type", "exc_crash",
            # Memory
            "memory.*pressure", "swap.*usage", "jetsam",
            "low.*memory", "compressor.*stall",
        ],
        "final_failure": [
            "kernel panic", "panic.*log", "machine.*check",
            "unable to read.*block", "filesystem.*unmounted",
            "force.*quit", "spinning.*beachball",
        ],
        "prevention_action": "Run Disk Utility first aid, check kernel extension conflicts, update macOS",
        "time_window_minutes": 30,
        "required_log_types": ["Mac"],
        "suppressed_by": [],
    },
}


def find_pattern_in_text(text: str, patterns: list) -> bool:
    """Check if any pattern matches the text."""
    text_lower = text.lower()
    for pat in patterns:
        try:
            if re.search(pat, text_lower):
                return True
        except re.error:
            if pat in text_lower:
                return True
    return False


def get_combined_text(result: dict) -> str:
    """Get all searchable text from a result entry."""
    parts = [
        (result.get("raw_text") or ""),
        " ".join(result.get("anomaly_reasons", [])),
        (result.get("log_type") or ""),
    ]
    return " ".join(parts).lower()


def _get_log_types_present(anomalies: list) -> set:
    """Get the set of log types present in the anomaly batch."""
    return {(r.get("log_type") or "Unknown") for r in anomalies}


def correlate_anomalies(results: list) -> dict:
    """
    Finds causal chains across multiple anomaly results.
    Returns detected chains with confidence scores and preserved severity.
    """
    logger.info(f"Correlating {len(results)} results for causal chains...")

    anomalies = [r for r in results if r.get("is_anomaly")]
    log_types_present = _get_log_types_present(anomalies)

    # ── FIX: track max anomaly score per chain to preserve M3 severity
    raw_scores = [float(r.get("anomaly_score", 0)) for r in anomalies]
    global_max_score = max(raw_scores) if raw_scores else 0

    detected_chains = []
    detected_chain_ids = set()

    # ── Pass 1: find all matching chains (before suppression)
    candidates = []
    for chain_id, chain in CAUSAL_CHAINS.items():

        # ── FIX: skip chain if required_log_types is set and none match
        required = chain.get("required_log_types", [])
        if required and not log_types_present.intersection(set(required)):
            logger.debug(f"Chain '{chain_id}' skipped — log type not present")
            continue

        warning_hits = 0
        failure_hits = 0
        warning_examples = []
        failure_examples = []
        chain_max_score = 0.0

        for r in anomalies:
            text = get_combined_text(r)
            score = float(r.get("anomaly_score", 0))

            if find_pattern_in_text(text, chain["warning_signs"]):
                warning_hits += 1
                chain_max_score = max(chain_max_score, score)
                if len(warning_examples) < 2:
                    warning_examples.append(r.get("raw_text", "")[:100])

            if find_pattern_in_text(text, chain["final_failure"]):
                failure_hits += 1
                chain_max_score = max(chain_max_score, score)
                if len(failure_examples) < 2:
                    failure_examples.append(r.get("raw_text", "")[:100])

        if warning_hits >= 2 or failure_hits >= 1:
            confidence = min(100, int(
                (warning_hits * 20) + (failure_hits * 40)
            ))

            # ── FIX: map max score back to severity label (mirrors M3 thresholds)
            if chain_max_score >= 85:
                severity = "CRITICAL"
            elif chain_max_score >= 70:
                severity = "HIGH"
            elif chain_max_score >= 40:
                severity = "MEDIUM"
            else:
                severity = "LOW"

            candidates.append({
                "chain_id":          chain_id,
                "chain_name":        chain["name"],
                "description":       chain["description"],
                "confidence":        confidence,
                "warning_count":     warning_hits,
                "failure_count":     failure_hits,
                "max_score":         round(chain_max_score, 2),
                "severity":          severity,
                "prevention_action": chain["prevention_action"],
                "warning_examples":  warning_examples,
                "failure_examples":  failure_examples,
                "suppressed_by":     chain.get("suppressed_by", []),
                "status": (
                    "🔴 FAILURE OCCURRING" if failure_hits > 0
                    else "🟡 WARNING — FAILURE RISK"
                ),
            })
            detected_chain_ids.add(chain_id)

    # ── Pass 2: suppress chains that are dominated by a higher-priority chain
    dominant_ids = {c["chain_id"] for c in candidates}
    final_chains = []
    for c in candidates:
        suppressed_by = c.get("suppressed_by", [])
        if any(dominant in dominant_ids for dominant in suppressed_by):
            logger.info(
                f"Chain '{c['chain_id']}' suppressed — dominated by "
                f"{[d for d in suppressed_by if d in dominant_ids]}"
            )
            continue
        final_chains.append(c)

    # Sort by confidence (highest first)
    final_chains.sort(key=lambda x: x["confidence"], reverse=True)

    logger.info(f"Found {len(final_chains)} causal chains after suppression")
    return {
        "chains_detected":     len(final_chains),
        "chains":              final_chains,
        "total_anomalies":     len(anomalies),
        "global_max_score":    round(global_max_score, 2),
        "correlation_summary": _build_summary(final_chains),
    }


def _build_summary(chains: list) -> str:
    if not chains:
        return "No causal chains detected. Anomalies appear isolated."
    top = chains[0]
    severity_tag = f"[{top.get('severity', 'MEDIUM')}]"
    if top["failure_count"] > 0:
        return (f"ACTIVE {severity_tag}: '{top['chain_name']}' is occurring now. "
                f"Immediate action needed: {top['prevention_action']}")
    return (f"WARNING {severity_tag}: Early signs of '{top['chain_name']}' detected. "
            f"Recommended action: {top['prevention_action']}")


def find_repeated_entities(results: list) -> list:
    """
    Finds entities (IPs, apps, jobs, nodes) that appear repeatedly in anomalies.
    This helps identify the single most problematic source.
    """
    entity_counts = defaultdict(lambda: {
        "count": 0, "anomaly_count": 0,
        "max_score": 0.0, "examples": [], "log_types": set()
    })

    for r in results:
        raw     = (r.get("raw_text") or "").strip()
        lt      = (r.get("log_type") or "Unknown")
        score   = float(r.get("anomaly_score", 0))
        is_anom = r.get("is_anomaly", False)
        entity  = None

        # IP address
        m = re.search(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', raw)
        if m:
            entity = m.group(1)

        # Android app
        if not entity and lt == "Android":
            m = re.search(r'([a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]+)+)', raw.lower())
            if m:
                entity = m.group(1)

        # Hadoop/Spark job
        if not entity and lt in ("Hadoop", "Spark", "HDFS"):
            m = re.search(r'(job_\d+_\d+|task_\d+_\d+_\w+)', raw)
            if m:
                entity = m.group(1)

        # Windows — try EventID first, then component name (CBS, CSI, etc.)
        if not entity and lt == "Windows":
            # EventID pattern: EventID 4625
            m = re.search(r'EventID[:\s]+(\d+)', raw, re.IGNORECASE)
            if m:
                entity = f"EventID_{m.group(1)}"
            else:
                # Windows CBS/CSI/DISM style: "Info   CBS   message..."
                # Format: date, level, component, message
                parts = [p.strip() for p in raw.split() if p.strip()]
                for p in parts:
                    # Component names are short ALL-CAPS or known Windows components
                    if p.isupper() and 2 <= len(p) <= 10 and p.isalpha():
                        entity = f"Component_{p}"
                        break

        # Generic fallback — extract any ALL-CAPS service/component name
        # Works for Linux syslog, Mac, HealthApp, Proxifier etc.
        if not entity:
            # Syslog style: "Dec 10 07:51:12 LabSZ sshd[24324]: ..."
            m = re.search(r'\b([A-Za-z][\w.-]+)\[(\d+)\]', raw)
            if m:
                entity = f"{m.group(1)}"  # e.g. "sshd", "kernel", "cron"
            else:
                # Last resort: grab 3rd or 4th word as service name if short
                words = raw.split()
                for w in words[2:6]:
                    w_clean = w.strip('[]():,')
                    if 2 <= len(w_clean) <= 20 and w_clean.replace('-','').replace('_','').isalpha():
                        entity = w_clean
                        break

        # BGL/HPC Node
        if not entity and lt in ("BGL", "HPC", "Thunderbird"):
            m = re.search(r'(R\d{2}-M\d-N\d+|\bnode\d+\b)', raw, re.IGNORECASE)
            if m:
                entity = m.group(1)

        if entity:
            d = entity_counts[entity]
            d["count"] += 1
            d["log_types"].add(lt)
            d["max_score"] = max(d["max_score"], score)
            if is_anom:
                d["anomaly_count"] += 1
            if is_anom and len(d["examples"]) < 2:
                d["examples"].append(raw[:100])

    # Convert to list and filter meaningful ones
    result_list = []
    for entity, data in entity_counts.items():
        if data["anomaly_count"] >= 2:
            result_list.append({
                "entity":        entity,
                "total_count":   data["count"],
                "anomaly_count": data["anomaly_count"],
                "max_score":     round(data["max_score"], 2),
                "log_types":     list(data["log_types"]),
                "examples":      data["examples"],
            })

    return sorted(result_list, key=lambda x: x["anomaly_count"], reverse=True)[:10]
