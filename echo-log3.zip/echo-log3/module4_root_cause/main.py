# main.py — Module 4: Root Cause Analysis Engine
# Port: 8003

import os
import uvicorn
from fastapi import FastAPI
from loguru import logger
from routes import router

app = FastAPI(
    title="Echo-Log — Root Cause Analysis API",
    description="""
    ## Module 4: Root Cause Analysis Engine

    Takes anomaly detection results from Module 3 and produces:
    - **Root Cause** — exactly why this anomaly happened
    - **Fix Steps** — step-by-step instructions to resolve it
    - **Causal Chains** — sequences of events leading to failures
    - **Escalation Decision** — auto-fix or human escalation needed
    - **Prevention** — what to monitor to stop it happening again

    ### Covers all 16 log types:
    HDFS, Hadoop, Spark, Zookeeper, BGL, HPC, Thunderbird,
    Windows, Linux, Android, HealthApp, Apache, OpenSSH,
    OpenStack, Mac, Proxifier

    ### 5 Anomaly Categories:
    - High Error Rate
    - Unauthorized Access
    - Unusual Operations
    - Repeated Abuse
    - Performance Issues
    """,
    version="1.0.0"
)

os.makedirs("logs", exist_ok=True)
logger.add(
    "logs/rca.log",
    rotation="10 MB",
    retention="7 days",
    level="INFO",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}"
)

app.include_router(router, prefix="/api/v4")


@app.get("/")
async def root():
    return {
        "project":  "Echo-Log",
        "module":   "Module 4 — Root Cause Analysis",
        "port":     8003,
        "status":   "running",
        "routes": {
            "POST /api/v4/analyze":           "RCA from Module 3 detection report",
            "POST /api/v4/analyze-from-logs": "Full pipeline: logs → detect → RCA",
            "POST /api/v4/single-entry":      "RCA on single anomaly entry",
            "POST /api/v4/causal-chains":     "Get causal chain analysis only",
            "GET  /api/v4/rules":             "List all RCA rules",
            "GET  /api/v4/health":            "Health check",
        },
        "docs": "Visit /docs for interactive API documentation"
    }


if __name__ == "__main__":
    logger.info("🚀 Starting Echo-Log Root Cause Analysis Server on port 8003...")
    uvicorn.run("main:app", host="0.0.0.0", port=8003, reload=False)
