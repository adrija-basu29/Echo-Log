# test_module4.py
# Tests Module 4 Root Cause Analysis
# Run: python test_module4.py <path_to_log_file>

import sys
import json
import requests
from alert_manager import send_alerts  # ← Module 5

M3_URL = "http://localhost:8002/api/v3"
M4_URL = "http://localhost:8003/api/v4"


def test_with_log_file(log_path: str):
    print("=" * 65)
    print("  Echo-Log — Module 4 Root Cause Analysis Test")
    print("=" * 65)

    # Step 1: Preprocess via Module 2
    print(f"\n📂 Reading: {log_path}")
    try:
        with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = [l.strip() for l in f if l.strip()]
    except FileNotFoundError:
        print(f"❌ File not found: {log_path}")
        return

    structured_logs = []
    for i, line in enumerate(lines[:2000], 1):
        structured_logs.append({
            "line_number": i,
            "raw_text":    line,
            "message":     line,
            "level":       "ERROR" if any(w in line.upper() for w in
                           ["ERROR","FATAL","EXCEPTION","FAIL","CRITICAL"]) else "INFO",
            "is_error":    any(w in line.upper() for w in
                           ["ERROR","FATAL","EXCEPTION","FAIL","CRITICAL"]),
            "is_warning":  any(w in line.upper() for w in ["WARN","WARNING"]),
            "service":     "",
            "timestamp":   None,
            "event_template": "",
        })

    print(f"✅ Loaded {len(structured_logs)} log entries")

    # Step 2: Call Module 4 full pipeline
    print(f"\n🔍 Running Module 3 + Module 4 pipeline...")
    try:
        resp = requests.post(
            f"{M4_URL}/analyze-from-logs",
            json={"structured_logs": structured_logs},
            timeout=300
        )
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to Module 4 (port 8003). Is it running?")
        return

    if resp.status_code != 200:
        print(f"❌ Error: {resp.text[:500]}")
        return

    data     = resp.json()
    detect   = data.get("detection_report", {})
    rca      = data.get("rca_report", {})
    summary  = rca.get("summary", {})
    chains   = rca.get("causal_chains", {})
    entities = rca.get("repeated_entities", [])
    fixes    = rca.get("top_fixes", [])

    # ── Print Results ─────────────────────────────────────────────
    print("\n" + "=" * 65)
    print("  DETECTION SUMMARY")
    print("=" * 65)
    print(f"  Total Entries  : {detect.get('total_entries', 0)}")
    print(f"  Anomalies      : {rca.get('anomaly_count', 0)}")
    print(f"  CRITICAL       : {detect.get('critical_count', 0)}")
    print(f"  HIGH           : {detect.get('high_count', 0)}")
    print(f"  Escalate       : {'🚨 YES' if rca.get('escalation_needed') else '✅ NO'}")

    print("\n" + "=" * 65)
    print("  ROOT CAUSE SUMMARY")
    print("=" * 65)
    print(f"  {summary.get('headline', '')}")
    for f in summary.get("key_findings", []):
        print(f"  • {f}")

    print("\n" + "=" * 65)
    print("  TOP FIXES")
    print("=" * 65)
    for i, fix in enumerate(fixes[:3], 1):
        print(f"\n  [{fix['rule_id']}] {fix['severity']} — {fix['category'].upper()}")
        print(f"  Root Cause : {fix['root_cause']}")
        print(f"  Affects    : {fix['affects_count']} anomalies")
        print(f"  Fix Step 1 : {fix['fix_steps'][0] if fix['fix_steps'] else 'N/A'}")
        print(f"  Prevention : {fix['prevention']}")

    if chains.get("chains_detected", 0) > 0:
        print("\n" + "=" * 65)
        print("  CAUSAL CHAINS DETECTED")
        print("=" * 65)
        for ch in chains.get("chains", [])[:2]:
            print(f"\n  {ch['status']}")
            print(f"  Chain   : {ch['chain_name']}")
            print(f"  Confidence: {ch['confidence']}%")
            print(f"  Action  : {ch['prevention_action']}")

    if entities:
        print("\n" + "=" * 65)
        print("  REPEATED PROBLEMATIC ENTITIES")
        print("=" * 65)
        for e in entities[:3]:
            print(f"  {e['entity']:<40} — {e['anomaly_count']} anomalies  "
                  f"(score: {e['max_score']})")

    print("\n" + "=" * 65)
    print("  ✅ Module 4 RCA Complete")
    print("=" * 65)

    # ── Step 3: Send Alerts (Module 5) ───────────────────────────
    # Detect log type from filename
    log_type_map = {
        "openssh": "OpenSSH", "ssh": "OpenSSH",
        "openstack": "OpenStack",
        "apache": "Apache",
        "linux": "Linux",
        "windows": "Windows",
        "android": "Android",
        "hadoop": "Hadoop",
        "hdfs": "HDFS",
        "spark": "Spark",
        "zookeeper": "Zookeeper",
        "bgl": "BGL",
        "hpc": "HPC",
        "thunderbird": "Thunderbird",
        "mac": "Mac",
        "healthapp": "HealthApp",
        "proxifier": "Proxifier",
    }
    log_fname = log_path.lower().replace("\\", "/").split("/")[-1]
    detected_log_type = "Unknown"
    for key, val in log_type_map.items():
        if key in log_fname:
            detected_log_type = val
            break

    detection_summary = {
        "log_file":       log_path,
        "log_type":       detected_log_type,
        "total_entries":  detect.get("total_entries", 0),
        "anomaly_count":  rca.get("anomaly_count", 0),
        "critical_count": detect.get("critical_count", 0),
        "high_count":     detect.get("high_count", 0),
        "max_score":      detect.get("max_score", 0),
    }
    # ── FIX: pass full rca output (includes top_entities), not just chains
    rca_output = {
        "chains":              chains.get("chains", []),
        "chains_detected":     chains.get("chains_detected", 0),
        "top_entities":        entities,   # ← was missing before, caused N/A
        "correlation_summary": chains.get("correlation_summary", ""),
    }
    send_alerts(rca_output, detection_summary)


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else r"E:\echo-log\loghub\OpenSSH\SSH_2k.log"
    test_with_log_file(path)
