# alert_manager.py
# Module 5: Alert & Notification System
# Receives M4 RCA output → formats → delivers alerts via multiple channels
#
# Supported channels:
#   - Console   (always on)
#   - Log file  (always on)
#   - JSON file (always on — Module 6 dashboard reads this)
#   - Email     (Gmail SMTP — configure section below)
#   - Slack     (webhook — configure section below)

import json
import os
import smtplib
import socket
import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from loguru import logger


# ─────────────────────────────────────────────────────────────────────────────
# ✉️  CONFIGURATION — edit this section to enable/disable channels
# ─────────────────────────────────────────────────────────────────────────────

ALERT_CONFIG = {

    "console": {
        "enabled": True,
    },

    "log_file": {
        "enabled": True,
        "path": "alerts.log",
    },

    "json_file": {
        "enabled": True,
        "path": "alerts_history.json",  # Module 6 reads this
    },

    # ── EMAIL — Gmail SMTP ────────────────────────────────────────────────────
    # To enable:
    #   1. Go to myaccount.google.com → Security → 2-Step Verification (ON)
    #   2. Search "App Passwords" → Generate → copy the 16-char password
    #   3. Fill in your details below and set enabled = True
    # ─────────────────────────────────────────────────────────────────────────
    "email": {
        "enabled":      True,                      # ← set True to activate
        "smtp_host":    "smtp.gmail.com",
        "smtp_port":    587,
        "username":     "adritaghosh586@gmail.com",     # ← your Gmail address
        "password":     "oktr ncsz ldex mjuv",     # ← 16-char App Password
        "from_addr":    "adritaghosh586@gmail.com",     # ← same Gmail address
        "to_addrs":     ["adritaghosh586@gmail.com"],   # ← recipient(s)
        "min_severity": "HIGH",                    # only email HIGH + CRITICAL
    },

    # ── SLACK — webhook ───────────────────────────────────────────────────────
    # To enable:
    #   1. Go to api.slack.com/apps → Create App → Incoming Webhooks
    #   2. Copy the webhook URL and paste below
    #   3. Set enabled = True
    # ─────────────────────────────────────────────────────────────────────────
    "slack": {
        "enabled":      False,
        "webhook_url":  "https://hooks.slack.com/services/YOUR/WEBHOOK/URL",
        "min_severity": "MEDIUM",
    },
}

# Severity rank for threshold comparisons
SEVERITY_RANK = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ENTRY POINT — call this from your pipeline after Module 4
# ─────────────────────────────────────────────────────────────────────────────

def send_alerts(rca_output: dict, detection_summary: dict) -> dict:
    """
    Main function — called after Module 4 completes.

    Args:
        rca_output:        Full dict returned by Module 4 RCA
        detection_summary: Detection stats from Module 3
                           Keys: log_file, log_type, total_entries,
                                 anomaly_count, critical_count, high_count, max_score

    Returns:
        dict with delivery results per channel
    """
    alerts = _build_alert_objects(rca_output, detection_summary)

    if not alerts:
        logger.info("No alerts to send — all anomalies below threshold")
        return {"alerts_sent": 0, "channels": {}}

    logger.info(f"Sending {len(alerts)} alert(s) across configured channels...")

    results = {}

    if ALERT_CONFIG["console"]["enabled"]:
        results["console"] = _send_console(alerts)

    if ALERT_CONFIG["log_file"]["enabled"]:
        results["log_file"] = _send_log_file(alerts)

    if ALERT_CONFIG["json_file"]["enabled"]:
        results["json_file"] = _send_json_file(alerts, rca_output, detection_summary)

    if ALERT_CONFIG["email"]["enabled"]:
        results["email"] = _send_email(alerts)

    if ALERT_CONFIG["slack"]["enabled"]:
        results["slack"] = _send_slack(alerts)

    total_sent = sum(1 for r in results.values() if r.get("success"))
    logger.info(f"Alert delivery complete — {total_sent}/{len(results)} channels succeeded")

    return {
        "alerts_built": len(alerts),
        "alerts_sent":  total_sent,
        "channels":     results,
        "top_alert":    alerts[0] if alerts else None,
    }


# ─────────────────────────────────────────────────────────────────────────────
# ALERT BUILDER
# ─────────────────────────────────────────────────────────────────────────────

def _build_alert_objects(rca_output: dict, detection_summary: dict) -> list:
    alerts   = []
    now      = datetime.datetime.now().isoformat()
    hostname = socket.gethostname()

    total     = detection_summary.get("total_entries", 0)
    anomalies = detection_summary.get("anomaly_count", 0)
    critical  = detection_summary.get("critical_count", 0)
    high      = detection_summary.get("high_count", 0)
    log_file  = detection_summary.get("log_file", "unknown")
    log_type  = detection_summary.get("log_type", "unknown")
    max_score = detection_summary.get("max_score", 0)

    chains   = rca_output.get("chains", [])
    entities = rca_output.get("top_entities", [])
    top_entity = entities[0] if entities else None

    # One alert per causal chain
    for chain in chains:
        severity  = chain.get("severity", "MEDIUM")
        is_active = chain.get("failure_count", 0) > 0

        alerts.append({
            "alert_id":             _make_alert_id(chain["chain_id"], now),
            "timestamp":            now,
            "hostname":             hostname,
            "log_file":             log_file,
            "log_type":             log_type,
            "severity":             severity,
            "status":               "ACTIVE" if is_active else "WARNING",
            "chain_id":             chain["chain_id"],
            "chain_name":           chain["chain_name"],
            "description":          chain["description"],
            "confidence":           chain["confidence"],
            "warning_count":        chain["warning_count"],
            "failure_count":        chain["failure_count"],
            "max_score":            chain.get("max_score", 0),
            "action_required":      chain["prevention_action"],
            "top_entity":           top_entity["entity"] if top_entity else "N/A",
            "top_entity_anomalies": top_entity["anomaly_count"] if top_entity else 0,
            "summary":              _build_chain_summary(chain, top_entity),
        })

    # Extra escalation alert if CRITICAL exists but no chain captured it
    if critical > 0 and not any(a["severity"] == "CRITICAL" for a in alerts):
        alerts.insert(0, {
            "alert_id":             _make_alert_id("critical_escalation", now),
            "timestamp":            now,
            "hostname":             hostname,
            "log_file":             log_file,
            "log_type":             log_type,
            "severity":             "CRITICAL",
            "status":               "ACTIVE",
            "chain_id":             "critical_escalation",
            "chain_name":           "Critical Anomaly Escalation",
            "description":          f"{critical} CRITICAL anomalies detected — immediate investigation required",
            "confidence":           100,
            "warning_count":        0,
            "failure_count":        critical,
            "max_score":            max_score,
            "action_required":      "Immediately review flagged log entries and escalate to on-call engineer",
            "top_entity":           top_entity["entity"] if top_entity else "N/A",
            "top_entity_anomalies": top_entity["anomaly_count"] if top_entity else 0,
            "summary":              f"🚨 CRITICAL: {critical} critical + {high} high anomalies in {log_file}.",
        })

    # Sort: CRITICAL first, then by confidence
    alerts.sort(key=lambda a: (
        -SEVERITY_RANK.get(a["severity"], 0),
        -a["confidence"]
    ))
    return alerts


def _build_chain_summary(chain: dict, top_entity) -> str:
    emoji = "🔴" if chain.get("failure_count", 0) > 0 else "🟡"
    entity_str = f" Top offender: {top_entity['entity']} ({top_entity['anomaly_count']} anomalies)." if top_entity else ""
    return (
        f"{emoji} [{chain['severity']}] {chain['chain_name']} — "
        f"{chain['confidence']}% confidence. "
        f"{chain['warning_count']} warnings, {chain['failure_count']} failures."
        f"{entity_str} Action: {chain['prevention_action']}"
    )


def _make_alert_id(chain_id: str, timestamp: str) -> str:
    ts = timestamp.replace(":", "").replace("-", "").replace(".", "")[:15]
    return f"ALERT-{chain_id.upper()[:12]}-{ts}"


# ─────────────────────────────────────────────────────────────────────────────
# CHANNEL 1 — CONSOLE
# ─────────────────────────────────────────────────────────────────────────────

def _send_console(alerts: list) -> dict:
    try:
        print()
        print("=" * 65)
        print("  📢 MODULE 5 — ALERT SUMMARY")
        print("=" * 65)
        for alert in alerts:
            sev   = alert["severity"]
            emoji = {"CRITICAL": "🚨", "HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🔵"}.get(sev, "⚪")
            status_label = "🔴 ACTIVE FAILURE" if alert["status"] == "ACTIVE" else "🟡 WARNING"
            print(f"""
  {emoji} [{sev}] {alert['chain_name']}
  ─────────────────────────────────────────────────────────────
  Status     : {status_label}
  Confidence : {alert['confidence']}%
  Log File   : {alert['log_file']}
  Top Entity : {alert['top_entity']} ({alert['top_entity_anomalies']} anomalies)
  Action     : {alert['action_required']}
  Alert ID   : {alert['alert_id']}
""")
        print("=" * 65)
        return {"success": True, "alerts_printed": len(alerts)}
    except Exception as e:
        logger.error(f"Console alert failed: {e}")
        return {"success": False, "error": str(e)}


# ─────────────────────────────────────────────────────────────────────────────
# CHANNEL 2 — LOG FILE
# ─────────────────────────────────────────────────────────────────────────────

def _send_log_file(alerts: list) -> dict:
    path = ALERT_CONFIG["log_file"]["path"]
    try:
        with open(path, "a", encoding="utf-8") as f:
            for alert in alerts:
                f.write(
                    f"[{alert['timestamp']}] [{alert['severity']}] "
                    f"{alert['chain_name']} | Confidence={alert['confidence']}% | "
                    f"Entity={alert['top_entity']} | Action={alert['action_required']}\n"
                )
        logger.info(f"Alerts appended to {path}")
        return {"success": True, "path": path, "alerts_written": len(alerts)}
    except Exception as e:
        logger.error(f"Log file alert failed: {e}")
        return {"success": False, "error": str(e)}


# ─────────────────────────────────────────────────────────────────────────────
# CHANNEL 3 — JSON FILE (Module 6 reads this)
# ─────────────────────────────────────────────────────────────────────────────

def _send_json_file(alerts: list, rca_output: dict, detection_summary: dict) -> dict:
    path = ALERT_CONFIG["json_file"]["path"]
    try:
        history = []
        if Path(path).exists():
            with open(path, "r", encoding="utf-8") as f:
                try:
                    history = json.load(f)
                except json.JSONDecodeError:
                    history = []

        batch = {
            "batch_id":            _make_alert_id("batch", alerts[0]["timestamp"]),
            "timestamp":           alerts[0]["timestamp"],
            "log_file":            detection_summary.get("log_file", "unknown"),
            "log_type":            detection_summary.get("log_type", "unknown"),
            "total_entries":       detection_summary.get("total_entries", 0),
            "anomaly_count":       detection_summary.get("anomaly_count", 0),
            "critical_count":      detection_summary.get("critical_count", 0),
            "high_count":          detection_summary.get("high_count", 0),
            "alerts":              alerts,
            "top_entities":        rca_output.get("top_entities", [])[:5],
            "chains_detected":     rca_output.get("chains_detected", 0),
            "correlation_summary": rca_output.get("correlation_summary", ""),
        }
        history.append(batch)

        with open(path, "w", encoding="utf-8") as f:
            json.dump(history, f, indent=2, default=str)

        logger.info(f"Alert batch saved to {path}")
        return {"success": True, "path": path, "batch_id": batch["batch_id"]}
    except Exception as e:
        logger.error(f"JSON file alert failed: {e}")
        return {"success": False, "error": str(e)}


# ─────────────────────────────────────────────────────────────────────────────
# CHANNEL 4 — EMAIL (Gmail SMTP)
# ─────────────────────────────────────────────────────────────────────────────

def _send_email(alerts: list) -> dict:
    cfg      = ALERT_CONFIG["email"]
    min_rank = SEVERITY_RANK.get(cfg["min_severity"], 2)
    filtered = [a for a in alerts if SEVERITY_RANK.get(a["severity"], 0) >= min_rank]

    if not filtered:
        return {"success": True, "skipped": "No alerts met email severity threshold"}

    try:
        subject  = _build_email_subject(filtered)
        html     = _build_email_html(filtered)
        text     = _build_email_text(filtered)

        msg            = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = cfg["from_addr"]
        msg["To"]      = ", ".join(cfg["to_addrs"])
        msg.attach(MIMEText(text, "plain"))
        msg.attach(MIMEText(html, "html"))

        with smtplib.SMTP(cfg["smtp_host"], cfg["smtp_port"]) as server:
            server.ehlo()
            server.starttls()
            server.login(cfg["username"], cfg["password"])
            server.sendmail(cfg["from_addr"], cfg["to_addrs"], msg.as_string())

        logger.info(f"✅ Email sent to {cfg['to_addrs']}")
        return {"success": True, "recipients": cfg["to_addrs"], "alerts_sent": len(filtered)}

    except smtplib.SMTPAuthenticationError:
        msg = "Gmail authentication failed. Check your App Password (not your regular password)."
        logger.error(msg)
        return {"success": False, "error": msg}
    except smtplib.SMTPException as e:
        logger.error(f"SMTP error: {e}")
        return {"success": False, "error": str(e)}
    except Exception as e:
        logger.error(f"Email alert failed: {e}")
        return {"success": False, "error": str(e)}


def _build_email_subject(alerts: list) -> str:
    top    = alerts[0]
    sev    = top["severity"]
    prefix = {"CRITICAL": "🚨 CRITICAL", "HIGH": "🔴 HIGH", "MEDIUM": "🟡 MEDIUM"}.get(sev, "⚪ ALERT")
    return f"{prefix} — {top['chain_name']} | {top['log_file']} | {top['hostname']}"


def _build_email_text(alerts: list) -> str:
    lines = ["ECHO-LOG ALERT REPORT", "=" * 50, ""]
    for a in alerts:
        lines += [
            f"[{a['severity']}] {a['chain_name']}",
            f"  Status     : {a['status']}",
            f"  Confidence : {a['confidence']}%",
            f"  Log File   : {a['log_file']}",
            f"  Top Entity : {a['top_entity']} ({a['top_entity_anomalies']} anomalies)",
            f"  Action     : {a['action_required']}",
            f"  Alert ID   : {a['alert_id']}",
            "",
        ]
    return "\n".join(lines)


def _build_email_html(alerts: list) -> str:
    sev_colors = {
        "CRITICAL": "#c0392b",
        "HIGH":     "#e74c3c",
        "MEDIUM":   "#f39c12",
        "LOW":      "#3498db",
    }
    rows = ""
    for a in alerts:
        color = sev_colors.get(a["severity"], "#888")
        rows += f"""
        <tr>
          <td style="padding:12px;border-bottom:1px solid #eee;">
            <span style="background:{color};color:white;padding:4px 10px;
                         border-radius:4px;font-weight:bold;font-size:13px;">
              {a['severity']}
            </span>
            &nbsp;<strong>{a['chain_name']}</strong><br>
            <small style="color:#666;">{a['description']}</small>
          </td>
          <td style="padding:12px;border-bottom:1px solid #eee;text-align:center;">
            <strong>{a['confidence']}%</strong>
          </td>
          <td style="padding:12px;border-bottom:1px solid #eee;">
            <code>{a['top_entity']}</code><br>
            <small>{a['top_entity_anomalies']} anomalies</small>
          </td>
          <td style="padding:12px;border-bottom:1px solid #eee;color:#c0392b;">
            {a['action_required']}
          </td>
        </tr>"""

    return f"""
    <html>
    <body style="font-family:Arial,sans-serif;color:#333;max-width:900px;margin:auto;">
      <div style="background:#c0392b;padding:20px;border-radius:8px 8px 0 0;">
        <h2 style="color:white;margin:0;">🚨 Echo-Log Alert Report</h2>
        <p style="color:#f5b7b1;margin:5px 0 0;">Automated anomaly detection alert</p>
      </div>
      <div style="background:#fdf2f2;padding:15px 20px;border:1px solid #f5c6cb;">
        <strong>Host:</strong> {alerts[0]['hostname']} &nbsp;|&nbsp;
        <strong>Log File:</strong> {alerts[0]['log_file']} &nbsp;|&nbsp;
        <strong>Log Type:</strong> {alerts[0]['log_type']} &nbsp;|&nbsp;
        <strong>Time:</strong> {alerts[0]['timestamp']}
      </div>
      <table style="width:100%;border-collapse:collapse;border:1px solid #eee;">
        <tr style="background:#f8f9fa;">
          <th style="padding:12px;text-align:left;">Alert</th>
          <th style="padding:12px;text-align:center;">Confidence</th>
          <th style="padding:12px;text-align:left;">Top Entity</th>
          <th style="padding:12px;text-align:left;">Action Required</th>
        </tr>
        {rows}
      </table>
      <div style="background:#f8f9fa;padding:15px 20px;border:1px solid #eee;
                  border-top:none;border-radius:0 0 8px 8px;">
        <small style="color:#888;">
          Generated by <strong>Echo-Log Pipeline — Module 5</strong><br>
          This is an automated alert. Do not reply to this email.
        </small>
      </div>
    </body>
    </html>"""


# ─────────────────────────────────────────────────────────────────────────────
# CHANNEL 5 — SLACK
# ─────────────────────────────────────────────────────────────────────────────

def _send_slack(alerts: list) -> dict:
    import urllib.request
    cfg      = ALERT_CONFIG["slack"]
    min_rank = SEVERITY_RANK.get(cfg["min_severity"], 2)
    filtered = [a for a in alerts if SEVERITY_RANK.get(a["severity"], 0) >= min_rank]

    if not filtered:
        return {"success": True, "skipped": "No alerts met Slack severity threshold"}

    try:
        sev_emoji = {"CRITICAL": "🚨", "HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🔵"}
        sev_color = {"CRITICAL": "#c0392b", "HIGH": "#e74c3c", "MEDIUM": "#f39c12", "LOW": "#3498db"}

        attachments = []
        for a in filtered:
            attachments.append({
                "color": sev_color.get(a["severity"], "#888"),
                "blocks": [{
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": (
                            f"{sev_emoji.get(a['severity'], '⚪')} "
                            f"*[{a['severity']}] {a['chain_name']}*\n"
                            f"*Status:* {a['status']}  |  *Confidence:* {a['confidence']}%\n"
                            f"*Log File:* `{a['log_file']}`\n"
                            f"*Top Offender:* `{a['top_entity']}` ({a['top_entity_anomalies']} anomalies)\n"
                            f"*Action:* {a['action_required']}\n"
                            f"_Alert ID: {a['alert_id']}_"
                        ),
                    },
                }],
            })

        top     = filtered[0]
        payload = {
            "text": (
                f"{sev_emoji.get(top['severity'], '⚪')} *Echo-Log Alert* — "
                f"{top['chain_name']} detected in `{top['log_file']}`"
            ),
            "attachments": attachments,
        }

        data = json.dumps(payload).encode("utf-8")
        req  = urllib.request.Request(
            cfg["webhook_url"], data=data,
            headers={"Content-Type": "application/json"}, method="POST"
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            response_text = resp.read().decode()

        if response_text == "ok":
            logger.info(f"✅ Slack alert sent — {len(filtered)} alerts")
            return {"success": True, "alerts_sent": len(filtered)}
        else:
            return {"success": False, "error": f"Slack returned: {response_text}"}

    except Exception as e:
        logger.error(f"Slack alert failed: {e}")
        return {"success": False, "error": str(e)}


# ─────────────────────────────────────────────────────────────────────────────
# STANDALONE TEST — run: python alert_manager.py
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":

    mock_rca = {
        "chains_detected": 1,
        "chains": [{
            "chain_id":          "ssh_brute_force",
            "chain_name":        "SSH Brute Force Escalation",
            "description":       "Progressive SSH attack pattern",
            "confidence":        100,
            "warning_count":     487,
            "failure_count":     3,
            "max_score":         82.9,
            "severity":          "HIGH",
            "prevention_action": "Block source IP immediately, enable fail2ban",
            "status":            "🔴 FAILURE OCCURRING",
        }],
        "top_entities": [
            {"entity": "183.62.140.253",   "anomaly_count": 582, "max_score": 67.22},
            {"entity": "187.141.143.180",  "anomaly_count": 194, "max_score": 59.12},
        ],
        "correlation_summary": "ACTIVE [HIGH]: SSH Brute Force Escalation is occurring now.",
    }

    mock_detection = {
        "log_file":       "OpenSSH_2k.log",
        "log_type":       "OpenSSH",
        "total_entries":  2000,
        "anomaly_count":  1029,
        "critical_count": 0,
        "high_count":     5,
        "max_score":      82.9,
    }

    result = send_alerts(mock_rca, mock_detection)
    print(f"\n✅ Delivery result:\n{json.dumps(result, indent=2, default=str)}")
